import React, { useState, useMemo, useEffect } from 'react';
import { 
  Trophy, 
  Medal, 
  Flame, 
  Target, 
  Crown, 
  Calendar, 
  Clock, 
  Sparkles,
  Users,
  CheckCircle2,
  Lock,
  ShieldCheck,
  Zap,
  Award,
  ArrowRight,
  UserCheck
} from 'lucide-react';
import { useTournaments } from '../context/TournamentContext';
import { useAuth } from '../context/AuthContext';
import { FF_OFFICIAL_PLACEMENT_POINTS, MatchResult } from '../types';

interface LeaderboardProps {
  setActiveTab?: (tab: string) => void;
}

export const Leaderboard: React.FC<LeaderboardProps> = ({ setActiveTab }) => {
  const { results, tournaments, userRegistrations } = useTournaments();
  const { user, isAdmin, setShowLoginModal } = useAuth();

  // Set of tournament IDs user has purchased/registered for
  const userPurchasedTourIds = useMemo(() => {
    return new Set(
      userRegistrations
        .filter(r => r.status === 'CONFIRMED' || r.status === 'REGISTERED' || r.status === 'PENDING_APPROVAL')
        .map(r => r.tournamentId)
    );
  }, [userRegistrations]);

  // Tournaments strictly visible to the current viewer:
  // Admin sees all tournaments so they can review entered results;
  // Regular users ONLY see the tournaments they have purchased!
  const availableTournaments = useMemo(() => {
    if (!user) return [];
    if (isAdmin) return tournaments;
    return tournaments.filter(t => userPurchasedTourIds.has(t.id));
  }, [tournaments, userPurchasedTourIds, user, isAdmin]);

  // Selected tournament: default to first available tournament (never combine 'ALL')
  const [selectedTournamentId, setSelectedTournamentId] = useState<string>('');

  useEffect(() => {
    if (availableTournaments.length > 0) {
      if (!selectedTournamentId || !availableTournaments.some(t => t.id === selectedTournamentId)) {
        setSelectedTournamentId(availableTournaments[0].id);
      }
    } else {
      setSelectedTournamentId('');
    }
  }, [availableTournaments, selectedTournamentId]);

  // Active selected tournament
  const currentTournament = useMemo(() => {
    return availableTournaments.find(t => t.id === selectedTournamentId) || availableTournaments[0];
  }, [availableTournaments, selectedTournamentId]);

  // Filtered results: STRICTLY for the single chosen tournament!
  // Never combine all tournaments together into one table
  const filteredResults = useMemo(() => {
    if (!user || !selectedTournamentId) return [];

    return results.filter(r => r.tournamentId === selectedTournamentId);
  }, [results, selectedTournamentId, user]);

  // Helper: check if active tournament is CS 4V4 or Lone Wolf
  const isCSorLoneWolf = useMemo(() => {
    if (!currentTournament) return false;
    const cat = (currentTournament.matchCategory || '').toUpperCase();
    const title = (currentTournament.title || '').toUpperCase();
    return (
      cat.includes('CS 4') ||
      cat.includes('CLASH SQUAD') ||
      cat.includes('LONE WOLF') ||
      cat.includes('LOWN WOLF') ||
      title.includes('CS 4') ||
      title.includes('CLASH SQUAD') ||
      title.includes('LONE WOLF') ||
      title.includes('LOWN WOLF')
    );
  }, [currentTournament]);

  // Sort standings:
  // For CS 4V4 & Lone Wolf:
  // "যার বেশি Booyah সে শুধু Champion"
  // Strictly sorted by Booyah count descending!
  // For BR Scrim / Blast / etc:
  // Sorted by Total Points descending, then Kills, then Placement Points
  const sortedStandings = useMemo(() => {
    // 1. Check if a team was designated as Champion (e.g. for CHAMPION RUSH)
    const designatedChamp = filteredResults.find(r => r.isDesignatedChampion);
    if (designatedChamp && !isCSorLoneWolf) {
      const others = filteredResults
        .filter(r => r.id !== designatedChamp.id)
        .sort((a, b) => {
          if (b.totalPoints !== a.totalPoints) return b.totalPoints - a.totalPoints;
          if (b.kills !== a.kills) return b.kills - a.kills;
          return b.placementPoints - a.placementPoints;
        });

      return [designatedChamp, ...others].map((item, idx) => ({
        ...item,
        rank: idx + 1,
      }));
    }

    const list = [...filteredResults].sort((a, b) => {
      if (isCSorLoneWolf) {
        const aBooyahs = a.booyahs ?? (a.rank === 1 ? 1 : 0);
        const bBooyahs = b.booyahs ?? (b.rank === 1 ? 1 : 0);
        if (bBooyahs !== aBooyahs) {
          return bBooyahs - aBooyahs;
        }
        if (b.kills !== a.kills) {
          return b.kills - a.kills;
        }
        return (a.matchesPlayed ?? 1) - (b.matchesPlayed ?? 1);
      }

      if (b.totalPoints !== a.totalPoints) {
        return b.totalPoints - a.totalPoints;
      }
      if (b.kills !== a.kills) {
        return b.kills - a.kills;
      }
      return b.placementPoints - a.placementPoints;
    });

    // Re-assign rank 1..N based on sorted order
    return list.map((item, idx) => ({
      ...item,
      rank: idx + 1,
    }));
  }, [filteredResults, isCSorLoneWolf]);

  const top1 = sortedStandings[0];
  const top2 = sortedStandings[1];
  const top3 = sortedStandings[2];

  // Helper: check if a result belongs to current user's squad
  const isUserSquad = (res: MatchResult) => {
    if (!user) return false;
    if (user.ffUid && res.ffUid === user.ffUid) return true;
    if (user.teamName && res.teamName && res.teamName.trim().toLowerCase() === user.teamName.trim().toLowerCase()) return true;
    if (user.ffNickname && res.playerName && res.playerName.toLowerCase().includes(user.ffNickname.toLowerCase())) return true;
    return false;
  };

  // Find user's own team result in current standings
  const userTeamResult = useMemo(() => {
    return sortedStandings.find(r => isUserSquad(r));
  }, [sortedStandings, user]);

  return (
    <div className="max-w-xl mx-auto space-y-4 pb-24 font-bangla text-slate-800">
      
      {/* 1. HEADER CARD */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
        <div>
          <span className="text-[11px] font-black text-red-600 uppercase tracking-widest block flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-red-600 animate-pulse"></span>
            FREE FIRE ESPORTS STANDINGS
          </span>
          <h1 className="font-heading text-xl font-black text-slate-950 mt-0.5">
            লিডারবোর্ড ও অফিসিয়াল পয়েন্ট টেবিল
          </h1>
        </div>
      </div>

      {/* 2. PURCHASED TOURNAMENT SELECTOR BUTTONS (NAME & TIME) */}
      {availableTournaments.length > 0 && (
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-0.5">
          {availableTournaments.map(t => {
            const isSelected = selectedTournamentId === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setSelectedTournamentId(t.id)}
                className={`px-4 py-2.5 rounded-xl text-xs font-heading font-black shrink-0 transition-all cursor-pointer flex items-center gap-2 border ${
                  isSelected
                    ? 'bg-red-600 text-white border-red-600 shadow-md shadow-red-600/20'
                    : 'bg-white text-slate-700 border-slate-200 hover:border-red-400 hover:text-red-600 shadow-sm'
                }`}
              >
                <Trophy className={`w-3.5 h-3.5 ${isSelected ? 'text-amber-300' : 'text-slate-400'}`} />
                <span>{t.title}</span>
                {t.time && (
                  <span className={`text-[10px] font-sans font-bold px-2 py-0.5 rounded-full ${
                    isSelected ? 'bg-black/25 text-white' : 'bg-slate-100 text-slate-600'
                  }`}>
                    {t.time}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      )}

      {/* 2. ACCESS RESTRICTION BANNER */}
      {!user ? (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-6 text-center space-y-3 shadow-sm">
          <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center mx-auto">
            <Lock className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <h3 className="font-heading font-black text-slate-900 text-base">
              টুর্নামেন্ট রেজাল্ট শুধুমাত্র ক্রেতাদের জন্য উন্মুক্ত
            </h3>
            <p className="text-xs text-slate-600 max-w-sm mx-auto leading-relaxed">
              NINEX পলিসি: আপনি যে টুর্নামেন্টটি কিনবেন শুধুমাত্র সেই টুর্নামেন্টের ফলাফল দেখতে পারবেন। লগইন করে আপনার কেনা টুর্নামেন্টের রেজাল্ট দেখুন।
            </p>
          </div>
          <button
            onClick={() => setShowLoginModal(true)}
            className="mt-2 px-6 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold shadow-md shadow-red-500/20 cursor-pointer transition-colors"
          >
            লগইন করুন (LOGIN)
          </button>
        </div>
      ) : availableTournaments.length === 0 ? (
        /* User is logged in, but has not purchased any tournaments */
        <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center space-y-4 shadow-sm">
          <div className="w-14 h-14 rounded-2xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center mx-auto shadow-sm">
            <Lock className="w-7 h-7" />
          </div>
          <div className="space-y-1.5">
            <span className="text-[10px] font-black tracking-widest text-amber-600 uppercase">
              NO PURCHASED MATCHES
            </span>
            <h3 className="font-heading font-black text-slate-950 text-base">
              আপনার কোনো কেনা টুর্নামেন্ট নেই
            </h3>
            <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
              আপনি যে টুর্নামেন্টটি কিনবেন, শুধুমাত্র সেই টুর্নামেন্টের রেজাল্ট আপনাকে দেখানো হবে। আপনি যেগুলো কিনেননি, সেগুলোর কোনো রেজাল্ট আপনার এখানে দেখানো হবে না।
            </p>
          </div>
          {setActiveTab && (
            <button
              onClick={() => setActiveTab('home')}
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold shadow-md shadow-red-500/20 cursor-pointer transition-colors"
            >
              <span>টুর্নামেন্ট দেখুন ও কিনুন (Play)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      ) : null}

      {/* 5. USER'S OWN TEAM HIGHLIGHT CARD (IF PRESENT IN STANDINGS) */}
      {userTeamResult && (
        <div className="bg-gradient-to-r from-red-600 via-red-700 to-amber-600 text-white rounded-2xl p-4 shadow-lg shadow-red-500/20 space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-amber-300" />
              <span className="font-heading font-black text-xs uppercase tracking-wider text-amber-200">
                আপনার দলের পারফরম্যান্স (YOUR SQUAD)
              </span>
            </div>
            <span className="px-2.5 py-0.5 rounded-full bg-white/20 text-white text-[10px] font-black font-mono">
              পজিশন #{userTeamResult.rank}
            </span>
          </div>

          <div className="flex items-center justify-between pt-1">
            <div>
              <h3 className="font-heading text-lg font-black leading-tight">
                {userTeamResult.teamName || user?.teamName || 'আপনার স্কোয়াড'}
              </h3>
              <p className="text-xs text-white/80 font-mono mt-0.5">
                ক্যাপ্টেন: {userTeamResult.playerName}
              </p>
            </div>

            <div className="text-right">
              {isCSorLoneWolf ? (
                <>
                  <span className="text-xs font-bold text-amber-200 block font-mono">
                    ম্যাচ: {userTeamResult.matchesPlayed ?? 1}
                  </span>
                  <span className="font-heading font-black text-2xl text-white block mt-0.5">
                    👑 {userTeamResult.booyahs ?? (userTeamResult.rank === 1 ? 1 : 0)} Booyah
                  </span>
                </>
              ) : (
                <>
                  <span className="text-xs font-bold text-amber-200 block font-mono">
                    {userTeamResult.kills} Kills • {userTeamResult.placementPoints} Place PTS
                  </span>
                  <span className="font-heading font-black text-2xl text-white block mt-0.5">
                    {userTeamResult.totalPoints} PTS
                  </span>
                </>
              )}
              {userTeamResult.prizeWon ? (
                <span className="text-[11px] font-black text-emerald-200 bg-white/10 px-2 py-0.5 rounded-md inline-block mt-0.5">
                  পুরস্কার: ৳{userTeamResult.prizeWon}
                </span>
              ) : null}
            </div>
          </div>
        </div>
      )}

      {/* 6. CHAMPION / PODIUM SECTION */}
      {sortedStandings.length > 0 && (
        isCSorLoneWolf ? (
          /* ======================================================== */
          /* CS 4V4 & LONE WOLF: ONLY CHAMPION (NO RUNNER-UP, NO 3RD)  */
          /* ======================================================== */
          top1 && (
            <div className="max-w-md mx-auto w-full pt-1">
              <div className="bg-gradient-to-b from-amber-500/10 via-white to-white rounded-2xl border-2 border-red-600 p-5 shadow-lg shadow-red-500/10 text-center relative overflow-hidden">
                <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-amber-400 via-red-600 to-amber-400"></div>
                
                <div className="flex justify-center items-center">
                  <span className="bg-red-600 text-white px-4 py-1 rounded-full text-xs font-black uppercase tracking-widest shadow-sm inline-flex items-center gap-1.5">
                    <Crown className="w-3.5 h-3.5 text-amber-300" />
                    <span>Champion</span>
                  </span>
                </div>

                <div className="w-14 h-14 rounded-2xl bg-amber-50 border-2 border-amber-300 flex items-center justify-center mx-auto my-3 text-amber-500 shadow-inner">
                  <Trophy className="w-7 h-7 text-amber-500" />
                </div>

                <h3 className="text-lg font-black text-slate-950 font-heading">
                  {top1.teamName || 'Squad Team'}
                </h3>
                {top1.playerName && (
                  <p className="text-xs text-slate-500 font-mono mt-0.5">
                    Player: {top1.playerName}
                  </p>
                )}

                {/* CS 4V4 / LONE WOLF STATS: ONLY BOOYAH & MATCH */}
                <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-slate-100 font-mono">
                  <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200">
                    <span className="text-[10px] uppercase font-bold text-amber-800 block font-sans">
                      সর্বোচ্চ BOOYAH
                    </span>
                    <span className="text-base font-black text-amber-700 block mt-0.5">
                      👑 {top1.booyahs ?? 1} Booyah
                    </span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                    <span className="text-[10px] uppercase font-bold text-slate-600 block font-sans">
                      ম্যাচ সংখ্যা
                    </span>
                    <span className="text-base font-black text-slate-900 block mt-0.5">
                      {top1.matchesPlayed ?? 1} Match
                    </span>
                  </div>
                </div>

                {top1.prizeWon ? (
                  <div className="mt-3 py-1.5 px-3 rounded-xl bg-emerald-50 border border-emerald-200 inline-block font-mono">
                    <span className="text-xs font-bold text-emerald-800">
                      পুরস্কার: <strong className="text-sm font-black text-emerald-600">৳{top1.prizeWon}</strong>
                    </span>
                  </div>
                ) : null}
              </div>
            </div>
          )
        ) : (
          /* ======================================================== */
          /* STANDARD BR: TOP 3 PODIUM (CHAMPION, RUNNER-UP, 3RD)     */
          /* ======================================================== */
          <div className="grid grid-cols-3 gap-2 sm:gap-3 pt-2">
            
            {/* #2 Runner up */}
            {top2 ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-3 shadow-sm text-center flex flex-col justify-between order-1">
                <div>
                  <span className="font-heading font-black text-[11px] text-slate-400 block tracking-wider uppercase">
                    RUNNER UP
                  </span>
                  <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center mx-auto my-2 text-slate-600 font-black ring-2 ring-slate-200">
                    <Medal className="w-5 h-5 text-slate-500" />
                  </div>
                  <div className="py-1">
                    <span className="text-xs font-black text-slate-900 block truncate">
                      {top2.teamName || 'Squad Team'}
                    </span>
                  </div>
                </div>
                <div className="pt-2 border-t border-slate-100 mt-2 font-mono text-center space-y-0.5">
                  <div className="text-[11px] font-bold text-slate-600">
                    মোট পয়েন্ট: <span className="font-black text-xs text-slate-900">{top2.totalPoints} PTS</span>
                  </div>
                  <div className="text-[11px] font-bold text-slate-600">
                    Prize: <span className="font-black text-emerald-600">{top2.prizeWon ? `৳${top2.prizeWon}` : '৳0'}</span>
                  </div>
                </div>
              </div>
            ) : <div className="order-1" />}

            {/* #1 Champion */}
            {top1 && (
              <div className="bg-white rounded-2xl border-2 border-red-600 p-3.5 shadow-md shadow-red-600/10 text-center flex flex-col justify-between order-2 -mt-2">
                <div>
                  <div className="flex justify-center items-center">
                    <span className="bg-red-600 text-white px-3.5 py-1 rounded-full text-xs font-black uppercase tracking-wider shadow-sm">
                      Champion
                    </span>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-amber-50 flex items-center justify-center mx-auto my-2 text-amber-500 ring-2 ring-amber-300">
                    <Trophy className="w-6 h-6" />
                  </div>
                  <div className="py-1">
                    <span className="text-xs sm:text-sm font-black text-slate-900 block truncate">
                      {top1.teamName || 'Squad Team'}
                    </span>
                  </div>
                </div>
                <div className="pt-2 border-t border-red-100 mt-2 font-mono text-center space-y-0.5">
                  <div className="text-xs font-bold text-slate-700">
                    মোট পয়েন্ট: <span className="font-black text-sm text-red-600">{top1.totalPoints} PTS</span>
                  </div>
                  <div className="text-xs font-bold text-slate-700">
                    Prize: <span className="font-black text-emerald-600">{top1.prizeWon ? `৳${top1.prizeWon}` : '৳0'}</span>
                  </div>
                </div>
              </div>
            )}

            {/* #3 3rd place */}
            {top3 ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-3 shadow-sm text-center flex flex-col justify-between order-3">
                <div>
                  <span className="font-heading font-black text-[11px] text-amber-700 block tracking-wider uppercase">
                    3RD PLACE
                  </span>
                  <div className="w-10 h-10 rounded-full bg-amber-50 flex items-center justify-center mx-auto my-2 text-amber-700 font-black ring-2 ring-amber-200">
                    <Medal className="w-5 h-5 text-amber-600" />
                  </div>
                  <div className="py-1">
                    <span className="text-xs font-black text-slate-900 block truncate">
                      {top3.teamName || 'Squad Team'}
                    </span>
                  </div>
                </div>
                <div className="pt-2 border-t border-slate-100 mt-2 font-mono text-center space-y-0.5">
                  <div className="text-[11px] font-bold text-slate-600">
                    মোট পয়েন্ট: <span className="font-black text-xs text-slate-900">{top3.totalPoints} PTS</span>
                  </div>
                  <div className="text-[11px] font-bold text-slate-600">
                    Prize: <span className="font-black text-emerald-600">{top3.prizeWon ? `৳${top3.prizeWon}` : '৳0'}</span>
                  </div>
                </div>
              </div>
            ) : <div className="order-3" />}

          </div>
        )
      )}

      {/* 8. POINT TABLE & STANDINGS */}
      {sortedStandings.length > 0 && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-3.5 bg-slate-900 text-white flex justify-between items-center border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Trophy className="w-4 h-4 text-amber-400" />
              <span className="font-heading font-black text-xs tracking-wider uppercase text-amber-300">
                {isCSorLoneWolf ? 'CS 4V4 / LONE WOLF STANDINGS' : 'OFFICIAL POINT TABLE & STANDINGS'}
              </span>
            </div>
            <span className="text-[10px] font-mono text-slate-300 bg-slate-800 px-2 py-0.5 rounded">
              {isCSorLoneWolf ? `${sortedStandings.length} টিম (সর্বোচ্চ Booyah = Champion)` : `${sortedStandings.length} টিম র‍্যাংকিং`}
            </span>
          </div>

          <div className="overflow-x-auto">
            {isCSorLoneWolf ? (
              /* ======================================================== */
              /* CS 4V4 & LONE WOLF TABLE: ONLY BOOYAH & MATCH           */
              /* ======================================================== */
              <table className="w-full text-left text-xs font-bangla border-collapse">
                <thead className="bg-slate-100/90 text-slate-600 uppercase text-[10px] font-black border-b border-slate-200 tracking-wider">
                  <tr>
                    <th className="py-2.5 px-3 text-center w-12">#</th>
                    <th className="py-2.5 px-3">TEAM / SQUAD</th>
                    <th className="py-2.5 px-3 text-center">MATCH</th>
                    <th className="py-2.5 px-3 text-center bg-amber-500/10 text-amber-900 font-black">👑 BOOYAH</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  {sortedStandings.map((res, index) => {
                    const rankNum = res.rank || index + 1;
                    const isFirst = rankNum === 1;
                    const matches = res.matchesPlayed ?? 1;
                    const booyahs = res.booyahs ?? (rankNum === 1 ? 1 : 0);
                    const isUser = isUserSquad(res);

                    return (
                      <tr 
                        key={res.id} 
                        className={`hover:bg-slate-50 transition-colors ${
                          isUser 
                            ? 'bg-amber-100/70 border-y-2 border-amber-400 font-bold' 
                            : isFirst 
                            ? 'bg-amber-50/60 font-bold' 
                            : ''
                        }`}
                      >
                        {/* Rank */}
                        <td className="py-3 px-3 text-center">
                          <span className={`w-6 h-6 mx-auto rounded-lg font-heading font-black text-xs flex items-center justify-center ${
                            isFirst
                              ? 'bg-amber-500 text-white shadow-sm ring-1 ring-amber-300'
                              : isUser
                              ? 'bg-red-600 text-white'
                              : 'bg-slate-100 text-slate-600'
                          }`}>
                            {rankNum}
                          </span>
                        </td>

                        {/* Team & Player */}
                        <td className="py-3 px-3 font-bangla">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className={`text-xs block truncate max-w-[160px] ${
                              isUser ? 'font-black text-red-700' : isFirst ? 'font-black text-slate-950' : 'font-bold text-slate-800'
                            }`}>
                              {res.teamName || 'Solo Squad'}
                            </span>
                            {isFirst && (
                              <span className="px-2 py-0.5 rounded-full bg-red-600 text-white text-[9px] font-black uppercase tracking-wider shrink-0 flex items-center gap-0.5 shadow-sm">
                                👑 Champion
                              </span>
                            )}
                            {isUser && !isFirst && (
                              <span className="px-1.5 py-0.2 rounded bg-red-600 text-white text-[9px] font-black shrink-0">
                                আপনার টিম
                              </span>
                            )}
                          </div>
                          {res.playerName && (
                            <div className="text-[10px] text-slate-500 mt-0.5 truncate max-w-[160px]">
                              {res.playerName}
                            </div>
                          )}
                        </td>

                        {/* Matches */}
                        <td className="py-3 px-3 text-center text-slate-700 text-xs font-bold font-mono">
                          {matches}
                        </td>

                        {/* Booyah */}
                        <td className="py-3 px-3 text-center bg-amber-500/10 font-bold">
                          {booyahs > 0 ? (
                            <span className="text-amber-700 font-black text-sm inline-flex items-center gap-1">
                              👑 {booyahs}
                            </span>
                          ) : (
                            <span className="text-slate-400 text-xs">0</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            ) : (
              /* ======================================================== */
              /* STANDARD BR TOURNAMENT TABLE                            */
              /* ======================================================== */
              <table className="w-full text-left text-xs font-bangla border-collapse">
                <thead className="bg-slate-100/90 text-slate-600 uppercase text-[10px] font-black border-b border-slate-200 tracking-wider">
                  <tr>
                    <th className="py-2.5 px-3 text-center w-10">#</th>
                    <th className="py-2.5 px-3">TEAM / SQUAD</th>
                    <th className="py-2.5 px-2 text-center">MATCH</th>
                    <th className="py-2.5 px-2 text-center">👑 BOOYAH</th>
                    <th className="py-2.5 px-2 text-center">PLACE PTS</th>
                    <th className="py-2.5 px-2 text-center text-red-600">KILL PTS</th>
                    <th className="py-2.5 px-3 text-center bg-amber-500/10 text-amber-900 font-black">TOTAL PTS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  {sortedStandings.map((res, index) => {
                    const rankNum = res.rank || index + 1;
                    const isFirst = rankNum === 1;
                    const isSecond = rankNum === 2;
                    const isThird = rankNum === 3;
                    const matches = res.matchesPlayed ?? 1;
                    const booyahs = res.booyahs ?? (rankNum === 1 ? 1 : 0);
                    const placePts = res.placementPoints;
                    const killPts = res.kills * 1;
                    const totalPts = res.totalPoints;
                    const isUser = isUserSquad(res);

                    return (
                      <tr 
                        key={res.id} 
                        className={`hover:bg-slate-50 transition-colors ${
                          isUser 
                            ? 'bg-amber-100/70 border-y-2 border-amber-400 font-bold' 
                            : isFirst 
                            ? 'bg-amber-50/50' 
                            : ''
                        }`}
                      >
                        {/* Rank */}
                        <td className="py-3 px-3 text-center">
                          <span className={`w-6 h-6 mx-auto rounded-lg font-heading font-black text-xs flex items-center justify-center ${
                            isFirst
                              ? 'bg-amber-500 text-white shadow-sm ring-1 ring-amber-300'
                              : isSecond
                              ? 'bg-slate-300 text-slate-800'
                              : isThird
                              ? 'bg-amber-700 text-white'
                              : isUser
                              ? 'bg-red-600 text-white'
                              : 'bg-slate-100 text-slate-600'
                          }`}>
                            {rankNum}
                          </span>
                        </td>

                        {/* Team & Player */}
                        <td className="py-3 px-3 font-bangla">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className={`text-xs block truncate max-w-[140px] ${isUser ? 'font-black text-red-700' : 'font-black text-slate-900'}`}>
                              {res.teamName || 'Solo Squad'}
                            </span>
                            {isUser && (
                              <span className="px-1.5 py-0.2 rounded bg-red-600 text-white text-[9px] font-black shrink-0">
                                আপনার টিম
                              </span>
                            )}
                            {isFirst && !isUser && <span className="text-[10px] text-amber-600 font-black shrink-0">👑</span>}
                          </div>
                          {res.playerName && (
                            <div className="text-[10px] text-slate-500 mt-0.5 truncate max-w-[140px]">
                              {res.playerName}
                            </div>
                          )}
                        </td>

                        {/* Matches */}
                        <td className="py-3 px-2 text-center text-slate-600 text-xs font-bold">
                          {matches}
                        </td>

                        {/* Booyah */}
                        <td className="py-3 px-2 text-center font-bold">
                          {booyahs > 0 ? (
                            <span className="text-amber-600 font-black text-xs inline-flex items-center gap-0.5">
                              👑 {booyahs}
                            </span>
                          ) : (
                            <span className="text-slate-300 text-xs">0</span>
                          )}
                        </td>

                        {/* Placement Points */}
                        <td className="py-3 px-2 text-center font-bold text-slate-700 text-xs">
                          {placePts}
                        </td>

                        {/* Kill Points */}
                        <td className="py-3 px-2 text-center font-bold text-red-600 text-xs">
                          {killPts}
                        </td>

                        {/* Total Points */}
                        <td className="py-3 px-3 text-center bg-amber-500/10 font-heading font-black text-sm text-slate-950">
                          {totalPts}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </div>
      )}

      {/* NO RESULTS YET FOR ACTIVE SELECTION */}
      {availableTournaments.length > 0 && sortedStandings.length === 0 && (
        <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-500 space-y-2 shadow-sm">
          <Trophy className="w-8 h-8 text-slate-300 mx-auto" />
          <p className="text-xs font-bold text-slate-700">
            {currentTournament ? `${currentTournament.title} (${currentTournament.time}) এর পয়েন্ট এখনও যোগ করা হয়নি।` : 'এই টুর্নামেন্টে এখনও কোনো পয়েন্ট যোগ করা হয়নি।'}
          </p>
          <p className="text-[11px] text-slate-400">
            ম্যাচ সম্পন্ন হলে এবং এডমিন পয়েন্ট সাবমিট করলে এখানে আপনার কেনা ম্যাচের পূর্ণাঙ্গ পয়েন্ট টেবিল ভেসে উঠবে।
          </p>
        </div>
      )}

    </div>
  );
};
