import React, { useState } from 'react';
import { Search, Filter, Swords, MapPin, Trophy, Shield, RefreshCw } from 'lucide-react';
import { useTournaments } from '../context/TournamentContext';
import { TournamentCard } from '../components/TournamentCard';
import { Tournament } from '../types';

interface TournamentsProps {
  onSelectTournament?: (tournament: Tournament) => void;
  onJoinTournament: (tournament: Tournament) => void;
  onOpenRoomId?: (tournament: Tournament) => void;
  onOpenPrizeList?: (tournament: Tournament) => void;
}

export const Tournaments: React.FC<TournamentsProps> = ({
  onSelectTournament,
  onJoinTournament,
  onOpenRoomId,
  onOpenPrizeList,
}) => {
  const { tournaments, refreshData } = useTournaments();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMode, setSelectedMode] = useState<string>('ALL');
  const [selectedMap, setSelectedMap] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');

  const filteredTournaments = tournaments.filter(t => {
    // Search
    const matchesSearch = t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          t.map.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Mode
    const matchesMode = selectedMode === 'ALL' || t.mode.toUpperCase() === selectedMode;

    // Map
    const matchesMap = selectedMap === 'ALL' || t.map.toUpperCase() === selectedMap;

    // Status
    const matchesStatus = selectedStatus === 'ALL' || 
      (selectedStatus === 'ACTIVE' && (t.status === 'OPEN' || t.status === 'ALMOST_FULL')) ||
      (selectedStatus === 'LIVE' && t.status === 'LIVE') ||
      (selectedStatus === 'COMPLETED' && t.status === 'COMPLETED');

    return matchesSearch && matchesMode && matchesMap && matchesStatus;
  });

  return (
    <div className="space-y-6 pb-12">
      
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest">
            BANGLADESH COMPETITIVE CIRCUIT
          </span>
          <h1 className="font-heading text-3xl sm:text-4xl font-black text-white">
            ALL TOURNAMENTS & SCRIMS
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Choose your match, book your slot, and battle for the Booyah prize pool.
          </p>
        </div>

        <button
          onClick={refreshData}
          className="self-start sm:self-auto flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 font-semibold cursor-pointer transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5 text-cyan-400" />
          <span>Refresh List</span>
        </button>
      </div>

      {/* Filter and Search Controls Bar */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
        {/* Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by tournament name or map (e.g. Bermuda, Dhaka Championship)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder:text-slate-500 text-sm focus:outline-none focus:border-cyan-500 transition-colors"
          />
        </div>

        {/* Filter Chips */}
        <div className="flex flex-wrap items-center gap-3 pt-1 border-t border-slate-800/60">
          {/* Mode Selector */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            <span className="text-[11px] font-bold text-slate-500 uppercase mr-1">Mode:</span>
            {['ALL', 'SOLO', 'DUO', 'SQUAD'].map(mode => (
              <button
                key={mode}
                onClick={() => setSelectedMode(mode)}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  selectedMode === mode
                    ? 'bg-cyan-500 text-black shadow-md shadow-cyan-500/20'
                    : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {mode}
              </button>
            ))}
          </div>

          {/* Map Selector */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            <span className="text-[11px] font-bold text-slate-500 uppercase mr-1">Map:</span>
            {['ALL', 'BERMUDA', 'PURGATORY', 'KALAHARI', 'ALPINE', 'NEXTERRA'].map(mapName => (
              <button
                key={mapName}
                onClick={() => setSelectedMap(mapName)}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  selectedMap === mapName
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {mapName}
              </button>
            ))}
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            <span className="text-[11px] font-bold text-slate-500 uppercase mr-1">Status:</span>
            {[
              { id: 'ALL', label: 'All' },
              { id: 'ACTIVE', label: 'Open' },
              { id: 'LIVE', label: 'Live' },
              { id: 'COMPLETED', label: 'Finished' },
            ].map(s => (
              <button
                key={s.id}
                onClick={() => setSelectedStatus(s.id)}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  selectedStatus === s.id
                    ? 'bg-emerald-500 text-black shadow-md'
                    : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Results Count */}
      <div className="flex items-center justify-between text-xs text-slate-400 px-1">
        <span>Showing <strong className="text-white">{filteredTournaments.length}</strong> tournaments</span>
      </div>

      {/* Tournament Cards Grid */}
      {filteredTournaments.length === 0 ? (
        <div className="text-center py-16 p-8 rounded-3xl bg-slate-900/40 border border-slate-800/80">
          <Swords className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="font-heading text-xl font-bold text-white">No Tournaments Found</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            No scrims match your current filter settings. Try resetting your search query or mode filters.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedMode('ALL');
              setSelectedMap('ALL');
              setSelectedStatus('ALL');
            }}
            className="mt-4 px-4 py-2 rounded-xl bg-cyan-500 text-black font-bold text-xs cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredTournaments.map(tournament => (
            <TournamentCard
              key={tournament.id}
              tournament={tournament}
              onSelect={onSelectTournament}
              onJoin={onJoinTournament}
              onOpenRoomId={onOpenRoomId || onJoinTournament}
              onOpenPrizeList={onOpenPrizeList || onJoinTournament}
            />
          ))}
        </div>
      )}

    </div>
  );
};
