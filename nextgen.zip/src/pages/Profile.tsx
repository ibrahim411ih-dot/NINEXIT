import React, { useState } from 'react';
import { Edit2, Check, AlertCircle, CheckCircle2, Shield, User, Gamepad2, Phone, Users } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { isUserProfileComplete } from '../types';

interface ProfileProps {
  setActiveTab: (tab: string) => void;
  onOpenWallet?: () => void;
}

export const Profile: React.FC<ProfileProps> = ({ setActiveTab }) => {
  const { user, isAdmin, updateProfile, logout, setShowLoginModal } = useAuth();

  const [isEditing, setIsEditing] = useState(() => !isUserProfileComplete(user));
  const [ffUid, setFfUid] = useState(user?.ffUid || '');
  const [ffNickname, setFfNickname] = useState(user?.ffNickname || '');
  const [teamName, setTeamName] = useState(user?.teamName || '');
  const [bkashNumber, setBkashNumber] = useState(user?.bkashNumber || user?.phone || '');
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Sync state if user changes
  React.useEffect(() => {
    if (user) {
      setFfUid(user.ffUid || '');
      setFfNickname(user.ffNickname || '');
      setTeamName(user.teamName || '');
      setBkashNumber(user.bkashNumber || user.phone || '');
      if (!isUserProfileComplete(user)) {
        setIsEditing(true);
      }
    }
  }, [user]);

  if (!user) {
    return (
      <div className="max-w-xl mx-auto text-center py-16 p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4 font-bangla">
        <h2 className="font-heading text-xl font-black text-slate-900">
          প্রোফাইল দেখতে লগইন করুন
        </h2>
        <p className="text-xs text-slate-500 leading-relaxed">
          আপনার ফ্রি ফায়ার UID, ইন-গেম নাম, টিম নেম ও বিকাশ নম্বর দেখতে অনুগ্রহ করে লগইন করুন।
        </p>
        <button
          onClick={() => setShowLoginModal(true)}
          className="py-2.5 px-6 rounded-lg bg-red-600 hover:bg-red-700 text-white font-black text-xs uppercase tracking-wide cursor-pointer"
        >
          লগইন করুন (LOGIN)
        </button>
      </div>
    );
  }

  const isComplete = isUserProfileComplete(user);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!ffNickname.trim()) {
      setErrorMsg('দয়া করে আপনার গেম নাম (IGN) লিখুন।');
      return;
    }
    if (!ffUid.trim() || ffUid.length < 5) {
      setErrorMsg('সঠিক ফ্রি ফায়ার গেম UID দিন (কমপক্ষে ৫ সংখ্যা)।');
      return;
    }
    if (!teamName.trim()) {
      setErrorMsg('দয়া করে আপনার টিম নেম (Team Name) লিখুন।');
      return;
    }
    if (!bkashNumber.trim() || bkashNumber.length < 11) {
      setErrorMsg('১১ সংখ্যার সঠিক বিকাশ বা নগদ নম্বর দিন।');
      return;
    }

    updateProfile({
      ffUid: ffUid.trim(),
      ffNickname: ffNickname.trim(),
      teamName: teamName.trim(),
      bkashNumber: bkashNumber.trim(),
      phone: bkashNumber.trim(),
    });

    setIsEditing(false);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  return (
    <div className="max-w-xl mx-auto space-y-4 pb-20 font-bangla text-slate-800">
      
      {/* Profile Completeness Alert Banner */}
      {!isComplete ? (
        <div className="p-4 rounded-2xl bg-amber-50 border-2 border-amber-300 text-amber-900 space-y-1.5 shadow-sm">
          <div className="flex items-center gap-2 font-black text-sm">
            <AlertCircle className="w-5 h-5 text-amber-600 shrink-0" />
            <span>প্রোফাইল অসম্পূর্ণ! টুর্নামেন্ট কিনতে আগে পূরণ করুন</span>
          </div>
          <p className="text-xs text-amber-800 leading-relaxed">
            টুর্নামেন্ট কিনতে হলে আপনার <strong>গেম নাম</strong>, <strong>গেম UID</strong>, <strong>TEAM NAME</strong> এবং <strong>bKash/Nagad number</strong> অবশ্যই প্রোফাইলে পূরণ করতে হবে।
          </p>
        </div>
      ) : (
        <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center justify-between shadow-sm">
          <div className="flex items-center gap-2 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>প্রোফাইল সম্পূর্ণ! আপনি এখন টুর্নামেন্টে জয়েন করতে পারবেন।</span>
          </div>
          <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-emerald-100 text-emerald-700">
            Verified
          </span>
        </div>
      )}

      {/* Main Profile Info Card */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 space-y-4">
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3.5">
            {/* User Name Initial Avatar */}
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-red-600 to-slate-900 text-white font-heading font-black text-2xl flex items-center justify-center shadow-md uppercase ring-2 ring-red-600/30 shrink-0">
              {user.displayName?.trim().charAt(0).toUpperCase() || 'U'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-heading font-black text-lg text-slate-900">
                  {user.displayName}
                </h1>
                {isAdmin && (
                  <span className="px-2 py-0.5 rounded text-[10px] font-black bg-red-100 text-red-700 border border-red-200">
                    Admin
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 font-mono mt-0.5">
                মোবাইল: <span className="font-bold text-slate-900">{user.phone || 'N/A'}</span>
              </p>
            </div>
          </div>

          {!isEditing && (
            <button
              onClick={() => setIsEditing(true)}
              className="flex items-center gap-1 py-1.5 px-3 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 text-xs font-bold transition-colors cursor-pointer border border-red-200"
            >
              <Edit2 className="w-3.5 h-3.5" />
              <span>এডিট</span>
            </button>
          )}
        </div>

        {/* Save success toast */}
        {saveSuccess && (
          <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs flex items-center gap-2">
            <Check className="w-4 h-4" />
            <span>প্রোফাইল সফলভাবে আপডেট হয়েছে!</span>
          </div>
        )}

        {/* Display Current Profile Details or Edit Form */}
        {!isEditing ? (
          <div className="grid grid-cols-2 gap-3 pt-3 border-t border-slate-100 text-xs">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-[10px] font-bold text-slate-500 uppercase block">গেম নাম (IGN)</span>
              <span className="font-heading font-black text-sm text-slate-900 mt-0.5 block truncate">
                {user.ffNickname || <span className="text-amber-600">খালি (পূরণ করুন)</span>}
              </span>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-[10px] font-bold text-slate-500 uppercase block">গেম UID</span>
              <span className="font-mono font-bold text-sm text-slate-900 mt-0.5 block">
                {user.ffUid || <span className="text-amber-600">খালি (পূরণ করুন)</span>}
              </span>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-[10px] font-bold text-slate-500 uppercase block">TEAM NAME</span>
              <span className="font-bold text-sm text-slate-900 mt-0.5 block truncate">
                {user.teamName || <span className="text-amber-600">খালি (পূরণ করুন)</span>}
              </span>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-[10px] font-bold text-slate-500 uppercase block">bKash / Nagad Number</span>
              <span className="font-mono font-bold text-sm text-slate-900 mt-0.5 block">
                {user.bkashNumber || user.phone || <span className="text-amber-600">খালি (পূরণ করুন)</span>}
              </span>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSaveProfile} className="pt-3 border-t border-slate-100 space-y-3">
            <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-600">
              টুর্নামেন্ট কিনতে হলে নিচের ৪টি তথ্য পূরণ করে <strong>তথ্য সংরক্ষণ করুন</strong> বাটনে ক্লিক করুন।
            </div>

            {errorMsg && (
              <div className="p-2.5 rounded-lg bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* 1. Game Nickname */}
            <div>
              <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1 flex items-center gap-1.5">
                <Gamepad2 className="w-3.5 h-3.5 text-red-600" />
                ১. গেম নাম (In-Game Nickname / IGN) *
              </label>
              <input
                type="text"
                required
                placeholder="যেমন: 亗 DARK_KILLER 亗"
                value={ffNickname}
                onChange={(e) => setFfNickname(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs text-slate-900 focus:outline-none focus:border-red-600 focus:ring-1 focus:ring-red-600"
              />
            </div>

            {/* 2. Free Fire UID */}
            <div>
              <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-red-600" />
                ২. গেম UID (Free Fire UID) *
              </label>
              <input
                type="text"
                required
                placeholder="যেমন: 2948291048"
                value={ffUid}
                onChange={(e) => setFfUid(e.target.value.replace(/[^0-9]/g, ''))}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 font-mono text-xs text-slate-900 focus:outline-none focus:border-red-600 focus:ring-1 focus:ring-red-600"
              />
            </div>

            {/* 3. Team Name */}
            <div>
              <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-red-600" />
                ৩. TEAM NAME (টিমের নাম) *
              </label>
              <input
                type="text"
                required
                placeholder="যেমন: NINEX Esports / Delta BD"
                value={teamName}
                onChange={(e) => setTeamName(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs text-slate-900 focus:outline-none focus:border-red-600 focus:ring-1 focus:ring-red-600"
              />
            </div>

            {/* 4. bKash / Nagad Number */}
            <div>
              <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-red-600" />
                ৪. bKash / Nagad Number (বিকাশ বা নগদ নম্বর) *
              </label>
              <input
                type="tel"
                required
                placeholder="01XXXXXXXXX"
                value={bkashNumber}
                onChange={(e) => setBkashNumber(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 font-mono text-xs text-slate-900 focus:outline-none focus:border-red-600 focus:ring-1 focus:ring-red-600"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              {isComplete && (
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold cursor-pointer"
                >
                  বাতিল
                </button>
              )}
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-black uppercase tracking-wider cursor-pointer shadow-md"
              >
                তথ্য সংরক্ষণ করুন (SAVE PROFILE)
              </button>
            </div>
          </form>
        )}

      </div>

      {/* Actions & Logout */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 space-y-2.5">
        {isAdmin && (
          <button
            onClick={() => setActiveTab('admin')}
            className="w-full py-2.5 px-3 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 text-xs font-bold text-left border border-amber-200 cursor-pointer flex items-center justify-between"
          >
            <span>Open Admin Dashboard (অ্যাডমিন প্যানেল)</span>
            <Shield className="w-4 h-4 text-amber-600" />
          </button>
        )}

        <button
          onClick={logout}
          className="w-full py-2.5 px-3 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 text-xs font-bold text-left cursor-pointer"
        >
          Logout (সাইন আউট)
        </button>
      </div>

    </div>
  );
};
