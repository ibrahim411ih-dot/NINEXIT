import React, { useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import { useTournaments } from '../context/TournamentContext';
import { TournamentCard } from '../components/TournamentCard';
import { Tournament } from '../types';

interface HomeProps {
  onSelectTournament: (tournament: Tournament) => void;
  onJoinTournament: (tournament: Tournament) => void;
  onOpenRoomId: (tournament: Tournament) => void;
  onOpenPrizeList: (tournament: Tournament) => void;
  setActiveTab: (tab: string) => void;
  onOpenWallet?: () => void;
}

export const Home: React.FC<HomeProps> = ({
  onJoinTournament,
  onOpenRoomId,
  onOpenPrizeList,
}) => {
  const { tournaments } = useTournaments();

  // Mode view state: null = categories grid (Opens by default on entering Play/Home)
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  // The 6 exact categories requested by the user
  const requestedCategories = [
    {
      id: 'BR SCRIM',
      title: 'BR SCRIM',
      subtitle: 'BR SCRIM',
      imageUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=500&q=80',
    },
    {
      id: 'BR BLAST',
      title: 'BR BLAST',
      subtitle: 'BR BLAST',
      imageUrl: 'https://images.unsplash.com/photo-1579373903781-fd5c0c30c4cd?auto=format&fit=crop&w=500&q=80',
    },
    {
      id: 'BR CHAMPION RUSH',
      title: 'BR CHAMPION RUSH',
      subtitle: 'BR CHAMPION RUSH',
      imageUrl: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=500&q=80',
    },
    {
      id: 'CS 4V4',
      title: 'CS 4V4',
      subtitle: 'CS 4V4',
      imageUrl: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=500&q=80',
    },
    {
      id: 'LONE WOLF',
      title: 'LONE WOLF',
      subtitle: 'LONE WOLF',
      imageUrl: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=500&q=80',
    },
    {
      id: 'FREE MATCH',
      title: 'FREE MATCH',
      subtitle: 'FREE MATCH',
      imageUrl: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?auto=format&fit=crop&w=500&q=80',
    },
  ];

  // Helper to count matches in category
  const getCategoryCount = (catId: string) => {
    const count = tournaments.filter(t => t.matchCategory === catId).length;
    return `${count} match${count === 1 ? '' : 'es'} found`;
  };

  // Matches for current category
  const activeMatches = tournaments.filter(t => {
    if (!selectedCategory) return true;
    return t.matchCategory === selectedCategory;
  });

  return (
    <div className="max-w-xl mx-auto space-y-4 pb-20 font-bangla text-slate-800">
      
      {/* Notice / Scrolling Ticker (Top Banner) */}
      <div className="bg-red-50 border-y border-red-200 py-1.5 px-3 text-xs text-red-700 font-semibold overflow-hidden flex items-center gap-2">
        <span className="shrink-0 bg-red-600 text-white text-[10px] font-black px-1.5 py-0.5 rounded">
          নোটিশ
        </span>
        <div className="truncate text-[11px] sm:text-xs">
          NINEX টুর্নামেন্টে স্বাগতম! রুম আইডি ও পাসওয়ার্ড ম্যাচ শুরুর ১৫ মিনিট আগে My Matches অপশনে দেওয়া হবে।
        </div>
      </div>

      {/* VIEW 1: CATEGORY SELECTION MENU (OPENS ON HOME / PLAY BY DEFAULT) */}
      {!selectedCategory ? (
        <div className="space-y-4 px-1">
          {/* Section Title */}
          <div className="text-center py-1">
            <h2 className="font-heading font-black text-xl text-slate-900 tracking-wider">
              FREE FIRE TOURNAMENTS
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              পছন্দের ক্যাটাগরি বেছে নিন এবং ম্যাচে জয়েন করুন
            </p>
          </div>

          {/* 6 Categories in 2-Column Mobile Grid (Matches Screenshot 1 layout) */}
          <div className="grid grid-cols-2 gap-3 sm:gap-4">
            {requestedCategories.map(cat => (
              <div
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className="bg-white rounded-2xl border-2 border-slate-300 hover:border-red-600 shadow-sm overflow-hidden cursor-pointer transition-all active:scale-98 group flex flex-col justify-between"
              >
                {/* Clean Artwork Image */}
                <div className="h-28 sm:h-36 w-full overflow-hidden bg-slate-100">
                  <img
                    src={cat.imageUrl}
                    alt={cat.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>

                {/* Category Title & Matches count */}
                <div className="p-2.5 sm:p-3 text-center bg-white border-t border-slate-100">
                  <span className="font-heading font-black text-xs sm:text-sm text-slate-900 block truncate tracking-wide">
                    {cat.title}
                  </span>
                  <span className="text-[11px] font-bold text-red-600 block mt-0.5 font-sans">
                    {getCategoryCount(cat.id)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* VIEW 2: MATCH LIST FOR SELECTED CATEGORY (MATCHES SCREENSHOT 2) */
        <div className="space-y-4">
          
          {/* Header Card: Category thumbnail + Category Title + NextGen / Match */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 flex items-center justify-between">
            <div className="flex items-center gap-3.5">
              <div className="relative w-14 h-14 rounded-xl overflow-hidden bg-slate-900 border border-slate-200 shrink-0">
                <img
                  src={
                    requestedCategories.find(c => c.id === selectedCategory)?.imageUrl ||
                    "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=300&q=80"
                  }
                  alt={selectedCategory}
                  className="w-full h-full object-cover"
                />
              </div>

              <div>
                <h2 className="font-heading font-black text-lg text-slate-900 tracking-wide leading-tight">
                  {selectedCategory}
                </h2>
                <span className="text-xs text-slate-500 font-semibold block mt-0.5">
                  NINEX / Match
                </span>
              </div>
            </div>

            {/* Back button to return to categories menu */}
            <button
              onClick={() => setSelectedCategory(null)}
              className="py-1.5 px-3 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 hover:text-red-600 font-bold text-xs flex items-center gap-1 cursor-pointer transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Categories</span>
            </button>
          </div>

          {/* Quick Horizontal Categories Switcher Bar */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
            <button
              onClick={() => setSelectedCategory(null)}
              className="py-1 px-3 rounded-full text-xs font-bold bg-slate-200 text-slate-700 hover:bg-slate-300 whitespace-nowrap cursor-pointer shrink-0"
            >
              সব ক্যাটাগরি
            </button>
            {requestedCategories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`py-1 px-3 rounded-full text-xs font-bold whitespace-nowrap cursor-pointer shrink-0 transition-colors ${
                  selectedCategory === cat.id
                    ? 'bg-red-600 text-white shadow-sm'
                    : 'bg-white text-slate-700 border border-slate-200 hover:border-red-400'
                }`}
              >
                {cat.title}
              </button>
            ))}
          </div>

          {/* MATCHES LIST FOR SELECTED CATEGORY */}
          <div className="space-y-4">
            {activeMatches.length === 0 ? (
              <div className="p-8 text-center bg-white rounded-2xl border border-slate-200 text-slate-500 space-y-2">
                <p className="font-bold text-sm text-slate-700">এই ক্যাটাগরিতে বর্তমানে কোনো লাইভ ম্যাচ নেই।</p>
                <p className="text-xs text-slate-400">খুব শীঘ্রই নতুন ম্যাচ যুক্ত করা হবে।</p>
                <button
                  onClick={() => setSelectedCategory(null)}
                  className="mt-2 text-xs font-bold text-red-600 underline cursor-pointer"
                >
                  অন্যান্য ক্যাটাগরি দেখুন
                </button>
              </div>
            ) : (
              activeMatches.map(tour => (
                <TournamentCard
                  key={tour.id}
                  tournament={tour}
                  onJoin={onJoinTournament}
                  onOpenRoomId={onOpenRoomId}
                  onOpenPrizeList={onOpenPrizeList}
                />
              ))
            )}
          </div>

        </div>
      )}

    </div>
  );
};
