import React, { useState } from 'react';
import { Lock, Unlock, Copy, Check, RefreshCw, Clock, AlertTriangle, ShieldCheck, Gamepad2, Trophy } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useTournaments } from '../context/TournamentContext';
import { Tournament } from '../types';

interface MyMatchesProps {
  onSelectTournament?: (tournament: Tournament) => void;
  setActiveTab: (tab: string) => void;
}

export const MyMatches: React.FC<MyMatchesProps> = ({ setActiveTab }) => {
  const { user, setShowLoginModal } = useAuth();
  const { userRegistrations, tournaments, results, getRoomCredentials, refreshData } = useTournaments();

  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [copiedPass, setCopiedPass] = useState<string | null>(null);

  if (!user) {
    return (
      <div className="max-w-xl mx-auto text-center py-16 p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4 font-bangla">
        <h2 className="font-heading text-xl font-black text-slate-900">
          মাই ম্যাচ দেখতে লগইন করুন
        </h2>
        <p className="text-xs text-slate-500 leading-relaxed">
          আপনার জয়েন করা ম্যাচ ও কাস্টম রুম আইডি দেখতে অনুগ্রহ করে লগইন করুন।
        </p>
        <button
          onClick={() => setShowLoginModal(true)}
          className="py-2.5 px-6 rounded-lg bg-red-600 hover:bg-red-700 text-white font-black text-xs uppercase tracking-wide cursor-pointer"
        >
          লগইন করুন (LOGIN)
        </button>
      </div>
    );
  }

  const handleCopy = (text: string, type: 'id' | 'pass', matchId: string) => {
    navigator.clipboard.writeText(text);
    if (type === 'id') {
      setCopiedId(matchId);
      setTimeout(() => setCopiedId(null), 2000);
    } else {
      setCopiedPass(matchId);
      setTimeout(() => setCopiedPass(null), 2000);
    }
  };

  return (
    <div className="max-w-xl mx-auto space-y-4 pb-20 font-bangla text-slate-800">
      
      {/* Header Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm flex items-center justify-between">
        <div>
          <span className="text-[10px] font-bold text-red-600 uppercase tracking-widest block">
            MY JOINED MATCHES
          </span>
          <h1 className="font-heading text-xl font-black text-slate-900 mt-0.5">
            মাই ম্যাচ (MY MATCHES)
          </h1>
        </div>

        <button
          onClick={refreshData}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-xs text-slate-700 font-bold transition-colors cursor-pointer"
        >
          <RefreshCw className="w-3.5 h-3.5 text-red-600" />
          <span>রিলোড</span>
        </button>
      </div>

      {/* Match Cards */}
      {userRegistrations.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-10 text-center space-y-3 shadow-sm">
          <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
            <Gamepad2 className="w-6 h-6" />
          </div>
          <h3 className="font-heading font-black text-base text-slate-800">
            আপনি এখনও কোনো টুর্নামেন্ট কিনেননি
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            পছন্দের ক্যাটাগরি বেছে নিন এবং আপনার টিম রেজিস্টার করে কাস্টম ম্যাচে অংশ নিন।
          </p>
          <button
            onClick={() => setActiveTab('home')}
            className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs uppercase cursor-pointer shadow-md transition-all"
          >
            ম্যাচ খুঁজুন (PLAY)
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {userRegistrations.map((reg) => {
            const tournament = tournaments.find(t => t.id === reg.tournamentId);
            const roomAccess = getRoomCredentials(reg.tournamentId);
            const isConfirmed = reg.status === 'CONFIRMED' || reg.status === 'REGISTERED';
            const isPending = reg.status === 'PENDING_APPROVAL';
            const isRejected = reg.status === 'REJECTED';

            return (
              <div
                key={reg.id}
                className="bg-white rounded-2xl border-2 border-red-600 shadow-md p-4 sm:p-5 space-y-3.5 transition-all"
              >
                {/* Header row */}
                <div className="flex items-start justify-between border-b border-slate-100 pb-3 gap-2">
                  <div>
                    <h3 className="font-heading font-black text-base sm:text-lg text-slate-950">
                      {reg.tournamentTitle}
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {reg.tournamentMode} • {reg.tournamentMap} • সময়: {reg.tournamentTime}
                    </p>
                  </div>

                  {/* Status Badge */}
                  {isConfirmed ? (
                    <span className="px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 font-black text-xs border border-emerald-300 shrink-0 flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Slot #{reg.slotNumber}</span>
                    </span>
                  ) : isPending ? (
                    <span className="px-2.5 py-1 rounded-lg bg-amber-50 text-amber-800 font-bold text-xs border border-amber-300 shrink-0 flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      <span>Pending Approval</span>
                    </span>
                  ) : isRejected ? (
                    <span className="px-2.5 py-1 rounded-lg bg-red-50 text-red-700 font-bold text-xs border border-red-300 shrink-0">
                      বাতিল (Rejected)
                    </span>
                  ) : (
                    <span className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 font-bold text-xs">
                      {reg.status}
                    </span>
                  )}
                </div>

                {/* Player details */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                  <div>
                    <span className="text-[10px] text-slate-400 font-bold block uppercase">TEAM NAME</span>
                    <span className="font-bold text-slate-900 truncate block">{reg.teamName || 'Solo'}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 font-bold block uppercase">Player IGN</span>
                    <span className="font-bold text-slate-900 truncate block">{reg.ffNickname}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 font-bold block uppercase">Free Fire UID</span>
                    <span className="font-mono font-bold text-slate-900">{reg.ffUid}</span>
                  </div>
                </div>

                {/* PENDING APPROVAL NOTICE */}
                {isPending && (
                  <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-300 text-amber-900 space-y-2 text-xs">
                    <div className="flex items-center gap-2 font-black">
                      <Clock className="w-4 h-4 text-amber-600 shrink-0" />
                      <span>পেমেন্ট ভেরিফিকেশন পেন্ডিং</span>
                    </div>
                    <p className="leading-relaxed text-[11px] text-amber-800">
                      আপনার বিকাশ/নগদ পেমেন্ট রিকোয়েস্ট জমা হয়েছে (TrxID: <strong>{reg.transactionId || 'N/A'}</strong>)। এডমিন যাচাই করে অনুমোদন করলেই আপনার টিম স্লট বরাদ্দ পাবে এবং রুম আইডি উন্মুক্ত হবে।
                    </p>
                  </div>
                )}

                {/* REJECTED NOTICE */}
                {isRejected && (
                  <div className="p-3.5 rounded-xl bg-red-50 border border-red-300 text-red-800 space-y-1 text-xs">
                    <div className="flex items-center gap-1.5 font-bold text-red-700">
                      <AlertTriangle className="w-4 h-4 shrink-0" />
                      <span>পেমেন্ট বাতিল হয়েছে</span>
                    </div>
                    <p className="text-[11px]">
                      কারণ: {reg.adminNote || 'ভুল ট্রানজেকশন আইডি বা পেমেন্ট পাওয়া যায়নি।'}
                    </p>
                  </div>
                )}

                {/* ROOM ID / PASSWORD BOX FOR CONFIRMED REGISTRATIONS */}
                {isConfirmed && (
                  <div className="p-3.5 rounded-xl border border-red-200 bg-red-50/40 space-y-3">
                    {roomAccess.status === 'AVAILABLE' && roomAccess.room ? (
                      /* RELEASED ROOM */
                      <div className="space-y-3">
                        <div className="flex items-center gap-1.5 text-emerald-700 text-xs font-black">
                          <Unlock className="w-4 h-4" />
                          <span>রুম আইডি ও পাসওয়ার্ড রেডি — দ্রুত ফ্রি ফায়ারে ঢুকুন!</span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                          {/* Room ID with Copy */}
                          <div className="p-2.5 bg-white rounded-lg border border-slate-200 flex items-center justify-between">
                            <div>
                              <span className="text-[9px] font-bold text-slate-400 uppercase block">ROOM ID</span>
                              <span className="font-mono text-base font-black text-slate-900">{roomAccess.room.roomId}</span>
                            </div>
                            <button
                              onClick={() => handleCopy(roomAccess.room!.roomId, 'id', reg.id)}
                              className="px-3 py-1.5 rounded-md bg-red-600 hover:bg-red-700 text-white font-bold text-xs flex items-center gap-1 cursor-pointer"
                            >
                              {copiedId === reg.id ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                              <span>{copiedId === reg.id ? 'কপি হয়েছে' : 'কপি'}</span>
                            </button>
                          </div>

                          {/* Password with Copy */}
                          <div className="p-2.5 bg-white rounded-lg border border-slate-200 flex items-center justify-between">
                            <div>
                              <span className="text-[9px] font-bold text-slate-400 uppercase block">PASSWORD</span>
                              <span className="font-mono text-base font-black text-slate-900">{roomAccess.room.password}</span>
                            </div>
                            <button
                              onClick={() => handleCopy(roomAccess.room!.password, 'pass', reg.id)}
                              className="px-3 py-1.5 rounded-md bg-red-600 hover:bg-red-700 text-white font-bold text-xs flex items-center gap-1 cursor-pointer"
                            >
                              {copiedPass === reg.id ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                              <span>{copiedPass === reg.id ? 'কপি হয়েছে' : 'কপি'}</span>
                            </button>
                          </div>
                        </div>

                        <p className="text-[11px] text-slate-600">
                          * Free Fire ওপেন করে কাস্টম রুমে ঢুকে <strong className="text-red-700">টিম স্লট #{reg.slotNumber}</strong> এ বসুন।
                        </p>
                      </div>
                    ) : (
                      /* LOCKED ROOM */
                      <div className="text-center py-2 space-y-1">
                        <div className="flex items-center justify-center gap-1.5 text-red-600 font-black text-xs">
                          <Lock className="w-4 h-4" />
                          <span>LOCKED</span>
                        </div>
                        <h4 className="font-heading font-black text-sm text-slate-900">
                          Room ID & Password will be available soon.
                        </h4>
                        <p className="text-[11px] text-slate-500">
                          ম্যাচ শুরুর ১০-১৫ মিনিট আগে এখানে স্বয়ংক্রিয়ভাবে রুম আইডি ভেসে উঠবে।
                        </p>
                      </div>
                    )}
                  </div>
                )}

                {/* RESULT BUTTON FOR THIS TOURNAMENT */}
                {results.some(r => r.tournamentId === reg.tournamentId) && (
                  <button
                    onClick={() => setActiveTab('leaderboard')}
                    className="w-full py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-black font-black text-xs flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
                  >
                    <Trophy className="w-4 h-4 text-black" />
                    <span>এই টুর্নামেন্টের পয়েন্ট টেবিল ও রেজাল্ট দেখুন (Result)</span>
                  </button>
                )}

              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
