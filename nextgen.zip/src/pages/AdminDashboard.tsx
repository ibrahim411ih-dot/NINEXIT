import React, { useState, useMemo } from 'react';
import { 
  Shield, Plus, Edit, Trash2, Key, Users, Trophy, Bell, 
  Settings, CheckCircle2, Lock, Unlock, Search, 
  Send, RefreshCw, ArrowRight, Save, Flame,
  Check, X, Copy, CreditCard, Clock, MapPin, Phone, Crown
} from 'lucide-react';
import { useTournaments } from '../context/TournamentContext';
import { useAuth } from '../context/AuthContext';
import { 
  Tournament, RoomData, MatchResult, TournamentMode, TournamentMap, TournamentStatus,
  getFFPlacementPoints, FF_OFFICIAL_PLACEMENT_POINTS 
} from '../types';
import { TODAY_DATE } from '../services/mockData';
import { storage } from '../services/storage';

// 12 Standard Squads for Free Fire esports matches
const DEFAULT_SQUAD_ROSTER = [
  { teamName: 'Apex BD', playerName: '亗 ᴛᴀɴᴠɪʀ 亗', ffUid: '2081948291' },
  { teamName: 'Shadow Clan', playerName: 'BD_SHADOW_07', ffUid: '1948291048' },
  { teamName: 'Viper Force', playerName: '⚡RAKIB_FF⚡', ffUid: '1839201948' },
  { teamName: 'Bengal Tigers', playerName: '★NAEEM_PRO★', ffUid: '1728394019' },
  { teamName: 'Delta BD', playerName: 'KILLER_SAKIB', ffUid: '1639204817' },
  { teamName: 'Red Wolves', playerName: 'DEAD_SHOT_BD', ffUid: '1529384719' },
  { teamName: 'Cyber Kings', playerName: 'CYBER_NINJA', ffUid: '1428394018' },
  { teamName: 'Dark Knights', playerName: 'RED_DEMON_77', ffUid: '1329482019' },
  { teamName: 'Phantom Crew', playerName: 'DARK_SOUL_99', ffUid: '1293840192' },
  { teamName: 'Hellfire BD', playerName: 'TIGER_FORCE', ffUid: '1192830194' },
  { teamName: 'Thunder Squad', playerName: 'SNIPER_KING', ffUid: '1092837482' },
  { teamName: 'Alpha BD', playerName: 'ALPHA_STRIKER', ffUid: '1029384756' },
];

export const AdminDashboard: React.FC = () => {
  const { user } = useAuth();
  const { 
    tournaments, 
    allRegistrations, 
    results, 
    adminSaveTournament, 
    adminDeleteTournament, 
    adminSaveRoom, 
    adminSaveResults, 
    adminSendNotification,
    adminApproveRegistration,
    adminRejectRegistration,
    refreshData,
    resetAllDemoData,
    getRoomCredentials
  } = useTournaments();

  const [activeAdminTab, setActiveAdminTab] = useState<
    'dashboard' | 'tournaments' | 'players' | 'rooms' | 'results' | 'notifications' | 'settings'
  >('dashboard');

  // Success alert message
  const [successBanner, setSuccessBanner] = useState<string | null>(null);
  const showSuccess = (msg: string) => {
    setSuccessBanner(msg);
    setTimeout(() => setSuccessBanner(null), 3000);
  };

  // --- 1. TOURNAMENT FORM STATE ---
  const [isEditingTournament, setIsEditingTournament] = useState(false);
  const [editingTourId, setEditingTourId] = useState<string | null>(null);
  const [tourTitle, setTourTitle] = useState('BR SCRIM');
  const [tourCategory, setTourCategory] = useState<string>('BR SCRIM');
  const [tourMap, setTourMap] = useState<string>('B. P. K');
  const [tourDate, setTourDate] = useState(TODAY_DATE);
  const [tourTime, setTourTime] = useState('10:00 PM');
  const [tourMaxSlots, setTourMaxSlots] = useState(12);
  const [tourEntryFee, setTourEntryFee] = useState(40);
  const [tourPrizePool, setTourPrizePool] = useState(380);
  const [tourFirstPrize, setTourFirstPrize] = useState(240);
  const [tourSecondPrize, setTourSecondPrize] = useState(100);
  const [tourThirdPrize, setTourThirdPrize] = useState(40);
  const [tourStatus, setTourStatus] = useState<TournamentStatus>('OPEN');

  // One-click presets matching official app specifications
  const applyCategoryPreset = (category: string) => {
    setTourCategory(category);
    setTourTitle(category);

    if (category === 'BR SCRIM') {
      setTourEntryFee(40);
      setTourPrizePool(380);
      setTourFirstPrize(240);
      setTourSecondPrize(100);
      setTourThirdPrize(40);
      setTourMap('B. P. K');
      setTourMaxSlots(12);
    } else if (category === 'BR BLAST') {
      setTourEntryFee(50);
      setTourPrizePool(450);
      setTourFirstPrize(280);
      setTourSecondPrize(120);
      setTourThirdPrize(50);
      setTourMap('B. P. K. N');
      setTourMaxSlots(12);
    } else if (category === 'BR CHAMPION RUSH') {
      setTourEntryFee(80);
      setTourPrizePool(700);
      setTourFirstPrize(420);
      setTourSecondPrize(180);
      setTourThirdPrize(100);
      setTourMap('B. P. K. N. S');
      setTourMaxSlots(12);
    } else if (category === 'CS 4V4') {
      setTourEntryFee(50);
      setTourPrizePool(100);
      setTourFirstPrize(70);
      setTourSecondPrize(30);
      setTourThirdPrize(0);
      setTourMap('Bermuda');
      setTourMaxSlots(4);
    } else if (category === 'LONE WOLF') {
      setTourEntryFee(50);
      setTourPrizePool(80);
      setTourFirstPrize(60);
      setTourSecondPrize(20);
      setTourThirdPrize(0);
      setTourMap('Lone Wolf Map');
      setTourMaxSlots(2);
    } else if (category === 'FREE MATCH') {
      setTourEntryFee(0);
      setTourPrizePool(100);
      setTourFirstPrize(70);
      setTourSecondPrize(30);
      setTourThirdPrize(0);
      setTourMap('Bermuda');
      setTourMaxSlots(12);
    }
  };

  const resetTourForm = () => {
    setIsEditingTournament(false);
    setEditingTourId(null);
    applyCategoryPreset('BR SCRIM');
    setTourDate(TODAY_DATE);
    setTourTime('10:00 PM');
    setTourStatus('OPEN');
  };

  const handleEditTournamentInit = (tour: Tournament) => {
    setIsEditingTournament(true);
    setEditingTourId(tour.id);
    setTourTitle(tour.title);
    setTourCategory(tour.matchCategory || 'BR SCRIM');
    setTourMap(tour.map);
    setTourDate(tour.date);
    setTourTime(tour.time);
    setTourMaxSlots(tour.maxSlots);
    setTourEntryFee(tour.entryFee);
    setTourPrizePool(tour.prizePool);
    setTourFirstPrize(tour.prizeDetails.first || 0);
    setTourSecondPrize(tour.prizeDetails.second || 0);
    setTourThirdPrize(tour.prizeDetails.third || 0);
    setTourStatus(tour.status);
    setActiveAdminTab('tournaments');
  };

  const handleSaveTournament = (e: React.FormEvent) => {
    e.preventDefault();

    const bannerMap: Record<string, string> = {
      'BR SCRIM': 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&q=80',
      'BR BLAST': 'https://images.unsplash.com/photo-1579373903781-fd5c0c30c4cd?auto=format&fit=crop&w=800&q=80',
      'BR CHAMPION RUSH': 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=800&q=80',
      'CS 4V4': 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=800&q=80',
      'LONE WOLF': 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=800&q=80',
      'FREE MATCH': 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?auto=format&fit=crop&w=800&q=80',
    };

    const tourData: Tournament = {
      id: editingTourId || `tour-${Date.now()}`,
      title: tourTitle,
      game: 'Free Fire MAX',
      mode: 'Squad',
      map: tourMap as TournamentMap,
      date: tourDate,
      time: tourTime,
      regDeadline: tourTime,
      maxSlots: Number(tourMaxSlots),
      joinedSlots: editingTourId ? (tournaments.find(t => t.id === editingTourId)?.joinedSlots || 0) : 0,
      entryFee: Number(tourEntryFee),
      prizePool: Number(tourPrizePool),
      prizeDetails: {
        first: Number(tourFirstPrize),
        second: Number(tourSecondPrize),
        third: Number(tourThirdPrize),
      },
      status: tourStatus,
      bannerUrl: bannerMap[tourCategory] || bannerMap['BR SCRIM'],
      rules: [
        `Squad (${tourMaxSlots} টিম) ব্যাটল।`,
        'মোবাইল প্লেয়ারদের জন্য উন্মুক্ত। Strictly No Emulator / PC.',
        'গান অ্যাট্রিবিউট: বন্ধ (OFF)। ক্যারেক্টার স্কিল: চালু (ON)।',
        'ম্যাচ শুরুর ১৫ মিনিট আগে My Matches অপশনে রুম আইডি ও পাসওয়ার্ড প্রকাশ করা হবে।'
      ],
      matchCategory: tourCategory,
      matchTimestamp: Date.now() + 3600000,
      createdAt: new Date().toISOString(),
    };

    adminSaveTournament(tourData);
    showSuccess(editingTourId ? 'টুর্নামেন্ট আপডেট সম্পন্ন হয়েছে!' : 'নতুন টুর্নামেন্ট সফলভাবে পাবলিশ হয়েছে!');
    resetTourForm();
  };

  // --- 2. ROOM MANAGEMENT STATE ---
  const [selectedRoomTourId, setSelectedRoomTourId] = useState<string>(tournaments[0]?.id || '');
  const [adminRoomId, setAdminRoomId] = useState('');
  const [adminRoomPassword, setAdminRoomPassword] = useState('');
  const [isRoomReleased, setIsRoomReleased] = useState(false);

  // Load current room values when selected tournament changes
  React.useEffect(() => {
    if (selectedRoomTourId) {
      const roomCreds = getRoomCredentials(selectedRoomTourId);
      if (roomCreds.room) {
        setAdminRoomId(roomCreds.room.roomId);
        setAdminRoomPassword(roomCreds.room.password);
        setIsRoomReleased(roomCreds.room.isReleased);
      } else {
        setAdminRoomId('');
        setAdminRoomPassword('');
        setIsRoomReleased(false);
      }
    }
  }, [selectedRoomTourId]);

  const handleSaveRoomAction = (releaseOverride?: boolean) => {
    if (!selectedRoomTourId) return;

    const releaseState = releaseOverride !== undefined ? releaseOverride : isRoomReleased;

    const roomPayload: RoomData = {
      tournamentId: selectedRoomTourId,
      roomId: adminRoomId || '89324019',
      password: adminRoomPassword || '7722',
      isReleased: releaseState,
      releaseTime: 'ম্যাচ শুরুর ১৫ মিনিট আগে',
      updatedAt: new Date().toISOString(),
    };

    adminSaveRoom(roomPayload);
    setIsRoomReleased(releaseState);
    showSuccess(
      releaseState 
        ? '🔥 রুম রিলিজ সম্পন্ন! অনুমোদিত সকল ক্রেতারা এখন My Matches এ রুম আইডি ও পাসওয়ার্ড দেখতে পাচ্ছেন।' 
        : 'রুম তথ্য সংরক্ষিত এবং লক রাখা হয়েছে।'
    );
  };

  // --- 3. RESULTS & LEADERBOARD ENTRY STATE (OFFICIAL FREE FIRE ESPORTS RULES) ---
  const [resultCategoryFilter, setResultCategoryFilter] = useState<string>('BR SCRIM');
  const [resultTourId, setResultTourId] = useState<string>(tournaments[0]?.id || '');
  const [editingResultId, setEditingResultId] = useState<string | null>(null);
  const [resPlayerName, setResPlayerName] = useState('');
  const [resFfUid, setResFfUid] = useState('');
  const [resTeamName, setResTeamName] = useState('');
  const [resRank, setResRank] = useState(1);
  const [resKills, setResKills] = useState(0);
  const [resPlacementPoints, setResPlacementPoints] = useState(12);
  const [resMatchesPlayed, setResMatchesPlayed] = useState(1);
  const [resBooyahs, setResBooyahs] = useState(1);
  const [resPrizeWon, setResPrizeWon] = useState(0);
  const [resIsDesignatedChampion, setResIsDesignatedChampion] = useState(false);

  // Filtered tournaments for the selected category
  const filteredResultTournaments = useMemo(() => {
    if (resultCategoryFilter === 'ALL') return tournaments;
    return tournaments.filter(t => (t.matchCategory || '').toUpperCase() === resultCategoryFilter.toUpperCase());
  }, [tournaments, resultCategoryFilter]);

  // Check if selected tournament is CS 4V4 or Lone Wolf
  const isSelectedTourCSorLW = useMemo(() => {
    const t = tournaments.find(x => x.id === resultTourId);
    if (!t) return false;
    const cat = (t.matchCategory || '').toUpperCase();
    const title = (t.title || '').toUpperCase();
    return (
      cat.includes('CS 4') ||
      cat.includes('CLASH SQUAD') ||
      cat.includes('LONE WOLF') ||
      cat.includes('LOWN WOLF') ||
      title.includes('CS 4') ||
      title.includes('CLASH SQUAD') ||
      title.includes('LONE WOLF') ||
      title.includes('LOWN WOLF')
    );
  }, [tournaments, resultTourId]);

  // Check if selected tournament is CHAMPION RUSH
  const isChampionRush = useMemo(() => {
    const t = tournaments.find(x => x.id === resultTourId);
    if (!t) return false;
    const cat = (t.matchCategory || '').toUpperCase();
    const title = (t.title || '').toUpperCase();
    return cat.includes('CHAMPION RUSH') || title.includes('CHAMPION RUSH');
  }, [tournaments, resultTourId]);

  // Sync selected tournament when filtered category changes
  React.useEffect(() => {
    if (filteredResultTournaments.length > 0) {
      if (!filteredResultTournaments.some(t => t.id === resultTourId)) {
        setResultTourId(filteredResultTournaments[0].id);
        setEditingResultId(null);
        setResPlayerName('');
        setResFfUid('');
        setResTeamName('');
        setResKills(0);
        setResPrizeWon(0);
        setResIsDesignatedChampion(false);
        setResRank(1);
      }
    }
  }, [filteredResultTournaments, resultTourId]);

  // Current tournament results list
  const currentTourResults = useMemo(() => {
    return results.filter(r => r.tournamentId === resultTourId).sort((a, b) => a.rank - b.rank);
  }, [results, resultTourId]);

  // Slot Buyers for the selected tournament (auto-fill list)
  // Ensures ALL teams up to maxSlots are ALWAYS present and NEVER disappear when a point is added!
  const tournamentSlotBuyers = useMemo(() => {
    if (!resultTourId) return [];

    const tour = tournaments.find(t => t.id === resultTourId);
    const maxSlots = tour?.maxSlots || 12;

    // 1. Gather all confirmed/registered registrations for this tournament
    const fromRegs = allRegistrations
      .filter(r => r.tournamentId === resultTourId && (r.status === 'CONFIRMED' || r.status === 'REGISTERED'))
      .map(r => ({
        id: r.id,
        teamName: r.teamName || r.userName || 'Squad Team',
        playerName: r.ffNickname || r.userName || 'Player',
        ffUid: r.ffUid || '',
        slotNumber: r.slotNumber || 1,
      }));

    const map = new Map<string, { id: string; teamName: string; playerName: string; ffUid: string; slotNumber: number }>();
    const usedSlots = new Set<number>();

    // Put confirmed registrations first
    fromRegs.forEach(t => {
      const key = t.teamName.toLowerCase().trim();
      map.set(key, t);
      usedSlots.add(t.slotNumber);
    });

    // Also include any teams that already have results saved for this tournament
    currentTourResults.forEach(res => {
      const key = (res.teamName || '').toLowerCase().trim();
      if (key && !map.has(key)) {
        let slot = res.rank || 1;
        while (usedSlots.has(slot) && slot <= 50) {
          slot++;
        }
        usedSlots.add(slot);
        map.set(key, {
          id: res.id,
          teamName: res.teamName || 'Squad Team',
          playerName: res.playerName || 'Player',
          ffUid: res.ffUid || '',
          slotNumber: slot,
        });
      }
    });

    // Fill remaining slots up to maxSlots from DEFAULT_SQUAD_ROSTER
    // so ALL 12 (or maxSlots) teams ALWAYS remain visible to click and never disappear!
    let fallbackIdx = 0;
    while (map.size < maxSlots && fallbackIdx < DEFAULT_SQUAD_ROSTER.length) {
      const item = DEFAULT_SQUAD_ROSTER[fallbackIdx];
      const key = item.teamName.toLowerCase().trim();
      if (!map.has(key)) {
        let slot = 1;
        while (usedSlots.has(slot) && slot <= maxSlots) {
          slot++;
        }
        usedSlots.add(slot);
        map.set(key, {
          id: `fb-slot-${fallbackIdx + 1}`,
          teamName: item.teamName,
          playerName: item.playerName,
          ffUid: item.ffUid,
          slotNumber: slot <= maxSlots ? slot : map.size + 1,
        });
      }
      fallbackIdx++;
    }

    return Array.from(map.values()).sort((a, b) => a.slotNumber - b.slotNumber);
  }, [allRegistrations, currentTourResults, resultTourId, tournaments]);

  // Rank change: auto placement points & default booyah
  const handleRankChange = (rank: number) => {
    setResRank(rank);
    const placePts = getFFPlacementPoints(rank);
    setResPlacementPoints(placePts);
    setResBooyahs(rank === 1 ? 1 : 0);
  };

  // Click slot team to auto-fill or enter edit mode!
  const handleSelectSlotTeam = (team: { teamName: string; playerName: string; ffUid: string }) => {
    setResTeamName(team.teamName);
    setResPlayerName(team.playerName);
    setResFfUid(team.ffUid);

    // Check if this team already has a submitted score
    const existing = currentTourResults.find(
      r => r.teamName?.trim().toLowerCase() === team.teamName.trim().toLowerCase()
    );

    if (existing) {
      setEditingResultId(existing.id);
      setResRank(existing.rank);
      setResKills(existing.kills);
      setResPlacementPoints(existing.placementPoints);
      setResMatchesPlayed(existing.matchesPlayed ?? 1);
      setResBooyahs(existing.booyahs ?? 0);
      setResPrizeWon(existing.prizeWon ?? 0);
      setResIsDesignatedChampion(Boolean(existing.isDesignatedChampion));
      showSuccess(`✏️ "${team.teamName}" এর পয়েন্ট এডিট করা হচ্ছে। কিল বা পজিশন পরিবর্তন করে সেভ করুন।`);
    } else {
      setEditingResultId(null);
      setResKills(0);
      setResPrizeWon(0);
      setResIsDesignatedChampion(false);
      // Automatically pick next unused rank (1-12) so adding points does not collide
      const usedRanks = new Set(currentTourResults.map(r => r.rank));
      let nextRank = 1;
      while (usedRanks.has(nextRank) && nextRank <= 12) {
        nextRank++;
      }
      handleRankChange(nextRank <= 12 ? nextRank : 1);
    }
  };

  const handleCancelEdit = () => {
    setEditingResultId(null);
    setResPlayerName('');
    setResFfUid('');
    setResTeamName('');
    setResKills(0);
    setResPrizeWon(0);
    setResIsDesignatedChampion(false);
    handleRankChange(1);
  };

  const handleStartEditRow = (res: MatchResult) => {
    setEditingResultId(res.id);
    setResTeamName(res.teamName || '');
    setResPlayerName(res.playerName || '');
    setResFfUid(res.ffUid || '');
    setResRank(res.rank);
    setResKills(res.kills);
    setResPlacementPoints(res.placementPoints);
    setResMatchesPlayed(res.matchesPlayed ?? 1);
    setResBooyahs(res.booyahs ?? 0);
    setResPrizeWon(res.prizeWon ?? 0);
    setResIsDesignatedChampion(Boolean(res.isDesignatedChampion));
    showSuccess(`✏️ "${res.teamName}" এর পয়েন্ট এডিট করার জন্য ফর্মে লোড হয়েছে।`);
  };

  // CHAMPION RUSH: designate any team as Champion!
  const handleMakeDesignatedChampion = (resultId: string) => {
    const champ = currentTourResults.find(r => r.id === resultId);
    if (!champ) return;

    const updated = currentTourResults.map(r => ({
      ...r,
      isDesignatedChampion: r.id === resultId,
    }));

    adminSaveResults(resultTourId, updated);
    showSuccess(`👑 "${champ.teamName}" কে সরাসরি Champion নির্ধারণ করা হয়েছে! বাকিদের মধ্যে যার পয়েন্ট বেশি সে Runner-up ও 3rd place হবে।`);
  };

  // Auto calculate total points = placementPoints + (kills * 1)
  const calculatedTotalPoints = (Number(resPlacementPoints) || 0) + (Number(resKills) * 1 || 0);

  const handleAddResult = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resultTourId || !resPlayerName.trim()) return;

    const tour = tournaments.find(t => t.id === resultTourId);

    const newResult: MatchResult = {
      id: editingResultId || `res-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      tournamentId: resultTourId,
      tournamentTitle: tour?.title || 'Tournament',
      matchCategory: tour?.matchCategory,
      rank: Number(resRank),
      playerName: resPlayerName,
      ffUid: resFfUid,
      teamName: resTeamName,
      kills: Number(resKills),
      placementPoints: isSelectedTourCSorLW ? 0 : Number(resPlacementPoints),
      totalPoints: isSelectedTourCSorLW ? (Number(resBooyahs) || 0) : calculatedTotalPoints,
      matchesPlayed: Number(resMatchesPlayed) || 1,
      booyahs: Number(resBooyahs) || (Number(resRank) === 1 ? 1 : 0),
      prizeWon: Number(resPrizeWon),
      isDesignatedChampion: Boolean(resIsDesignatedChampion),
    };

    let updatedTourResults: MatchResult[];

    if (editingResultId) {
      // Direct edit of an existing record
      updatedTourResults = currentTourResults.map(r => r.id === editingResultId ? newResult : r);
    } else {
      // Check if this team is already in currentTourResults by team name
      const existingTeamIndex = currentTourResults.findIndex(
        r => r.teamName?.trim().toLowerCase() === resTeamName.trim().toLowerCase()
      );
      if (existingTeamIndex >= 0) {
        // Update that team without removing any other team
        updatedTourResults = [...currentTourResults];
        updatedTourResults[existingTeamIndex] = {
          ...newResult,
          id: currentTourResults[existingTeamIndex].id,
        };
      } else {
        // Add new team - NEVER delete other teams!
        updatedTourResults = [...currentTourResults, newResult];
      }
    }

    // If designated champion, ensure other teams don't have it
    if (newResult.isDesignatedChampion) {
      updatedTourResults = updatedTourResults.map(r => ({
        ...r,
        isDesignatedChampion: r.id === newResult.id,
      }));
    }

    updatedTourResults.sort((a, b) => a.rank - b.rank);
    adminSaveResults(resultTourId, updatedTourResults);

    showSuccess(
      editingResultId
        ? `পয়েন্ট আপডেট সম্পন্ন: ${resTeamName} (পজিশন #${resRank}, মোট ${newResult.totalPoints} PTS)`
        : `পয়েন্ট যোগ সম্পন্ন: ${resTeamName || resPlayerName} (পজিশন #${resRank}, মোট ${newResult.totalPoints} PTS)`
    );
    
    handleCancelEdit();
  };

  const handleDeleteResultItem = (resultId: string) => {
    if (!resultTourId) return;
    const tourResults = results.filter(r => r.tournamentId === resultTourId && r.id !== resultId);
    adminSaveResults(resultTourId, tourResults);
    showSuccess('রেজাল্ট এন্ট্রি সফলভাবে মুছে ফেলা হয়েছে।');
    if (editingResultId === resultId) {
      handleCancelEdit();
    }
  };

  // --- 4. BROADCAST NOTIFICATIONS STATE ---
  const [broadcastTitle, setBroadcastTitle] = useState('');
  const [broadcastMessage, setBroadcastMessage] = useState('');

  const handleSendBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastTitle || !broadcastMessage) return;

    adminSendNotification({
      title: broadcastTitle,
      message: broadcastMessage,
      type: 'ANNOUNCEMENT',
      targetUserId: 'all',
    });

    showSuccess('ব্রডকাস্ট নোটিশ সফলভাবে সকল ইউজারের কাছে পাঠানো হয়েছে!');
    setBroadcastTitle('');
    setBroadcastMessage('');
  };

  // --- 5. PLAYER SEARCH & PENDING REGISTRATIONS ---
  const [playerSearchQuery, setPlayerSearchQuery] = useState('');
  const [copiedTrxId, setCopiedTrxId] = useState<string | null>(null);

  const pendingRegistrations = allRegistrations.filter(r => r.status === 'PENDING_APPROVAL');

  const handleCopyTrx = (trx: string) => {
    navigator.clipboard.writeText(trx);
    setCopiedTrxId(trx);
    setTimeout(() => setCopiedTrxId(null), 2000);
  };

  const handleApprove = (regId: string, ffNick: string) => {
    const res = adminApproveRegistration(regId);
    if (res.success) {
      showSuccess(`অনুমোদন সম্পন্ন! "${ffNick}" এর জন্য স্লট #${res.registration?.slotNumber} বরাদ্দ করা হয়েছে।`);
    } else {
      showSuccess(res.message);
    }
  };

  const handleReject = (regId: string, ffNick: string) => {
    const reason = prompt(`"${ffNick}" এর রেজিস্ট্রেশন বাতিলের কারণ লিখুন:`, 'পেমেন্ট ট্রানজেকশন মেলেনি') || 'বাতিল করা হয়েছে';
    const res = adminRejectRegistration(regId, reason);
    if (res.success) {
      showSuccess(`"${ffNick}" এর রেজিস্ট্রেশন বাতিল করা হয়েছে।`);
    }
  };

  const filteredRegistrations = allRegistrations.filter(r => 
    r.userName.toLowerCase().includes(playerSearchQuery.toLowerCase()) ||
    r.ffNickname.toLowerCase().includes(playerSearchQuery.toLowerCase()) ||
    r.ffUid.includes(playerSearchQuery) ||
    r.tournamentTitle.toLowerCase().includes(playerSearchQuery.toLowerCase()) ||
    (r.teamName && r.teamName.toLowerCase().includes(playerSearchQuery.toLowerCase())) ||
    (r.transactionId && r.transactionId.toLowerCase().includes(playerSearchQuery.toLowerCase())) ||
    (r.senderNumber && r.senderNumber.includes(playerSearchQuery))
  );

  // --- 6. ADMIN RECEIVER PAYMENT NUMBER SETTINGS ---
  const [adminPaymentNum, setAdminPaymentNum] = useState(() => storage.getAdminPaymentNumber());
  const handleSavePaymentNumber = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminPaymentNum.trim() || adminPaymentNum.trim().length < 11) {
      alert('সঠিক ১১ সংখ্যার মোবাইল নম্বর লিখুন');
      return;
    }
    storage.saveAdminPaymentNumber(adminPaymentNum.trim());
    showSuccess(`অফিসিয়াল পেমেন্ট নম্বর আপডেট সম্পন্ন: ${adminPaymentNum.trim()}! ইউজারদের কেনা পেজে এটি সক্রিয় হয়েছে।`);
  };

  return (
    <div className="space-y-5 pb-24 font-bangla text-slate-800">
      
      {/* Top Admin Header */}
      <div className="bg-slate-900 text-white rounded-2xl p-4 sm:p-5 border border-slate-800 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-red-600 text-white flex items-center justify-center font-black shadow-md shrink-0">
            <Shield className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-heading text-xl sm:text-2xl font-black tracking-wide">
                NINEX ADMIN PANEL
              </h1>
              <span className="px-2 py-0.5 rounded text-[10px] font-black bg-red-600 text-white uppercase">
                HOST
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              অ্যাডমিন: <strong className="text-white">{user?.displayName || 'Host'}</strong> ({user?.phone || user?.email || 'Admin'})
            </p>
          </div>
        </div>

        <button
          onClick={refreshData}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 font-bold transition-colors cursor-pointer self-start sm:self-auto border border-slate-700"
        >
          <RefreshCw className="w-3.5 h-3.5 text-cyan-400" />
          <span>রিফ্রেশ ডেটা</span>
        </button>
      </div>

      {/* Floating Success Banner */}
      {successBanner && (
        <div className="p-3.5 rounded-xl bg-emerald-50 border-2 border-emerald-300 text-emerald-800 text-xs font-bold flex items-center gap-2 shadow-sm animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{successBanner}</span>
        </div>
      )}

      {/* Admin Tab Navigation */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar p-1.5 bg-white rounded-2xl border border-slate-200 shadow-sm">
        {[
          { id: 'dashboard', label: 'ড্যাশবোর্ড', icon: Trophy },
          { id: 'players', label: 'পেমেন্ট অনুমোদন', icon: Users, badge: pendingRegistrations.length },
          { id: 'rooms', label: 'রুম আইডি রিলিজ', icon: Key },
          { id: 'results', label: 'পয়েন্ট টেবিল ইনপুট', icon: Flame },
          { id: 'tournaments', label: 'টুর্নামেন্ট নিয়ন্ত্রণ', icon: Plus },
          { id: 'notifications', label: 'নোটিশ ব্রডকাস্ট', icon: Bell },
          { id: 'settings', label: 'পেমেন্ট নম্বর ও সেটিংস', icon: Settings },
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeAdminTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveAdminTab(tab.id as any)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'bg-red-600 text-white shadow-sm font-black'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
              {tab.badge && tab.badge > 0 ? (
                <span className="px-1.5 py-0.2 rounded-full bg-white text-red-600 text-[10px] font-black animate-pulse">
                  {tab.badge}
                </span>
              ) : null}
            </button>
          );
        })}
      </div>

      {/* ========================================================= */}
      {/* TAB 1: DASHBOARD OVERVIEW */}
      {/* ========================================================= */}
      {activeAdminTab === 'dashboard' && (
        <div className="space-y-4">
          
          {/* Quick Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-sm">
              <span className="text-[10px] text-slate-500 uppercase font-bold block">মোট টুর্নামেন্ট</span>
              <p className="font-heading text-2xl font-black text-slate-900 mt-0.5">{tournaments.length}</p>
            </div>
            <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-sm">
              <span className="text-[10px] text-slate-500 uppercase font-bold block">অপেক্ষমাণ পেমেন্ট</span>
              <p className="font-heading text-2xl font-black text-amber-600 mt-0.5">{pendingRegistrations.length}</p>
            </div>
            <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-sm">
              <span className="text-[10px] text-slate-500 uppercase font-bold block">রুম রিলিজড</span>
              <p className="font-heading text-2xl font-black text-emerald-600 mt-0.5">
                {tournaments.filter(t => getRoomCredentials(t.id).room?.isReleased).length}
              </p>
            </div>
            <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-sm">
              <span className="text-[10px] text-slate-500 uppercase font-bold block">মোট খেলোয়াড়</span>
              <p className="font-heading text-2xl font-black text-red-600 mt-0.5">{allRegistrations.length}</p>
            </div>
          </div>

          {/* Pending Approvals Urgency Banner */}
          {pendingRegistrations.length > 0 && (
            <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-300 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-amber-600" />
                  <h3 className="font-heading font-black text-sm text-slate-900">
                    অপেক্ষমাণ পেমেন্ট অনুমোদন ({pendingRegistrations.length} জন)
                  </h3>
                </div>
                <button
                  onClick={() => setActiveAdminTab('players')}
                  className="text-xs font-bold text-red-600 hover:underline cursor-pointer"
                >
                  সবগুলো দেখুন →
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {pendingRegistrations.slice(0, 2).map(reg => (
                  <div key={reg.id} className="p-3 rounded-xl bg-white border border-amber-200 space-y-2">
                    <div className="flex justify-between items-start text-xs">
                      <div>
                        <span className="font-black text-slate-900 block">{reg.ffNickname}</span>
                        <span className="text-[10px] text-slate-500">টিম: {reg.teamName || 'Solo'} • {reg.tournamentTitle}</span>
                      </div>
                      <span className="text-[10px] font-mono font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded">
                        {reg.paymentMethod || 'bKash'}
                      </span>
                    </div>

                    <div className="text-[11px] font-mono bg-slate-50 p-2 rounded border border-slate-200">
                      <div>নম্বর: <strong className="text-slate-900">{reg.senderNumber || reg.phone}</strong></div>
                      <div>TrxID: <strong className="text-emerald-700">{reg.transactionId || 'N/A'}</strong></div>
                    </div>

                    <div className="flex items-center gap-2 pt-1">
                      <button
                        onClick={() => handleApprove(reg.id, reg.ffNickname)}
                        className="flex-1 py-1.5 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>কনফার্ম ও স্লট দিন</span>
                      </button>
                      <button
                        onClick={() => handleReject(reg.id, reg.ffNickname)}
                        className="py-1.5 px-3 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 font-bold text-xs cursor-pointer"
                      >
                        বাতিল
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Quick Room Status Monitor */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Key className="w-4 h-4 text-red-600" />
                <h3 className="font-heading font-black text-sm text-slate-900">
                  রুম আইডি ও পাসওয়ার্ড রিলিজ মনিটর
                </h3>
              </div>
              <button
                onClick={() => setActiveAdminTab('rooms')}
                className="text-xs font-bold text-red-600 hover:underline cursor-pointer"
              >
                রুম ম্যানেজারে যান →
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {tournaments.slice(0, 4).map(tour => {
                const roomData = getRoomCredentials(tour.id);
                const isReleased = roomData.room?.isReleased;

                return (
                  <div
                    key={tour.id}
                    className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3"
                  >
                    <div>
                      <h4 className="text-xs font-black text-slate-900 truncate max-w-[180px]">
                        {tour.title}
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        {tour.time} • {tour.joinedSlots}/{tour.maxSlots} টিম
                      </p>
                    </div>

                    <div className="shrink-0">
                      {isReleased ? (
                        <span className="px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-800 text-[10px] font-black flex items-center gap-1">
                          <Unlock className="w-3 h-3 text-emerald-600" />
                          রিলিজড
                        </span>
                      ) : (
                        <span className="px-2.5 py-1 rounded-lg bg-slate-200 text-slate-700 text-[10px] font-black flex items-center gap-1">
                          <Lock className="w-3 h-3 text-slate-500" />
                          লকড
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>
      )}

      {/* ========================================================= */}
      {/* TAB 2: PLAYERS & PENDING APPROVALS */}
      {/* ========================================================= */}
      {activeAdminTab === 'players' && (
        <div className="space-y-4">
          
          {/* 1. Pending Approvals Queue */}
          <div className="p-4 rounded-2xl bg-amber-50/70 border-2 border-amber-300 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-heading font-black text-base text-slate-900 flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-amber-600" />
                  পেমেন্ট ভেরিফিকেশন ও স্লট অনুমোদন
                </h3>
                <p className="text-xs text-slate-600 mt-0.5">
                  খেলোয়াড়দের বিকাশ/নগদ নম্বর ও TrxID মিলিয়ে <strong>কনফার্ম ও স্লট দিন</strong> বাটনে চাপ দিন।
                </p>
              </div>
              <span className="px-2.5 py-1 rounded-full bg-amber-200 text-amber-900 text-xs font-black">
                {pendingRegistrations.length} টি অপেক্ষমাণ
              </span>
            </div>

            {pendingRegistrations.length === 0 ? (
              <div className="p-6 text-center text-slate-500 rounded-xl bg-white border border-slate-200">
                <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-1.5" />
                <p className="text-xs font-bold text-slate-800">কোনো অপেক্ষমাণ পেমেন্ট নেই!</p>
                <p className="text-[11px] text-slate-500">সকল টুর্নামেন্ট রেজিস্ট্রেশন অনুমোদিত ও স্লট বরাদ্দকৃত রয়েছে।</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {pendingRegistrations.map(reg => (
                  <div key={reg.id} className="p-4 rounded-xl bg-white border border-amber-300 space-y-2.5 shadow-sm">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-sm font-black text-slate-900 block">{reg.ffNickname}</span>
                        <span className="text-[11px] text-slate-500">ইউজার: {reg.userName}</span>
                      </div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-black bg-amber-100 text-amber-800 border border-amber-200">
                        PENDING
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                      <div>
                        <span className="text-[10px] text-slate-400 block font-bold">GAME UID</span>
                        <span className="font-mono text-slate-900 font-bold">{reg.ffUid}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block font-bold">TEAM NAME</span>
                        <span className="text-slate-900 font-bold truncate block">{reg.teamName || 'Solo'}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block font-bold">প্রেরক নম্বর ({reg.paymentMethod || 'bKash'})</span>
                        <span className="font-mono text-red-600 font-bold">{reg.senderNumber || reg.phone}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block font-bold">টুর্নামেন্ট</span>
                        <span className="text-slate-900 font-bold truncate block">{reg.tournamentTitle}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-xs bg-emerald-50 border border-emerald-200 px-3 py-2 rounded-lg">
                      <span className="text-slate-600 text-[11px] font-bold">TrxID:</span>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-black text-emerald-800 text-xs">{reg.transactionId || 'N/A'}</span>
                        {reg.transactionId && (
                          <button
                            onClick={() => handleCopyTrx(reg.transactionId!)}
                            className="p-1 text-slate-500 hover:text-slate-900 rounded hover:bg-emerald-100 cursor-pointer"
                            title="Copy TrxID"
                          >
                            {copiedTrxId === reg.transactionId ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-1">
                      <button
                        onClick={() => handleApprove(reg.id, reg.ffNickname)}
                        className="flex-1 py-2 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-sm transition-colors"
                      >
                        <Check className="w-4 h-4" />
                        <span>কনফার্ম ও স্লট বরাদ্দ</span>
                      </button>
                      <button
                        onClick={() => handleReject(reg.id, reg.ffNickname)}
                        className="py-2 px-3 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 font-bold text-xs flex items-center justify-center gap-1 cursor-pointer border border-red-200 transition-colors"
                      >
                        <X className="w-4 h-4" />
                        <span>বাতিল</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* 2. All Approved Registrations */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="font-heading font-black text-base text-slate-900">
                  অনুমোদিত খেলোয়াড় তালিকা ({allRegistrations.length})
                </h3>
                <p className="text-xs text-slate-500">
                  UID, গেম নাম, টিম নেম বা TrxID দিয়ে সার্চ করুন।
                </p>
              </div>

              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="সার্চ UID, IGN, Team, TrxID..."
                  value={playerSearchQuery}
                  onChange={(e) => setPlayerSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 focus:outline-none focus:border-red-600"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-100 text-slate-600 uppercase text-[10px] font-black border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">স্লট #</th>
                    <th className="py-2.5 px-3">Player IGN</th>
                    <th className="py-2.5 px-3">Free Fire UID</th>
                    <th className="py-2.5 px-3">Team Name</th>
                    <th className="py-2.5 px-3">Tournament</th>
                    <th className="py-2.5 px-3">Payment & TrxID</th>
                    <th className="py-2.5 px-3">স্ট্যাটাস</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  {filteredRegistrations.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-400 font-sans">
                        কোনো খেলোয়াড় পাওয়া যায়নি।
                      </td>
                    </tr>
                  ) : (
                    filteredRegistrations.map((reg) => (
                      <tr key={reg.id} className="hover:bg-slate-50">
                        <td className="py-3 px-3 font-heading text-sm font-black text-red-600">
                          #{reg.slotNumber}
                        </td>
                        <td className="py-3 px-3 font-sans">
                          <span className="font-bold text-slate-900 block">{reg.ffNickname}</span>
                          <span className="text-[10px] text-slate-400">{reg.userName}</span>
                        </td>
                        <td className="py-3 px-3 font-bold text-slate-700">
                          {reg.ffUid}
                        </td>
                        <td className="py-3 px-3 text-slate-900 font-bold font-sans">
                          {reg.teamName || 'Solo'}
                        </td>
                        <td className="py-3 px-3 text-slate-700 truncate max-w-[140px] font-sans">
                          {reg.tournamentTitle}
                        </td>
                        <td className="py-3 px-3 text-slate-600">
                          <span className="text-[10px] block">{reg.paymentMethod || 'bKash'}: {reg.senderNumber || reg.phone}</span>
                          {reg.transactionId && (
                            <span className="text-emerald-700 text-[10px] font-bold block">Trx: {reg.transactionId}</span>
                          )}
                        </td>
                        <td className="py-3 px-3 font-sans">
                          {reg.status === 'PENDING_APPROVAL' ? (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
                              পেন্ডিং
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                              অনুমোদিত
                            </span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

      {/* ========================================================= */}
      {/* TAB 3: ROOM MANAGEMENT */}
      {/* ========================================================= */}
      {activeAdminTab === 'rooms' && (
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-red-600 block">
                CUSTOM ROOM CREDENTIALS
              </span>
              <h3 className="font-heading text-xl font-black text-slate-900 mt-0.5 flex items-center gap-2">
                <Key className="w-5 h-5 text-red-600" />
                কাস্টম রুম আইডি ও পাসওয়ার্ড রিলিজ
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                ম্যাচ শুরুর ১৫ মিনিট আগে রুম আইডি ও পাসওয়ার্ড বসিয়ে <strong className="text-emerald-600">রুম রিলিজ করুন</strong> বাটনে চাপ দিন। শুধুমাত্র অনুমোদিত ক্রেতারা তাদের My Matches অপশনে রুম আইডি দেখতে পারবেন।
              </p>
            </div>

            {/* Select Tournament */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                ম্যাচ নির্বাচন করুন *
              </label>
              <select
                value={selectedRoomTourId}
                onChange={(e) => setSelectedRoomTourId(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 font-bold text-xs focus:outline-none focus:border-red-600 cursor-pointer"
              >
                {tournaments.map(t => (
                  <option key={t.id} value={t.id}>
                    {t.title} ({t.time} • {t.joinedSlots}/{t.maxSlots} Slots)
                  </option>
                ))}
              </select>
            </div>

            {/* Room Credentials Input Fields */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 rounded-xl bg-slate-50 border border-slate-200">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  কাস্টম রুম আইডি (Room ID) *
                </label>
                <input
                  type="text"
                  placeholder="যেমন: 89324019"
                  value={adminRoomId}
                  onChange={(e) => setAdminRoomId(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 font-mono text-sm focus:outline-none focus:border-red-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  রুম পাসওয়ার্ড (Password) *
                </label>
                <input
                  type="text"
                  placeholder="যেমন: 7722"
                  value={adminRoomPassword}
                  onChange={(e) => setAdminRoomPassword(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 font-mono text-sm focus:outline-none focus:border-red-600"
                />
              </div>
            </div>

            {/* Current Visibility Status Banner */}
            <div className={`p-3.5 rounded-xl border flex items-center justify-between ${
              isRoomReleased 
                ? 'bg-emerald-50 border-emerald-300 text-emerald-900' 
                : 'bg-amber-50 border-amber-300 text-amber-900'
            }`}>
              <div className="flex items-center gap-2.5">
                {isRoomReleased ? <Unlock className="w-5 h-5 text-emerald-600" /> : <Lock className="w-5 h-5 text-amber-600" />}
                <div>
                  <h4 className="font-bold text-xs sm:text-sm">
                    {isRoomReleased ? 'রুম রিলিজ করা আছে (খেলোয়াড়রা দেখতে পাচ্ছে)' : 'রুম লক করা আছে (খেলোয়াড়দের কাছে গোপন)'}
                  </h4>
                  <p className="text-[11px] opacity-80">
                    {isRoomReleased 
                      ? 'অনুমোদিত খেলোয়াড়রা My Matches এ রুম আইডি ও পাসওয়ার্ড কপি করতে পারছে।' 
                      : 'খেলোয়াড়দের এখানে "রুম লকড - ম্যাচ শুরুর ১৫ মিনিট আগে প্রকাশ হবে" লেখা দেখাচ্ছে।'}
                  </p>
                </div>
              </div>
            </div>

            {/* Action Buttons: RELEASE ROOM, HIDE ROOM */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <button
                type="button"
                onClick={() => handleSaveRoomAction(true)}
                className="py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer transition-all"
              >
                <Unlock className="w-4 h-4" />
                <span>রুম রিলিজ করুন (RELEASE ROOM)</span>
              </button>

              <button
                type="button"
                onClick={() => handleSaveRoomAction(false)}
                className="py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center justify-center gap-2 border border-slate-200 cursor-pointer transition-all"
              >
                <Lock className="w-4 h-4" />
                <span>রুম লক রাখুন (HIDE / LOCK)</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* TAB 4: RESULTS & LEADERBOARD ENTRY */}
      {/* ========================================================= */}
      {activeAdminTab === 'results' && (
        <div className="space-y-4">
          
          {/* Result Entry Form Card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-red-600 block">
                OFFICIAL ESPORTS RULES
              </span>
              <h3 className="font-heading text-xl font-black text-slate-900 mt-0.5 flex items-center gap-2">
                <Flame className="w-5 h-5 text-red-600" />
                অফিসিয়াল পয়েন্ট টেবিল ও রেজাল্ট এন্ট্রি
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                ক্যাটাগরি ও ম্যাচ সিলেক্ট করে স্লট কেনা টিমের ওপর চাপ দিলেই নাম অটো-ফিল হবে। কিল ও পজিশন দিয়ে সেভ বা এডিট করুন।
              </p>
            </div>

            {/* 1. CATEGORY FILTER BUTTONS */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5 flex items-center justify-between">
                <span>১. ক্যাটাগরি ফিল্টার নির্বাচন করুন</span>
                <span className="text-[10px] text-red-600 font-bold">আলাদা আলাদা ক্যাটাগরি</span>
              </label>
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
                {[
                  { id: 'BR SCRIM', label: 'BR SCRIM' },
                  { id: 'BR BLAST', label: 'BR BLAST' },
                  { id: 'BR CHAMPION RUSH', label: 'BR CHAMPION RUSH' },
                  { id: 'CS 4V4', label: 'CS 4V4' },
                  { id: 'LONE WOLF', label: 'LONE WOLF' },
                  { id: 'FREE MATCH', label: 'FREE MATCH' },
                  { id: 'ALL', label: 'সবগুলো (ALL)' },
                ].map(cat => {
                  const isSelected = resultCategoryFilter === cat.id;
                  return (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => {
                        setResultCategoryFilter(cat.id);
                        const matchTour = cat.id === 'ALL' 
                          ? tournaments[0] 
                          : tournaments.find(t => (t.matchCategory || '').toUpperCase() === cat.id.toUpperCase());
                        if (matchTour) {
                          setResultTourId(matchTour.id);
                          handleCancelEdit();
                        }
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer whitespace-nowrap border ${
                        isSelected
                          ? 'bg-red-600 text-white border-red-600 shadow-sm'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:border-red-400 hover:text-red-600'
                      }`}
                    >
                      {cat.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 2. MATCH & TIME SELECTOR */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                ২. ম্যাচ ও সময় নির্বাচন করুন *
              </label>
              <select
                value={resultTourId}
                onChange={(e) => {
                  setResultTourId(e.target.value);
                  handleCancelEdit();
                }}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 text-xs font-bold focus:outline-none focus:border-red-600 cursor-pointer"
              >
                {filteredResultTournaments.length === 0 ? (
                  <option value="">এই ক্যাটাগরিতে কোনো টুর্নামেন্ট নেই</option>
                ) : (
                  filteredResultTournaments.map(t => (
                    <option key={t.id} value={t.id}>
                      {t.title} ({t.time} • {t.joinedSlots}/{t.maxSlots} টিম)
                    </option>
                  ))
                )}
              </select>
            </div>

            {/* 3. SLOT BUYERS ROSTER (QUICK AUTO-FILL & EDIT SELECTION) */}
            <div className="p-3.5 bg-gradient-to-r from-slate-50 to-amber-50/50 rounded-xl border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-slate-900 flex items-center gap-1.5 uppercase font-heading">
                  <Users className="w-4 h-4 text-red-600" />
                  ৩. স্লট কেনা টিমসমূহ (Slot Buyers) — চাপ দিলেই অটো-ফিল হবে:
                </span>
                <span className="text-[10px] text-slate-500 font-bold">
                  {tournamentSlotBuyers.length} টি টিম
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 pt-1">
                {tournamentSlotBuyers.map((t, idx) => {
                  const existingResult = currentTourResults.find(
                    r => r.teamName?.trim().toLowerCase() === t.teamName.trim().toLowerCase()
                  );
                  const isCurrentEditing = editingResultId === existingResult?.id;

                  return (
                    <button
                      key={`${t.teamName}-${idx}`}
                      type="button"
                      onClick={() => handleSelectSlotTeam(t)}
                      className={`p-2 rounded-xl text-left border transition-all cursor-pointer flex flex-col justify-between ${
                        isCurrentEditing
                          ? 'bg-amber-100 border-amber-500 ring-2 ring-amber-400 shadow-sm'
                          : existingResult
                          ? 'bg-white border-emerald-300 hover:border-emerald-500 hover:bg-emerald-50/50 shadow-xs'
                          : 'bg-white border-slate-200 hover:border-red-400 hover:bg-red-50/40 shadow-xs'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between text-[10px]">
                          <span className="font-mono font-bold text-slate-500">
                            স্লট #{t.slotNumber || idx + 1}
                          </span>
                          {existingResult ? (
                            <span className="text-emerald-700 font-bold bg-emerald-100 px-1.5 py-0.2 rounded font-mono text-[9px]">
                              ✓ #{existingResult.rank}
                            </span>
                          ) : (
                            <span className="text-amber-700 font-bold bg-amber-100 px-1.5 py-0.2 rounded font-mono text-[9px]">
                              বাকি
                            </span>
                          )}
                        </div>
                        <span className="font-black text-xs text-slate-950 block truncate mt-0.5">
                          {t.teamName}
                        </span>
                        <span className="text-[10px] text-slate-500 block truncate">
                          {t.playerName}
                        </span>
                      </div>
                      <div className="pt-1 mt-1 border-t border-slate-100 text-[9px] font-bold text-red-600">
                        {existingResult ? '✏️ চাপ দিয়ে এডিট করুন' : '➕ সিলেক্ট করুন'}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 4. EDIT MODE ACTIVE BANNER */}
            {editingResultId && (
              <div className="p-3 rounded-xl bg-amber-50 border-2 border-amber-400 text-amber-950 flex items-center justify-between animate-fade-in shadow-sm">
                <div className="flex items-center gap-2 text-xs">
                  <Edit className="w-4 h-4 text-amber-700 shrink-0" />
                  <div>
                    <span className="font-black block font-sans">
                      ✏️ এডিট মোড চালু আছে: "{resTeamName}"
                    </span>
                    <span className="text-[11px] text-amber-800">
                      কিল, পজিশন বা Booyah পরিবর্তন করে নিচে <strong>"পয়েন্ট আপডেট করুন"</strong> বাটনে চাপ দিন।
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleCancelEdit}
                  className="px-2.5 py-1 rounded-lg bg-white border border-amber-300 hover:bg-amber-100 text-amber-900 text-xs font-bold cursor-pointer transition-colors shrink-0"
                >
                  ✕ বাতিল (নতুন মোড)
                </button>
              </div>
            )}

            {/* 5. RULES QUICK BAR */}
            {isSelectedTourCSorLW ? (
              <div className="p-3 bg-gradient-to-r from-red-950 via-slate-900 to-amber-950 text-white rounded-xl border border-red-700/60 space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-black text-amber-400 text-[11px] uppercase flex items-center gap-1.5">
                    <Crown className="w-4 h-4 text-amber-400" />
                    CS 4V4 ও LONE WOLF পয়েন্ট নিয়ম
                  </span>
                  <span className="text-[10px] bg-amber-500/30 text-amber-300 border border-amber-500/40 px-2 py-0.5 rounded font-bold">
                    যার বেশি Booyah = একক Champion
                  </span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  এই মোডের পয়েন্ট টেবিলে শুধুমাত্র <strong className="text-amber-400">BOOYAH সংখ্যা</strong> এবং <strong className="text-white">ম্যাচ সংখ্যা</strong> প্রদর্শিত হবে। যার বেশি Booyah থাকবে সে শুধু <strong className="text-amber-300">Champion</strong> হবে। লিডারবোর্ডে রানার-আপ বা ৩য় স্থান দেখানো হবে না।
                </p>
              </div>
            ) : null}

            {/* 6. RESULT INPUT & EDIT FORM */}
            <form onSubmit={handleAddResult} className="space-y-3">
              
              {/* CHAMPION RUSH: CUSTOM CHAMPION DESIGNATION OPTION */}
              {isChampionRush && (
                <div className="p-3.5 rounded-xl bg-gradient-to-r from-amber-50 via-orange-50 to-red-50 border-2 border-amber-400 flex items-center justify-between gap-3 shadow-sm">
                  <div className="flex items-center gap-2.5">
                    <Crown className="w-5 h-5 text-amber-600 shrink-0" />
                    <div>
                      <h4 className="font-heading font-black text-xs text-slate-900">
                        👑 সরাসরি Champion নির্ধারণ করুন (Admin Choice Champion)
                      </h4>
                      <p className="text-[11px] text-slate-600 mt-0.5">
                        যাকে খুশি Champion দিন! এই টিমটি Champion (#1) হবে এবং বাকি যাদের পয়েন্ট বেশি তারা Runner-up (#2) ও 3rd place (#3) হবে।
                      </p>
                    </div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer shrink-0">
                    <input 
                      type="checkbox" 
                      checked={resIsDesignatedChampion} 
                      onChange={(e) => {
                        setResIsDesignatedChampion(e.target.checked);
                        if (e.target.checked) {
                          setResRank(1);
                        }
                      }}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500"></div>
                  </label>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                
                {/* Team Name */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    টিম নেম (TEAM NAME) *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: Apex BD Squad"
                    value={resTeamName}
                    onChange={(e) => setResTeamName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 text-xs focus:outline-none focus:border-red-600 font-bold"
                  />
                </div>

                {/* Player Name */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    প্লেয়ার নাম / IGN *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: 亗 RAVEN 亗"
                    value={resPlayerName}
                    onChange={(e) => setResPlayerName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 text-xs focus:outline-none focus:border-red-600"
                  />
                </div>

                {/* Free Fire UID */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Free Fire UID
                  </label>
                  <input
                    type="text"
                    placeholder="যেমন: 2948291048"
                    value={resFfUid}
                    onChange={(e) => setResFfUid(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 font-mono text-xs focus:outline-none focus:border-red-600"
                  />
                </div>

                {/* Position / Rank (1-12) */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1 flex items-center justify-between">
                    <span>পজিশন / র‍্যাংক (১-১২) *</span>
                    <span className="text-[10px] text-amber-700 font-bold">অটো পয়েন্ট</span>
                  </label>
                  <select
                    value={resRank}
                    onChange={(e) => handleRankChange(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-amber-50/60 border border-amber-300 text-slate-900 font-bold text-xs focus:outline-none focus:border-red-600"
                  >
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(r => (
                      <option key={r} value={r}>
                        #{r} পজিশন ({FF_OFFICIAL_PLACEMENT_POINTS[r]} পয়েন্ট{r === 1 ? ' - 👑 BOOYAH' : ''})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Kills (Each kill = 1 pt) */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1 flex items-center justify-between">
                    <span>কিল সংখ্যা (Kills) *</span>
                    <span className="text-[10px] text-red-600 font-bold">১ কিল = ১ পয়েন্ট</span>
                  </label>
                  <input
                    type="number"
                    min={0}
                    required
                    placeholder="0"
                    value={resKills}
                    onChange={(e) => setResKills(Math.max(0, Number(e.target.value)))}
                    className="w-full px-3 py-2 rounded-xl bg-red-50/50 border border-red-300 text-slate-900 font-mono text-xs focus:outline-none focus:border-red-600 font-bold"
                  />
                </div>

                {/* Placement Points */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    প্লেসমেন্ট পয়েন্ট (অফিসিয়াল)
                  </label>
                  <input
                    type="number"
                    min={0}
                    required
                    value={resPlacementPoints}
                    onChange={(e) => setResPlacementPoints(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 font-mono text-xs font-bold"
                  />
                </div>

                {/* Matches Played */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    ম্যাচ সংখ্যা (Matches)
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={resMatchesPlayed}
                    onChange={(e) => setResMatchesPlayed(Math.max(1, Number(e.target.value)))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 font-mono text-xs"
                  />
                </div>

                {/* Booyah Count */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Booyah সংখ্যা
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={resBooyahs}
                    onChange={(e) => setResBooyahs(Math.max(0, Number(e.target.value)))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-300 text-amber-700 font-mono text-xs font-bold"
                  />
                </div>

                {/* Prize won */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    পুরস্কার টাকা (৳ BDT)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={resPrizeWon}
                    onChange={(e) => setResPrizeWon(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-300 text-emerald-700 font-mono text-xs font-bold"
                  />
                </div>

                {/* Live Total Points Preview Banner */}
                <div className="sm:col-span-3 p-3 rounded-xl bg-amber-50 border border-amber-300 flex items-center justify-between font-mono">
                  <div>
                    <span className="text-[10px] text-amber-900 uppercase font-black block font-sans">
                      অটো ক্যালকুলেটেড সর্বমোট পয়েন্ট (TOTAL POINTS)
                    </span>
                    <span className="text-xs text-amber-900 mt-0.5 block">
                      প্লেসমেন্ট পয়েন্ট: <strong>{resPlacementPoints}</strong> + কিল পয়েন্ট: <strong>{resKills}</strong> ({resKills} কিল × ১)
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="font-heading font-black text-2xl text-red-600">
                      {calculatedTotalPoints} PTS
                    </span>
                  </div>
                </div>
              </div>

              {/* Form Buttons: Save / Update + Cancel */}
              <div className="flex items-center gap-2 pt-1">
                <button
                  type="submit"
                  className="flex-1 py-3 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs uppercase tracking-wider cursor-pointer shadow-md transition-all flex items-center justify-center gap-1.5"
                >
                  <Save className="w-4 h-4" />
                  <span>{editingResultId ? 'পয়েন্ট আপডেট করুন (UPDATE RESULT)' : 'পয়েন্ট সংরক্ষণ করুন (SAVE RESULT)'}</span>
                </button>
                {editingResultId && (
                  <button
                    type="button"
                    onClick={handleCancelEdit}
                    className="py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs cursor-pointer border border-slate-300 transition-all"
                  >
                    বাতিল
                  </button>
                )}
              </div>
            </form>
          </div>

          {/* Table of Already Entered Results for this Tournament */}
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-heading font-black text-sm text-slate-900">
                  বর্তমান পয়েন্ট টেবিল ({currentTourResults.length} টি টিম)
                </h4>
                <p className="text-[11px] text-slate-500">
                  কিল বা পজিশন বদলাতে "এডিট" চাপুন অথবা চ্যাম্পিয়ন নির্ধারণ করুন।
                </p>
              </div>
              <span className="text-[10px] font-bold text-slate-400">
                ভুল এন্ট্রি হলে ডিলিট করতে পারেন
              </span>
            </div>

            {currentTourResults.length === 0 ? (
              <p className="text-xs text-slate-400 py-6 text-center">
                এই টুর্নামেন্টে এখনও কোনো পয়েন্ট যোগ করা হয়নি। উপরের স্লট কেনা টিমের ওপর চাপ দিয়ে কিল ও পজিশন দিন।
              </p>
            ) : (
              <div className="overflow-x-auto">
                {isSelectedTourCSorLW ? (
                  <table className="w-full text-left text-xs font-mono border-collapse">
                    <thead className="bg-slate-100 text-slate-600 uppercase text-[10px] font-black border-b border-slate-200">
                      <tr>
                        <th className="py-2 px-2 text-center">#</th>
                        <th className="py-2 px-3 font-sans">TEAM / SQUAD</th>
                        <th className="py-2 px-2 text-center">MATCH</th>
                        <th className="py-2 px-2 text-center text-amber-600 font-black">👑 BOOYAH</th>
                        <th className="py-2 px-2 text-center text-emerald-600">PRIZE (৳)</th>
                        <th className="py-2 px-2 text-right">ACTION</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {currentTourResults.map(res => (
                        <tr key={res.id} className="hover:bg-slate-50 font-mono">
                          <td className="py-2.5 px-2 text-center font-bold text-slate-900">
                            #{res.rank}
                          </td>
                          <td className="py-2.5 px-3 font-sans">
                            <span className="font-bold text-slate-900 block truncate max-w-[140px]">{res.teamName || 'Solo'}</span>
                            <span className="text-[10px] text-slate-400 block">{res.playerName}</span>
                          </td>
                          <td className="py-2.5 px-2 text-center text-slate-600 font-bold">{res.matchesPlayed || 1}</td>
                          <td className="py-2.5 px-2 text-center text-amber-600 font-black text-sm bg-amber-50/60">
                            👑 {res.booyahs || 0}
                          </td>
                          <td className="py-2.5 px-2 text-center text-emerald-600 font-bold">
                            {res.prizeWon ? `৳${res.prizeWon}` : '-'}
                          </td>
                          <td className="py-2.5 px-2 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => handleStartEditRow(res)}
                                className="p-1.5 rounded-lg bg-amber-50 text-amber-700 hover:bg-amber-100 cursor-pointer flex items-center gap-1 font-sans text-[11px] font-bold"
                                title="এডিট করুন"
                              >
                                <Edit className="w-3 h-3" />
                                <span>এডিট</span>
                              </button>
                              <button
                                onClick={() => handleDeleteResultItem(res.id)}
                                className="p-1.5 rounded-lg text-red-600 hover:bg-red-50 cursor-pointer"
                                title="মুছে ফেলুন"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : (
                  <table className="w-full text-left text-xs font-mono border-collapse">
                    <thead className="bg-slate-100 text-slate-600 uppercase text-[10px] font-black border-b border-slate-200">
                      <tr>
                        <th className="py-2 px-2 text-center">#</th>
                        <th className="py-2 px-3 font-sans">TEAM / SQUAD</th>
                        <th className="py-2 px-2 text-center">MATCH</th>
                        <th className="py-2 px-2 text-center">BOOYAH</th>
                        <th className="py-2 px-2 text-center">PLACE</th>
                        <th className="py-2 px-2 text-center text-red-600">KILLS</th>
                        <th className="py-2 px-2 text-center font-black">TOTAL</th>
                        <th className="py-2 px-2 text-right">ACTION</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {currentTourResults.map(res => (
                        <tr key={res.id} className="hover:bg-slate-50 font-mono">
                          <td className="py-2.5 px-2 text-center font-bold text-slate-900">
                            #{res.rank}
                          </td>
                          <td className="py-2.5 px-3 font-sans">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-bold text-slate-900 block truncate max-w-[140px]">{res.teamName || 'Solo'}</span>
                              {res.isDesignatedChampion && (
                                <span className="bg-amber-500 text-white text-[9px] px-1.5 py-0.2 rounded font-black flex items-center gap-0.5">
                                  👑 CHAMPION
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] text-slate-400 block">{res.playerName}</span>
                          </td>
                          <td className="py-2.5 px-2 text-center text-slate-600">{res.matchesPlayed || 1}</td>
                          <td className="py-2.5 px-2 text-center text-amber-600 font-bold">{res.booyahs || 0}</td>
                          <td className="py-2.5 px-2 text-center text-slate-700">{res.placementPoints}</td>
                          <td className="py-2.5 px-2 text-center text-red-600 font-bold">{res.kills}</td>
                          <td className="py-2.5 px-2 text-center font-black text-slate-950 bg-amber-50/60">{res.totalPoints} PTS</td>
                          <td className="py-2.5 px-2 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {isChampionRush && (
                                <button
                                  type="button"
                                  onClick={() => handleMakeDesignatedChampion(res.id)}
                                  className={`p-1.5 rounded-lg text-[10px] font-sans font-bold flex items-center gap-1 cursor-pointer transition-colors ${
                                    res.isDesignatedChampion
                                      ? 'bg-amber-500 text-white shadow-xs'
                                      : 'bg-amber-50 text-amber-800 hover:bg-amber-100 border border-amber-200'
                                  }`}
                                  title="এই টিমকে সরাসরি Champion করুন"
                                >
                                  <Crown className="w-3 h-3 text-amber-300" />
                                  <span>{res.isDesignatedChampion ? 'Champion ✓' : 'Champion দিন'}</span>
                                </button>
                              )}
                              <button
                                onClick={() => handleStartEditRow(res)}
                                className="p-1.5 rounded-lg bg-amber-50 text-amber-700 hover:bg-amber-100 cursor-pointer flex items-center gap-1 font-sans text-[11px] font-bold"
                                title="এডিট করুন"
                              >
                                <Edit className="w-3 h-3" />
                                <span>এডিট</span>
                              </button>
                              <button
                                onClick={() => handleDeleteResultItem(res.id)}
                                className="p-1.5 rounded-lg text-red-600 hover:bg-red-50 cursor-pointer"
                                title="মুছে ফেলুন"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            )}
          </div>

        </div>
      )}

      {/* ========================================================= */}
      {/* TAB 5: TOURNAMENTS CREATE & MANAGE */}
      {/* ========================================================= */}
      {activeAdminTab === 'tournaments' && (
        <div className="space-y-4">
          
          {/* Create / Edit Form */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-heading text-lg font-black text-slate-900 flex items-center gap-2">
                <Plus className="w-5 h-5 text-red-600" />
                {isEditingTournament ? 'টুর্নামেন্ট এডিট করুন' : 'নতুন টুর্নামেন্ট তৈরি করুন'}
              </h3>
              {isEditingTournament && (
                <button
                  onClick={resetTourForm}
                  className="text-xs text-red-600 hover:underline font-bold"
                >
                  বাতিল (নতুন তৈরি করুন)
                </button>
              )}
            </div>

            {/* One-Click Category Presets */}
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5">
                ক্যাটাগরি প্রিসেট (১-ক্লিকে সঠিক এন্ট্রি ফি ও প্রাইজ পূরণ)
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  { id: 'BR SCRIM', title: 'BR SCRIM (40৳, 12 টিম)', color: 'border-red-300' },
                  { id: 'BR BLAST', title: 'BR BLAST (50৳, 12 টিম)', color: 'border-orange-300' },
                  { id: 'BR CHAMPION RUSH', title: 'CHAMPION RUSH (80৳)', color: 'border-amber-300' },
                  { id: 'CS 4V4', title: 'CS 4V4 (50৳, 4 টিম)', color: 'border-cyan-300' },
                  { id: 'LONE WOLF', title: 'LONE WOLF (50৳, 2 টিম)', color: 'border-purple-300' },
                  { id: 'FREE MATCH', title: 'FREE MATCH (0৳)', color: 'border-emerald-300' },
                ].map(cat => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => applyCategoryPreset(cat.id)}
                    className={`py-2 px-3 rounded-xl text-xs font-heading font-black border transition-all text-left cursor-pointer ${
                      tourCategory === cat.id
                        ? 'bg-red-600 text-white border-red-600 shadow-sm'
                        : `bg-slate-50 hover:bg-slate-100 text-slate-700 ${cat.color}`
                    }`}
                  >
                    {cat.title}
                  </button>
                ))}
              </div>
            </div>

            <form onSubmit={handleSaveTournament} className="space-y-3 pt-2">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                
                {/* Title */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    টুর্নামেন্ট নাম (Tournament Title) *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: BR SCRIM"
                    value={tourTitle}
                    onChange={(e) => setTourTitle(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 text-xs font-bold focus:outline-none focus:border-red-600"
                  />
                </div>

                {/* Map */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    ম্যাপ (Map) *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: B. P. K"
                    value={tourMap}
                    onChange={(e) => setTourMap(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 text-xs font-bold focus:outline-none focus:border-red-600"
                  />
                </div>

                {/* Date */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    তারিখ (Date) *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="DD/MM/YYYY"
                    value={tourDate}
                    onChange={(e) => setTourDate(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 text-xs font-mono focus:outline-none focus:border-red-600"
                  />
                </div>

                {/* Start Time */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    ম্যাচ শুরু সময় (Time) *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: 10:00 PM"
                    value={tourTime}
                    onChange={(e) => setTourTime(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 text-xs font-mono focus:outline-none focus:border-red-600"
                  />
                </div>

                {/* Slots */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    সর্বমোট টিম / স্লট (Max Slots) *
                  </label>
                  <input
                    type="number"
                    required
                    min={2}
                    max={12}
                    value={tourMaxSlots}
                    onChange={(e) => setTourMaxSlots(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 text-xs font-mono focus:outline-none focus:border-red-600"
                  />
                </div>

                {/* Entry Fee */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    এন্ট্রি ফি (৳ BDT)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={tourEntryFee}
                    onChange={(e) => setTourEntryFee(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 text-xs font-mono focus:outline-none focus:border-red-600"
                  />
                </div>

                {/* Total Prize Pool */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    সর্বমোট প্রাইজ পুল (৳ BDT) *
                  </label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={tourPrizePool}
                    onChange={(e) => setTourPrizePool(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 text-xs font-mono focus:outline-none focus:border-red-600"
                  />
                </div>

                {/* 1st, 2nd, 3rd Prize */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    ১ম স্থান প্রাইজ (৳)
                  </label>
                  <input
                    type="number"
                    value={tourFirstPrize}
                    onChange={(e) => setTourFirstPrize(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    ২য় স্থান প্রাইজ (৳)
                  </label>
                  <input
                    type="number"
                    value={tourSecondPrize}
                    onChange={(e) => setTourSecondPrize(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 text-xs font-mono"
                  />
                </div>

                {/* Status */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    স্ট্যাটাস (Status)
                  </label>
                  <select
                    value={tourStatus}
                    onChange={(e) => setTourStatus(e.target.value as any)}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 text-xs font-bold"
                  >
                    <option value="OPEN">OPEN (রেজিস্ট্রেশন চালু)</option>
                    <option value="LIVE">LIVE (ম্যাচ চলমান)</option>
                    <option value="COMPLETED">COMPLETED (ম্যাচ শেষ)</option>
                    <option value="CANCELLED">CANCELLED (বাতিল)</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>{isEditingTournament ? 'টুর্নামেন্ট আপডেট করুন' : 'টুর্নামেন্ট পাবলিশ করুন'}</span>
              </button>
            </form>
          </div>

          {/* Manage Existing Tournaments */}
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-3">
            <h3 className="font-heading font-black text-base text-slate-900">
              বর্তমান টুর্নামেন্টসমূহ ({tournaments.length} টি)
            </h3>

            <div className="space-y-2.5">
              {tournaments.map(tour => (
                <div
                  key={tour.id}
                  className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[10px] font-black px-2 py-0.5 rounded bg-red-100 text-red-700">
                        {tour.matchCategory || 'Squad'}
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-200 text-slate-700">
                        {tour.map}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        tour.status === 'LIVE' ? 'bg-red-600 text-white' : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {tour.status}
                      </span>
                    </div>
                    <h4 className="font-black text-slate-900 text-sm">{tour.title}</h4>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {tour.date} • {tour.time} • {tour.joinedSlots}/{tour.maxSlots} টিম • ফি: ৳{tour.entryFee} • প্রাইজ: ৳{tour.prizePool}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleEditTournamentInit(tour)}
                      className="py-1.5 px-3 rounded-lg bg-white border border-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1 cursor-pointer hover:bg-slate-100"
                    >
                      <Edit className="w-3.5 h-3.5" />
                      <span>এডিট</span>
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`"${tour.title}" টুর্নামেন্টটি মুছে ফেলতে চান?`)) {
                          adminDeleteTournament(tour.id);
                          showSuccess('টুর্নামেন্ট মুছে ফেলা হয়েছে।');
                        }
                      }}
                      className="py-1.5 px-3 rounded-lg bg-red-50 text-red-600 border border-red-200 text-xs font-bold flex items-center gap-1 cursor-pointer hover:bg-red-100"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>মুছুন</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* ========================================================= */}
      {/* TAB 6: NOTIFICATIONS & ANNOUNCEMENTS */}
      {/* ========================================================= */}
      {activeAdminTab === 'notifications' && (
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-red-600 block">
                BROADCAST ANNOUNCEMENT
              </span>
              <h3 className="font-heading text-xl font-black text-slate-900 mt-0.5 flex items-center gap-2">
                <Bell className="w-5 h-5 text-red-600" />
                সকল ইউজারদের জন্য নোটিশ ও ঘোষণা
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                জরুরি রুম নোটিশ, ম্যাচ আপডেট বা টুর্নামেন্ট শুরুর বার্তা অ্যাপের নোটিশ বোর্ড ও প্লেয়ার নোটিফিকেশনে সরাসরি চলে যাবে।
              </p>
            </div>

            <form onSubmit={handleSendBroadcast} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  নোটিশ শিরোনাম (Title) *
                </label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: 📢 জরুরি ম্যাচ শিডিউল ও রুম আইডি নোটিশ"
                  value={broadcastTitle}
                  onChange={(e) => setBroadcastTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 text-xs focus:outline-none focus:border-red-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  বিস্তারিত বার্তা (Message Details) *
                </label>
                <textarea
                  required
                  rows={3}
                  placeholder="প্লেয়ারদের জন্য বিস্তারিত বার্তা লিখুন..."
                  value={broadcastMessage}
                  onChange={(e) => setBroadcastMessage(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 text-xs focus:outline-none focus:border-red-600"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
              >
                <Send className="w-4 h-4" />
                <span>নোটিশ সম্প্রচার করুন (BROADCAST NOTICE)</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* TAB 7: SETTINGS & PAYMENT NUMBER CONFIG */}
      {/* ========================================================= */}
      {activeAdminTab === 'settings' && (
        <div className="space-y-4">
          
          {/* Payment Number Configuration */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-red-600 block">
                PAYMENT NUMBER SETTINGS
              </span>
              <h3 className="font-heading text-xl font-black text-slate-900 mt-0.5 flex items-center gap-2">
                <Phone className="w-5 h-5 text-red-600" />
                NINEX অফিসিয়াল বিকাশ ও নগদ পেমেন্ট নম্বর
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                প্লেয়াররা টুর্নামেন্ট কেনার সময় যে বিকাশ বা নগদ পার্সোনাল নম্বরে সেন্ড মানি করবে, সেটি এখানে সেট করুন।
              </p>
            </div>

            <form onSubmit={handleSavePaymentNumber} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  bKash / Nagad Personal Receiver Number *
                </label>
                <input
                  type="tel"
                  required
                  placeholder="01XXXXXXXXX"
                  value={adminPaymentNum}
                  onChange={(e) => setAdminPaymentNum(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-300 font-mono text-base font-black text-slate-900 focus:outline-none focus:border-red-600"
                />
              </div>

              <button
                type="submit"
                className="py-2.5 px-6 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs uppercase tracking-wider shadow-md cursor-pointer flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                <span>পেমেন্ট নম্বর সংরক্ষণ করুন</span>
              </button>
            </form>
          </div>

          {/* Reset Demo Data */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-3">
            <h4 className="font-heading font-black text-sm text-slate-900">
              প্ল্যাটফর্ম ডেমো ডেটা রিসেট
            </h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              যদি টেস্ট ডেটা বা ডেমো টুর্নামেন্টগুলো আবার প্রাথমিক অবস্থায় ফিরিয়ে নিতে চান, তবে নিচের বাটনে ক্লিক করুন।
            </p>
            <button
              onClick={() => {
                if (confirm('সকল ডেমো টুর্নামেন্ট, রুম ও রেজিস্ট্রেশন আবার প্রাথমিক অবস্থায় রিসেট করতে চান?')) {
                  resetAllDemoData();
                  showSuccess('ডেমো ডেটা রিসেট সফল হয়েছে।');
                }
              }}
              className="py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-red-50 text-slate-700 hover:text-red-600 border border-slate-200 hover:border-red-200 font-bold text-xs cursor-pointer transition-colors"
            >
              রিসেট ডেমো ডেটা (Reset All Data)
            </button>
          </div>

        </div>
      )}

    </div>
  );
};
