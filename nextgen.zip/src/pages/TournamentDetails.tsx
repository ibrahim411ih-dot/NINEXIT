import React from 'react';
import { ArrowLeft, Calendar, Clock, MapPin, Users, Trophy, Coins, ShieldCheck, Flame, AlertCircle, Share2, Sparkles, CheckCircle2 } from 'lucide-react';
import { Tournament } from '../types';
import { useTournaments } from '../context/TournamentContext';

interface TournamentDetailsProps {
  tournament: Tournament | null;
  onBack: () => void;
  onJoin: (tournament: Tournament) => void;
  onViewMyMatch: (tournament: Tournament) => void;
}

export const TournamentDetails: React.FC<TournamentDetailsProps> = ({
  tournament,
  onBack,
  onJoin,
  onViewMyMatch,
}) => {
  const { isRegisteredFor, userRegistrations } = useTournaments();

  if (!tournament) return null;

  const registered = isRegisteredFor(tournament.id);
  const userReg = userRegistrations.find(r => r.tournamentId === tournament.id);
  const slotPercentage = Math.min(100, Math.round((tournament.joinedSlots / tournament.maxSlots) * 100));

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-16 font-bangla">
      
      {/* Top Back Navigation */}
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-xs font-bold text-slate-400 hover:text-cyan-400 transition-colors cursor-pointer group"
      >
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
        <span>সকল টুর্নামেন্টে ফিরে যান (BACK TO TOURNAMENTS)</span>
      </button>

      {/* Hero Banner Section */}
      <div className="relative rounded-3xl overflow-hidden border border-slate-800 bg-slate-900 shadow-2xl">
        <div className="h-64 sm:h-80 w-full relative">
          <img
            src={tournament.bannerUrl}
            alt={tournament.title}
            className="w-full h-full object-cover filter brightness-90"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#060913] via-[#060913]/60 to-transparent" />
        </div>

        {/* Content Floating on Banner bottom */}
        <div className="p-6 sm:p-8 -mt-24 relative z-10 space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-3 py-1 rounded-xl bg-cyan-500 text-black font-extrabold text-xs uppercase tracking-wider">
              {tournament.mode}
            </span>
            <span className="px-3 py-1 rounded-xl bg-slate-900/90 border border-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-cyan-400" />
              {tournament.map}
            </span>
            <span className="px-3 py-1 rounded-xl bg-slate-900/90 border border-slate-700 text-slate-300 text-xs font-semibold">
              Game: {tournament.game}
            </span>
          </div>

          <h1 className="font-heading text-3xl sm:text-4xl font-black text-white leading-tight">
            {tournament.title}
          </h1>

          {/* Already registered banner */}
          {registered && (
            <div className="p-3.5 rounded-2xl bg-emerald-500/15 border border-emerald-500/40 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5 text-emerald-300 text-xs font-bold">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                <span>
                  You are registered for this match! {userReg?.slotNumber ? `(Slot #${userReg.slotNumber})` : ''}
                </span>
              </div>
              <button
                onClick={() => onViewMyMatch(tournament)}
                className="py-1.5 px-3 rounded-xl bg-emerald-500 text-black font-black text-xs hover:bg-emerald-400 transition-colors shrink-0 cursor-pointer"
              >
                VIEW ROOM ID
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Main Grid: Meta & Rules & Prize Info */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Left Column (2 Cols): Schedule, Rules & Details */}
        <div className="md:col-span-2 space-y-6">
          
          {/* Key Schedule Card */}
          <div className="p-5 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-4">
            <h3 className="font-heading text-lg font-bold text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-cyan-400" />
              SCHEDULE & TIMINGS
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-850">
                <span className="text-[10px] text-slate-500 uppercase font-bold block">Match Date</span>
                <span className="text-xs font-bold text-white mt-1 block">{tournament.date}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-850">
                <span className="text-[10px] text-slate-500 uppercase font-bold block">Start Time</span>
                <span className="text-xs font-bold text-cyan-400 mt-1 block">{tournament.time}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-850 col-span-2 sm:col-span-1">
                <span className="text-[10px] text-slate-500 uppercase font-bold block">Reg Deadline</span>
                <span className="text-xs font-bold text-amber-300 mt-1 block">{tournament.regDeadline}</span>
              </div>
            </div>
          </div>

          {/* Tournament Rules & Regulations */}
          <div className="p-5 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-4">
            <h3 className="font-heading text-lg font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
              TOURNAMENT RULES & FAIR PLAY
            </h3>

            <div className="space-y-2.5">
              {tournament.rules.map((rule, idx) => (
                <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-300">
                  <span className="w-5 h-5 rounded-full bg-cyan-950 border border-cyan-800 text-cyan-400 font-bold flex items-center justify-center shrink-0 text-[10px] mt-0.5">
                    {idx + 1}
                  </span>
                  <span className="leading-relaxed">{rule}</span>
                </div>
              ))}
            </div>

            {/* Note on room release */}
            <div className="p-3.5 rounded-xl bg-cyan-950/30 border border-cyan-800/40 text-xs text-slate-300 flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
              <p>
                <strong className="text-cyan-300">Room Release Policy:</strong> Room ID & Password will be unlocked in your <strong className="text-white">"My Matches"</strong> page 15 minutes before the match start time. An instant in-app notification will notify all registered players.
              </p>
            </div>
          </div>

        </div>

        {/* Right Column (1 Col): Prize Distribution & Action Card */}
        <div className="space-y-6">
          
          {/* Action / Slot Status Box */}
          <div className="p-5 rounded-2xl bg-slate-900/90 border border-cyan-500/30 space-y-4 shadow-xl">
            <div className="flex justify-between items-center">
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase">Entry Fee</span>
                <p className="font-heading text-2xl font-black text-white">
                  {tournament.entryFee === 0 ? (
                    <span className="text-emerald-400">FREE ENTRY</span>
                  ) : (
                    <span>৳ {tournament.entryFee} BDT</span>
                  )}
                </p>
              </div>
              <div className="text-right">
                <span className="text-[10px] font-bold text-slate-400 uppercase">Available Slots</span>
                <p className="font-heading text-xl font-black text-cyan-400">
                  {tournament.maxSlots - tournament.joinedSlots} Left
                </p>
              </div>
            </div>

            {/* Progress Bar */}
            <div>
              <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                <span>Filled: {tournament.joinedSlots}/{tournament.maxSlots}</span>
                <span>{slotPercentage}%</span>
              </div>
              <div className="w-full h-2 rounded-full bg-slate-950 overflow-hidden border border-slate-800">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-blue-500 transition-all"
                  style={{ width: `${slotPercentage}%` }}
                />
              </div>
            </div>

            {/* Big Action CTA */}
            {registered ? (
              <button
                onClick={() => onViewMyMatch(tournament)}
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-black font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25 transition-all cursor-pointer"
              >
                <ShieldCheck className="w-5 h-5" />
                <span>VIEW MY MATCH & ROOM ID</span>
              </button>
            ) : tournament.status === 'FULL' || tournament.joinedSlots >= tournament.maxSlots ? (
              <button
                disabled
                className="w-full py-3.5 px-4 rounded-xl bg-slate-800 text-slate-500 font-black text-sm flex items-center justify-center gap-2 cursor-not-allowed"
              >
                <span>SLOTS MAXIMUM FILLED</span>
              </button>
            ) : (
              <button
                onClick={() => onJoin(tournament)}
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-black text-sm flex items-center justify-center gap-2 shadow-xl shadow-cyan-500/30 active:scale-95 transition-all cursor-pointer"
              >
                <Sparkles className="w-5 h-5 fill-black" />
                <span>JOIN TOURNAMENT</span>
              </button>
            )}

            <p className="text-[10px] text-center text-slate-400">
              Payment method: bKash / Nagad (Demo mode enabled)
            </p>
          </div>

          {/* Prize Breakdown Table */}
          <div className="p-5 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-4">
            <h3 className="font-heading text-lg font-bold text-white flex items-center gap-2">
              <Trophy className="w-4 h-4 text-amber-400" />
              PRIZE POOL BREAKDOWN
            </h3>

            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-center">
              <span className="text-[10px] font-bold text-amber-400 uppercase">Total Prize Pool</span>
              <p className="font-heading text-3xl font-black text-amber-300">
                ৳ {tournament.prizePool.toLocaleString()}
              </p>
            </div>

            <div className="space-y-2 text-xs divide-y divide-slate-800/60">
              {tournament.prizeDetails.first && (
                <div className="flex justify-between items-center pt-2 first:pt-0">
                  <span className="font-bold text-amber-400 flex items-center gap-1.5">
                    🥇 1st Place (Booyah)
                  </span>
                  <span className="font-heading text-base font-black text-white">
                    ৳ {tournament.prizeDetails.first.toLocaleString()}
                  </span>
                </div>
              )}
              {tournament.prizeDetails.second && (
                <div className="flex justify-between items-center pt-2">
                  <span className="font-bold text-slate-300 flex items-center gap-1.5">
                    🥈 2nd Place
                  </span>
                  <span className="font-heading text-base font-black text-white">
                    ৳ {tournament.prizeDetails.second.toLocaleString()}
                  </span>
                </div>
              )}
              {tournament.prizeDetails.third && (
                <div className="flex justify-between items-center pt-2">
                  <span className="font-bold text-amber-600 flex items-center gap-1.5">
                    🥉 3rd Place
                  </span>
                  <span className="font-heading text-base font-black text-white">
                    ৳ {tournament.prizeDetails.third.toLocaleString()}
                  </span>
                </div>
              )}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
