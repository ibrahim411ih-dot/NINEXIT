import React from 'react';
import { Home, Swords, Gamepad2, Award, User } from 'lucide-react';
import { useTournaments } from '../context/TournamentContext';

interface BottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, setActiveTab }) => {
  const { userRegistrations } = useTournaments();
  const joinedCount = userRegistrations.length;

  const navItems = [
    { id: 'home', label: 'Play', icon: Home },
    { id: 'my-matches', label: 'My Matches', icon: Gamepad2, badge: joinedCount > 0 ? joinedCount : undefined },
    { id: 'leaderboard', label: 'Result', icon: Award },
    { id: 'profile', label: 'Me', icon: User },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200 pb-safe shadow-lg font-bangla">
      <div className="max-w-xl mx-auto grid grid-cols-4 h-15">
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`relative flex flex-col items-center justify-center gap-1 transition-all focus:outline-none cursor-pointer ${
                isActive ? 'text-red-600 font-black' : 'text-slate-500 hover:text-slate-800 font-semibold'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110 stroke-[2.5]' : 'stroke-2'}`} />
                {item.badge && (
                  <span className="absolute -top-1.5 -right-2 min-w-4 h-4 px-1 rounded-full bg-red-600 text-white text-[9px] font-black flex items-center justify-center ring-2 ring-white">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="text-[11px] tracking-tight">
                {item.label}
              </span>
              {isActive && (
                <div className="absolute top-0 w-8 h-1 bg-red-600 rounded-full" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
