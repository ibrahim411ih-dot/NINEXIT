import React, { useState } from 'react';
import { X, Lock, Unlock, Copy, Check, Key } from 'lucide-react';
import { Tournament } from '../types';
import { useTournaments } from '../context/TournamentContext';

interface RoomModalProps {
  tournament: Tournament | null;
  isOpen: boolean;
  onClose: () => void;
  onJoinPrompt?: () => void;
}

export const RoomModal: React.FC<RoomModalProps> = ({
  tournament,
  isOpen,
  onClose,
  onJoinPrompt,
}) => {
  const { getRoomCredentials } = useTournaments();
  const [copiedId, setCopiedId] = useState(false);
  const [copiedPass, setCopiedPass] = useState(false);

  if (!isOpen || !tournament) return null;

  const roomStatus = getRoomCredentials(tournament.id);

  const handleCopyId = () => {
    if (roomStatus.room?.roomId) {
      navigator.clipboard.writeText(roomStatus.room.roomId);
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    }
  };

  const handleCopyPass = () => {
    if (roomStatus.room?.password) {
      navigator.clipboard.writeText(roomStatus.room.password);
      setCopiedPass(true);
      setTimeout(() => setCopiedPass(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in font-bangla">
      <div className="relative w-full max-w-sm bg-white text-slate-900 rounded-2xl border-2 border-red-600 shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="p-4 bg-red-600 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Key className="w-5 h-5 text-white" />
            <h3 className="font-heading font-black text-lg tracking-wide">
              ROOM ID & PASSWORD
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-red-700 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          <div className="text-center pb-3 border-b border-slate-200">
            <h4 className="font-bold text-sm text-slate-900">{tournament.title}</h4>
            <span className="text-xs text-slate-500 font-mono mt-0.5 block">
              {tournament.date}, {tournament.time}
            </span>
          </div>

          {/* STATE 1: UNREGISTERED USER */}
          {roomStatus.status === 'UNREGISTERED' && (
            <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-center space-y-3">
              <div className="w-10 h-10 rounded-full bg-red-100 text-red-600 flex items-center justify-center mx-auto">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h5 className="font-black text-sm text-red-700">
                  লক করা — আপনি রেজিস্টার্ড নন
                </h5>
                <p className="text-xs text-slate-600 mt-1">
                  রুম আইডি ও পাসওয়ার্ড শুধুমাত্র এই ম্যাচে জয়েন করা প্লেয়ারদের জন্য সংরক্ষিত।
                </p>
              </div>

              {onJoinPrompt && (
                <button
                  onClick={() => {
                    onClose();
                    onJoinPrompt();
                  }}
                  className="w-full py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white font-black text-xs uppercase tracking-wide cursor-pointer"
                >
                  এখনই জয়েন করুন (Join)
                </button>
              )}
            </div>
          )}

          {/* STATE 2: REGISTERED BUT ROOM LOCKED BY ADMIN */}
          {roomStatus.status === 'LOCKED' && (
            <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-center space-y-2">
              <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto animate-pulse">
                <Lock className="w-5 h-5" />
              </div>
              <h5 className="font-black text-sm text-amber-900">
                LOCKED
              </h5>
              <p className="text-xs text-slate-700 font-bold">
                Room ID & Password will be available soon.
              </p>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                ম্যাচ শুরুর ১০-১৫ মিনিট আগে এডমিন রুম রিলিজ করবেন। রিলিজ হওয়ামাত্রই এখানে দেখতে পাবেন।
              </p>
            </div>
          )}

          {/* STATE 3: ROOM RELEASED & AVAILABLE */}
          {roomStatus.status === 'AVAILABLE' && roomStatus.room && (
            <div className="space-y-3">
              <div className="p-2 bg-emerald-50 text-emerald-800 text-center text-xs font-bold rounded-lg border border-emerald-200 flex items-center justify-center gap-1.5">
                <Unlock className="w-4 h-4 text-emerald-600" />
                <span>ROOM AVAILABLE — জয়েন করুন</span>
              </div>

              {/* Room ID box */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 font-bold uppercase block">ROOM ID</span>
                  <span className="font-mono text-lg font-black text-slate-900">{roomStatus.room.roomId}</span>
                </div>
                <button
                  onClick={handleCopyId}
                  className="px-3.5 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white font-bold text-xs flex items-center gap-1 cursor-pointer"
                >
                  {copiedId ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedId ? 'কপি হয়েছে' : 'কপি রুম আইডি'}</span>
                </button>
              </div>

              {/* Password box */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 font-bold uppercase block">PASSWORD</span>
                  <span className="font-mono text-lg font-black text-slate-900">{roomStatus.room.password}</span>
                </div>
                <button
                  onClick={handleCopyPass}
                  className="px-3.5 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white font-bold text-xs flex items-center gap-1 cursor-pointer"
                >
                  {copiedPass ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedPass ? 'কপি হয়েছে' : 'কপি পাসওয়ার্ড'}</span>
                </button>
              </div>

              <p className="text-[11px] text-slate-500 text-center">
                * ফ্রি ফায়ারে কাস্টম রুমে ঢুকে আপনার নির্ধারিত স্লটে বসুন।
              </p>
            </div>
          )}

          <button
            onClick={onClose}
            className="w-full py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs cursor-pointer"
          >
            বন্ধ করুন (Close)
          </button>
        </div>

      </div>
    </div>
  );
};
