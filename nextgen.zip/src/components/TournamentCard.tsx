import React, { useState, useEffect } from 'react';
import { ShieldCheck } from 'lucide-react';
import { Tournament } from '../types';
import { useTournaments } from '../context/TournamentContext';

interface TournamentCardProps {
  tournament: Tournament;
  onSelect?: (tournament: Tournament) => void;
  onJoin: (tournament: Tournament) => void;
  onOpenRoomId: (tournament: Tournament) => void;
  onOpenPrizeList: (tournament: Tournament) => void;
}

export const TournamentCard: React.FC<TournamentCardProps> = ({
  tournament,
  onJoin,
  onOpenRoomId,
  onOpenPrizeList,
}) => {
  const { isRegisteredFor } = useTournaments();
  const registered = isRegisteredFor(tournament.id);

  // Live countdown timer calculation
  const [timeLeft, setTimeLeft] = useState<{ days: number; hours: number; minutes: number; seconds: number }>({
    days: 0,
    hours: 0,
    minutes: 5,
    seconds: 53,
  });

  useEffect(() => {
    // Target time: tournament.matchTimestamp or default ~15 minutes
    const target = tournament.matchTimestamp || (Date.now() + 355000);

    const interval = setInterval(() => {
      const diff = target - Date.now();
      if (diff <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      } else {
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diff % (1000 * 60)) / 1000);
        setTimeLeft({ days, hours, minutes, seconds });
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [tournament.matchTimestamp]);

  const joined = tournament.joinedSlots;
  const available = Math.max(0, tournament.maxSlots - joined);
  const percentage = Math.min(100, Math.round((joined / tournament.maxSlots) * 100));

  return (
    <div className="bg-white text-slate-800 rounded-2xl border-2 border-red-600 shadow-md p-4 sm:p-5 space-y-4 font-bangla transition-all hover:shadow-lg">
      
      {/* 1. TOP ROW: Artwork + Title + Subtitle */}
      <div className="flex items-center gap-3.5">
        {/* Square FF Artwork */}
        <div className="relative w-14 h-14 sm:w-16 sm:h-16 rounded-xl overflow-hidden bg-slate-900 shrink-0 border border-slate-200">
          <img
            src={tournament.bannerUrl || "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=300&q=80"}
            alt={tournament.title}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Title and Timestamp */}
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="font-heading font-black text-base sm:text-lg text-slate-950 truncate tracking-wide">
              {tournament.title}
            </h3>
            {available <= 0 && (
              <span className="px-2 py-0.5 rounded bg-red-100 text-red-700 text-[10px] font-black border border-red-300">
                SOLD OUT
              </span>
            )}
          </div>
          <div className="flex flex-wrap items-center gap-1.5 text-xs text-red-600 font-bold mt-1">
            <span className="bg-red-50 text-red-700 px-2 py-0.5 rounded border border-red-200 font-mono text-[11px]">
              তারিখ: {tournament.date}
            </span>
            <span>•</span>
            <span className="font-mono text-[11px] text-slate-700">
              সময়: {tournament.time}
            </span>
          </div>
        </div>
      </div>

      {/* 2. STATS 3-COLUMN 2-ROW GRID */}
      <div className="grid grid-cols-3 gap-y-3.5 gap-x-2 text-center pt-1 border-t border-slate-100">
        {/* Row 1: TOTAL PRIZE | ENTRY FEE | MAP */}
        <div>
          <span className="text-[10px] sm:text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            TOTAL PRIZE
          </span>
          <span className="font-heading font-black text-sm sm:text-base text-slate-950 mt-0.5 block">
            ৳ {tournament.prizePool}
          </span>
        </div>

        <div>
          <span className="text-[10px] sm:text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            ENTRY FEE
          </span>
          <span className="font-heading font-black text-sm sm:text-base text-slate-950 mt-0.5 block">
            {tournament.entryFee === 0 ? 'FREE' : `৳ ${tournament.entryFee}`}
          </span>
        </div>

        <div>
          <span className="text-[10px] sm:text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            MAP
          </span>
          <span className="font-bold text-xs sm:text-sm text-slate-900 mt-0.5 block truncate">
            {tournament.map}
          </span>
        </div>

        {/* Row 2: TYPE | VERSION | TEAM SLOTS */}
        <div>
          <span className="text-[10px] sm:text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            TYPE
          </span>
          <span className="font-bold text-xs sm:text-sm text-slate-900 mt-0.5 block truncate">
            {tournament.customType || (
              tournament.matchCategory === 'BR SCRIM' ? 'Scrim' :
              tournament.matchCategory === 'BR BLAST' ? 'Blast' :
              tournament.matchCategory === 'BR CHAMPION RUSH' ? 'CHAMPION RUSH' :
              tournament.matchCategory === 'CS 4V4' ? 'Squad (4 team)' :
              tournament.matchCategory === 'LONE WOLF' ? 'Lone Wolf' :
              'Squad'
            )}
          </span>
        </div>

        <div>
          <span className="text-[10px] sm:text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            VERSION
          </span>
          <span className="font-bold text-xs sm:text-sm text-slate-900 mt-0.5 block">
            Mobile
          </span>
        </div>

        <div>
          <span className="text-[10px] sm:text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            TEAM SLOTS
          </span>
          <span className="font-bold text-xs sm:text-sm text-slate-900 mt-0.5 block">
            {tournament.matchCategory === 'LONE WOLF' || tournament.maxSlots === 2
              ? '2 team'
              : tournament.matchCategory === 'CS 4V4' || tournament.maxSlots === 4
              ? '4 team'
              : `${tournament.maxSlots} Teams`}
          </span>
        </div>
      </div>

      {/* 3. SLOTS BAR & JOIN BUTTON (Row) */}
      <div className="flex items-center gap-4 pt-1">
        {/* Progress bar with counts */}
        <div className="flex-1 space-y-1">
          <div className="w-full h-2.5 rounded-full bg-slate-100 overflow-hidden border border-slate-200">
            <div
              className={`h-full rounded-full transition-all duration-300 ${
                available <= 0 ? 'bg-slate-400' : 'bg-red-600'
              }`}
              style={{ width: `${percentage}%` }}
            />
          </div>
          <div className="flex justify-between items-center text-[11px] font-bold text-slate-600">
            <span>{joined}/{tournament.maxSlots} Teams ({joined} টিম জয়েন)</span>
            <span className={available <= 0 ? 'text-red-600 font-black' : 'text-slate-600'}>
              {available <= 0 ? 'সোল্ড আউট (SOLD OUT)' : `${available} Teams Left`}
            </span>
          </div>
        </div>

        {/* Join button */}
        {registered ? (
          <div className="px-4 py-1.5 rounded-lg bg-emerald-600 text-white font-black text-xs sm:text-sm flex items-center gap-1 shrink-0">
            <ShieldCheck className="w-4 h-4" />
            <span>Joined</span>
          </div>
        ) : available <= 0 ? (
          <button
            disabled
            className="px-5 py-2 rounded-lg bg-slate-200 border-2 border-slate-300 text-slate-500 font-black text-xs sm:text-sm shrink-0 cursor-not-allowed uppercase tracking-wider"
          >
            SOLD OUT
          </button>
        ) : (
          <button
            onClick={() => onJoin(tournament)}
            className="px-6 py-1.5 rounded-lg border-2 border-red-600 bg-red-600 hover:bg-red-700 text-white font-black text-xs sm:text-sm transition-all shrink-0 cursor-pointer shadow-sm active:scale-95"
          >
            Join
          </button>
        )}
      </div>

      {/* 4. BUTTONS ROW: [ Prize List ] & [ ROOM ID ] */}
      <div className="grid grid-cols-2 gap-3 pt-1">
        <button
          onClick={() => onOpenPrizeList(tournament)}
          className="w-full py-2.5 px-3 rounded-lg bg-red-600 hover:bg-red-700 active:scale-98 text-white font-black text-xs sm:text-sm uppercase tracking-wide transition-all shadow-sm cursor-pointer"
        >
          Prize List
        </button>

        <button
          onClick={() => onOpenRoomId(tournament)}
          className="w-full py-2.5 px-3 rounded-lg bg-red-600 hover:bg-red-700 active:scale-98 text-white font-black text-xs sm:text-sm uppercase tracking-wide transition-all shadow-sm cursor-pointer"
        >
          ROOM ID
        </button>
      </div>

      {/* 5. COUNTDOWN TIMER ROW (Bottom) */}
      <div className="text-center pt-2 border-t border-slate-100 text-xs sm:text-sm font-black text-slate-800 tracking-wider">
        <span>{timeLeft.days}</span> Days : <span>{timeLeft.hours}</span> Hours : <span>{timeLeft.minutes}</span> Minutes : <span>{timeLeft.seconds}</span> Seconds
      </div>

    </div>
  );
};
