import React from 'react';
import { X, Trophy, Award, Target } from 'lucide-react';
import { Tournament } from '../types';

interface PrizeListModalProps {
  tournament: Tournament | null;
  isOpen: boolean;
  onClose: () => void;
}

export const PrizeListModal: React.FC<PrizeListModalProps> = ({ tournament, isOpen, onClose }) => {
  if (!isOpen || !tournament) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in font-bangla">
      <div className="relative w-full max-w-sm bg-white text-slate-900 rounded-2xl shadow-2xl border-2 border-red-600 overflow-hidden">
        
        {/* Header */}
        <div className="p-4 bg-red-600 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-300" />
            <h3 className="font-heading font-black text-lg tracking-wide">
              পুরস্কার তালিকা (PRIZE LIST)
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-red-700 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          <div className="text-center pb-3 border-b border-slate-200">
            <h4 className="font-bold text-sm text-slate-800">{tournament.title}</h4>
            <span className="text-xs text-red-600 font-extrabold block mt-1">
              মোট প্রাইজ পুল: ৳ {tournament.prizePool}
            </span>
          </div>

          <div className="space-y-2.5 text-xs">
            {tournament.prizeDetails.first && (
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-amber-50 border border-amber-200">
                <span className="font-bold text-amber-800 flex items-center gap-1.5">
                  🥇 ১ম স্থান (1st Place):
                </span>
                <span className="font-heading font-black text-base text-amber-900">
                  ৳ {tournament.prizeDetails.first}
                </span>
              </div>
            )}

            {tournament.prizeDetails.second && (
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <span className="font-bold text-slate-700 flex items-center gap-1.5">
                  🥈 ২য় স্থান (2nd Place):
                </span>
                <span className="font-heading font-black text-base text-slate-900">
                  ৳ {tournament.prizeDetails.second}
                </span>
              </div>
            )}

            {tournament.prizeDetails.third && (
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-amber-50/50 border border-amber-100">
                <span className="font-bold text-amber-900 flex items-center gap-1.5">
                  🥉 ৩য় স্থান (3rd Place):
                </span>
                <span className="font-heading font-black text-base text-amber-900">
                  ৳ {tournament.prizeDetails.third}
                </span>
              </div>
            )}

          </div>

          <p className="text-[11px] text-slate-500 text-center pt-2">
            * ম্যাচ সমাপ্তির ১০ মিনিটের মধ্যে বিকাশ/নগদে প্রাইজমানি পাঠানো হবে।
          </p>

          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs uppercase tracking-wider cursor-pointer"
          >
            ঠিক আছে (Close)
          </button>
        </div>

      </div>
    </div>
  );
};
