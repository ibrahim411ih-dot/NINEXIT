import React, { useState } from 'react';
import { X, Wallet, ArrowDownCircle, ArrowUpCircle, CheckCircle2, AlertCircle, Copy, Check } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface WalletModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WalletModal: React.FC<WalletModalProps> = ({ isOpen, onClose }) => {
  const { user, updateProfile } = useAuth();
  const [activeTab, setActiveTab] = useState<'deposit' | 'withdraw'>('deposit');
  const [selectedMethod, setSelectedMethod] = useState<'bkash' | 'nagad' | 'rocket'>('bkash');
  const [amount, setAmount] = useState('100');
  const [phone, setPhone] = useState(user?.phone || '01700000000');
  const [trxId, setTrxId] = useState('');
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [copiedNumber, setCopiedNumber] = useState(false);

  if (!isOpen || !user) return null;

  const currentBalance = user.stats?.winningsBDT || 450;

  const demoNumbers = {
    bkash: '01712-345678 (Personal)',
    nagad: '01812-987654 (Personal)',
    rocket: '01912-456789-2 (Personal)',
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text.split(' ')[0]);
    setCopiedNumber(true);
    setTimeout(() => setCopiedNumber(false), 2000);
  };

  const handleDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const addAmt = Number(amount) || 100;
    const newTotal = (user.stats?.winningsBDT || 0) + addAmt;
    
    updateProfile({
      stats: {
        ...(user.stats || { matchesPlayed: 0, booyahs: 0, kills: 0, winningsBDT: 0 }),
        winningsBDT: newTotal,
      }
    });

    setSuccessMessage(`৳ ${addAmt} সফলভাবে ওয়ালেটে যুক্ত হয়েছে! বর্তমান ব্যালেন্স: ৳ ${newTotal}`);
    setTrxId('');
    setTimeout(() => setSuccessMessage(null), 3000);
  };

  const handleWithdrawSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const withAmt = Number(amount) || 100;
    if (withAmt > currentBalance) {
      alert('আপনার ওয়ালেটে পর্যাপ্ত ব্যালেন্স নেই!');
      return;
    }

    const newTotal = currentBalance - withAmt;
    updateProfile({
      stats: {
        ...(user.stats || { matchesPlayed: 0, booyahs: 0, kills: 0, winningsBDT: 0 }),
        winningsBDT: newTotal,
      }
    });

    setSuccessMessage(`৳ ${withAmt} ক্যাশআউট রিকোয়েস্ট সফল হয়েছে! ১০ মিনিটের মধ্যে আপনার ${selectedMethod.toUpperCase()} একাউন্টে পাঠানো হবে।`);
    setTimeout(() => setSuccessMessage(null), 3500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in font-bangla">
      <div className="relative w-full max-w-md bg-[#0a1022] rounded-3xl border border-cyan-500/40 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-800 bg-gradient-to-r from-slate-900 via-[#0d162d] to-slate-900 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-black font-black">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-heading text-lg font-black text-white">
                মাই ওয়ালেট (MY WALLET)
              </h3>
              <p className="text-[11px] text-slate-400">
                বিকাশ • নগদ • রকেট ইনস্ট্যান্ট পেমেন্ট
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Balance Showcase Card */}
        <div className="p-5 space-y-4 overflow-y-auto">
          <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-900 via-cyan-950/40 to-slate-900 border border-cyan-500/40 text-center relative overflow-hidden">
            <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider block">
              বর্তমান ব্যালেন্স (TOTAL BALANCE)
            </span>
            <div className="font-heading text-4xl font-black text-cyan-400 mt-1">
              ৳ {currentBalance.toLocaleString()} <span className="text-xs text-slate-400 font-normal">BDT</span>
            </div>
            <p className="text-[10px] text-emerald-400 mt-1">
              ✓ ১০০% ট্রাস্টেড ও ভেরিফাইড বিডি প্লেয়ার ওয়ালেট
            </p>
          </div>

          {/* Tab Selector: Deposit vs Withdraw */}
          <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-slate-950 border border-slate-800">
            <button
              onClick={() => setActiveTab('deposit')}
              className={`py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'deposit'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-black shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <ArrowDownCircle className="w-4 h-4" />
              <span>টাকা যোগ করুন (Add Money)</span>
            </button>
            <button
              onClick={() => setActiveTab('withdraw')}
              className={`py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'withdraw'
                  ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-black shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <ArrowUpCircle className="w-4 h-4" />
              <span>টাকা তুলুন (Withdraw)</span>
            </button>
          </div>

          {/* Success Message */}
          {successMessage && (
            <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* Payment Method Selector (bKash / Nagad / Rocket) */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-2">
              পেমেন্ট মাধ্যম বেছে নিন:
            </label>
            <div className="grid grid-cols-3 gap-2">
              {/* bKash */}
              <button
                type="button"
                onClick={() => setSelectedMethod('bkash')}
                className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                  selectedMethod === 'bkash'
                    ? 'bg-[#e2136e]/20 border-[#e2136e] text-white shadow-lg shadow-[#e2136e]/20'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="w-6 h-6 rounded-full bg-[#e2136e] text-white font-black text-[10px] flex items-center justify-center mx-auto mb-1">
                  ব
                </div>
                <span className="text-xs font-bold block">bKash (বিকাশ)</span>
              </button>

              {/* Nagad */}
              <button
                type="button"
                onClick={() => setSelectedMethod('nagad')}
                className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                  selectedMethod === 'nagad'
                    ? 'bg-[#f7941d]/20 border-[#f7941d] text-white shadow-lg shadow-[#f7941d]/20'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="w-6 h-6 rounded-full bg-[#f7941d] text-black font-black text-[10px] flex items-center justify-center mx-auto mb-1">
                  ন
                </div>
                <span className="text-xs font-bold block">Nagad (নগদ)</span>
              </button>

              {/* Rocket */}
              <button
                type="button"
                onClick={() => setSelectedMethod('rocket')}
                className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                  selectedMethod === 'rocket'
                    ? 'bg-[#8c3494]/20 border-[#8c3494] text-white shadow-lg shadow-[#8c3494]/20'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="w-6 h-6 rounded-full bg-[#8c3494] text-white font-black text-[10px] flex items-center justify-center mx-auto mb-1">
                  র
                </div>
                <span className="text-xs font-bold block">Rocket (রকেট)</span>
              </button>
            </div>
          </div>

          {/* TAB CONTENT: DEPOSIT */}
          {activeTab === 'deposit' ? (
            <form onSubmit={handleDepositSubmit} className="space-y-3">
              {/* Send Money Guide */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-2">
                <span className="text-slate-400 block text-[11px]">
                  আমাদের নিচের <strong className="text-white">{selectedMethod.toUpperCase()}</strong> পার্সোনাল নাম্বারে সেন্ড মানি করুন:
                </span>
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-900 border border-slate-800">
                  <span className="font-mono text-cyan-400 font-bold text-sm">
                    {demoNumbers[selectedMethod]}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleCopy(demoNumbers[selectedMethod])}
                    className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1 cursor-pointer"
                  >
                    {copiedNumber ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>কপি</span>
                  </button>
                </div>
              </div>

              {/* Amount Quick Pills */}
              <div>
                <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1">
                  টাকার পরিমাণ (BDT ৳)
                </label>
                <div className="grid grid-cols-4 gap-1.5 mb-2">
                  {['50', '100', '200', '500'].map(amt => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setAmount(amt)}
                      className={`py-1.5 rounded-lg text-xs font-bold border cursor-pointer ${
                        amount === amt
                          ? 'bg-cyan-500 text-black border-cyan-400'
                          : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      ৳ {amt}
                    </button>
                  ))}
                </div>
                <input
                  type="number"
                  required
                  min={20}
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs font-bold"
                />
              </div>

              {/* Transaction ID */}
              <div>
                <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1">
                  TrxID / ট্রানজেকশন আইডি (৮ বা ১০ সংখ্যার কোড)
                </label>
                <input
                  type="text"
                  placeholder="e.g. BL92810398"
                  value={trxId}
                  onChange={(e) => setTrxId(e.target.value.toUpperCase())}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono text-xs"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-black text-xs uppercase tracking-wider shadow-lg shadow-cyan-500/20 cursor-pointer"
              >
                টাকা যোগ করুন (VERIFY & ADD)
              </button>
            </form>
          ) : (
            /* TAB CONTENT: WITHDRAW */
            <form onSubmit={handleWithdrawSubmit} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1">
                  উত্তোলনের পরিমাণ (মিনিমাম ৳৫০)
                </label>
                <input
                  type="number"
                  required
                  min={50}
                  max={currentBalance}
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs font-bold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1">
                  আপনার {selectedMethod.toUpperCase()} একাউন্ট নাম্বার
                </label>
                <input
                  type="tel"
                  required
                  placeholder="01XXXXXXXXX"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono text-xs"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 text-black font-black text-xs uppercase tracking-wider shadow-lg shadow-amber-500/20 cursor-pointer"
              >
                ক্যাশআউট রিকোয়েস্ট পাঠান (WITHDRAW)
              </button>
            </form>
          )}

        </div>
      </div>
    </div>
  );
};
