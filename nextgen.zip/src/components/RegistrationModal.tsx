import React, { useState, useEffect } from 'react';
import { X, CheckCircle2, Gamepad2, AlertCircle, Copy, Check, ShieldAlert, ArrowRight, Wallet } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Tournament, isUserProfileComplete } from '../types';
import { useAuth } from '../context/AuthContext';
import { useTournaments } from '../context/TournamentContext';
import { storage } from '../services/storage';

interface RegistrationModalProps {
  tournament: Tournament | null;
  isOpen: boolean;
  onClose: () => void;
  onNavigateToMatches: () => void;
  onNavigateToProfile?: () => void;
}

export const RegistrationModal: React.FC<RegistrationModalProps> = ({
  tournament,
  isOpen,
  onClose,
  onNavigateToMatches,
  onNavigateToProfile,
}) => {
  const { user, setShowLoginModal, updateProfile } = useAuth();
  const { joinTournament } = useTournaments();

  // NextGen Official Payment Receiving Number from Admin settings
  const OFFICIAL_PAYMENT_NUMBER = storage.getAdminPaymentNumber();

  const [paymentMethod, setPaymentMethod] = useState<'bKash' | 'Nagad'>('bKash');
  const [senderNumber, setSenderNumber] = useState('');
  const [transactionId, setTransactionId] = useState('');
  const [teamName, setTeamName] = useState('');
  const [ffUid, setFfUid] = useState('');
  const [ffNickname, setFfNickname] = useState('');
  const [rulesAgreed, setRulesAgreed] = useState(true);
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);
  const [successStatus, setSuccessStatus] = useState<'PENDING' | 'CONFIRMED'>('PENDING');
  const [assignedSlot, setAssignedSlot] = useState<number | undefined>(undefined);
  const [copiedNumber, setCopiedNumber] = useState(false);

  // In-modal profile quick complete state
  const [quickFfNickname, setQuickFfNickname] = useState('');
  const [quickFfUid, setQuickFfUid] = useState('');
  const [quickTeamName, setQuickTeamName] = useState('');
  const [quickBkash, setQuickBkash] = useState('');
  const [quickSaveError, setQuickSaveError] = useState('');

  useEffect(() => {
    if (user) {
      setFfUid(user.ffUid || '');
      setFfNickname(user.ffNickname || '');
      setTeamName(user.teamName || '');
      setSenderNumber(user.bkashNumber || user.phone || '');
      
      setQuickFfNickname(user.ffNickname || '');
      setQuickFfUid(user.ffUid || '');
      setQuickTeamName(user.teamName || '');
      setQuickBkash(user.bkashNumber || user.phone || '');
    }
    setIsSuccess(false);
    setErrorMessage(null);
    setTransactionId('');
  }, [user, tournament, isOpen]);

  if (!isOpen || !tournament) return null;

  const isProfileCompleteNow = isUserProfileComplete(user);
  const isPaidMatch = tournament.entryFee > 0;

  const handleCopyPaymentNumber = () => {
    navigator.clipboard.writeText(OFFICIAL_PAYMENT_NUMBER);
    setCopiedNumber(true);
    setTimeout(() => setCopiedNumber(false), 2000);
  };

  const handleQuickProfileSave = (e: React.FormEvent) => {
    e.preventDefault();
    setQuickSaveError('');

    if (!quickFfNickname.trim()) {
      setQuickSaveError('গেম নাম (IGN) লিখুন।');
      return;
    }
    if (!quickFfUid.trim() || quickFfUid.length < 5) {
      setQuickSaveError('সঠিক ফ্রি ফায়ার গেম UID দিন।');
      return;
    }
    if (!quickTeamName.trim()) {
      setQuickSaveError('টিম নেম (TEAM NAME) লিখুন।');
      return;
    }
    if (!quickBkash.trim() || quickBkash.length < 11) {
      setQuickSaveError('১১ সংখ্যার বিকাশ/নগদ নম্বর দিন।');
      return;
    }

    updateProfile({
      ffNickname: quickFfNickname.trim(),
      ffUid: quickFfUid.trim(),
      teamName: quickTeamName.trim(),
      bkashNumber: quickBkash.trim(),
      phone: quickBkash.trim(),
    });

    setFfNickname(quickFfNickname.trim());
    setFfUid(quickFfUid.trim());
    setTeamName(quickTeamName.trim());
    setSenderNumber(quickBkash.trim());
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!user) {
      setShowLoginModal(true);
      return;
    }

    if (!isProfileCompleteNow) {
      setErrorMessage('টুর্নামেন্ট কিনতে হলে আগে প্রোফাইল সম্পূর্ণ করতে হবে।');
      return;
    }

    if (tournament.joinedSlots >= tournament.maxSlots) {
      setErrorMessage('দুঃখিত! এই টুর্নামেন্টের সব স্লট ইতিমধ্যে পূরণ হয়ে গেছে (SOLD OUT)।');
      return;
    }

    if (!ffUid.trim()) {
      setErrorMessage('গেম UID প্রদান করুন।');
      return;
    }

    if (!ffNickname.trim()) {
      setErrorMessage('গেম নাম (IGN) প্রদান করুন।');
      return;
    }

    if (!teamName.trim()) {
      setErrorMessage('টিম নেম (TEAM NAME) প্রদান করুন।');
      return;
    }

    if (isPaidMatch) {
      if (!senderNumber.trim() || senderNumber.length < 11) {
        setErrorMessage('টাকা পাঠানো বিকাশ বা নগদ মোবাইল নম্বর দিন।');
        return;
      }

      if (!transactionId.trim() || transactionId.trim().length < 4) {
        setErrorMessage('টাকা পাঠানোর সঠিক ট্রানজেকশন আইডি (TrxID) দিন।');
        return;
      }
    }

    setIsSubmitting(true);

    try {
      // Sync profile if user modified IGN or teamName during checkout
      updateProfile({
        ffUid: ffUid.trim(),
        ffNickname: ffNickname.trim(),
        teamName: teamName.trim(),
        bkashNumber: senderNumber.trim() || user.bkashNumber,
      });

      const res = await joinTournament({
        tournamentId: tournament.id,
        ffUid: ffUid.trim(),
        ffNickname: ffNickname.trim(),
        teamName: teamName.trim(),
        phone: senderNumber.trim() || user.phone,
        paymentMethod: isPaidMatch ? paymentMethod : undefined,
        senderNumber: isPaidMatch ? senderNumber.trim() : undefined,
        transactionId: isPaidMatch ? transactionId.trim().toUpperCase() : undefined,
        amountPaid: tournament.entryFee,
      });

      if (res.success && res.registration) {
        if (isPaidMatch) {
          setSuccessStatus('PENDING');
        } else {
          setSuccessStatus('CONFIRMED');
          setAssignedSlot(res.registration.slotNumber);
        }
        setIsSuccess(true);
        confetti({
          particleCount: 70,
          spread: 60,
          origin: { y: 0.6 },
          colors: ['#dc2626', '#16a34a', '#0284c7']
        });
      } else {
        setErrorMessage(res.message);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'টুর্নামেন্ট জয়েন ব্যর্থ হয়েছে। আবার চেষ্টা করুন।');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in font-bangla">
      <div className="relative w-full max-w-md bg-white text-slate-900 rounded-2xl border-2 border-red-600 shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
        
        {/* Header */}
        <div className="p-4 bg-red-600 text-white flex items-center justify-between shrink-0">
          <div>
            <h3 className="font-heading font-black text-lg tracking-wide leading-tight">
              {isSuccess ? 'রিকোয়েস্ট সম্পন্ন' : 'টুর্নামেন্ট ক্রয় / রেজিস্ট্রেশন'}
            </h3>
            <span className="text-[11px] opacity-90 block">
              {tournament.title} • {tournament.map}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-red-700 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4">
          
          {/* 1. NOT LOGGED IN STATE */}
          {!user ? (
            <div className="text-center py-6 space-y-4">
              <div className="w-12 h-12 rounded-full bg-red-50 text-red-600 flex items-center justify-center mx-auto">
                <AlertCircle className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-heading font-black text-lg text-slate-900">
                  টুর্নামেন্ট কিনতে লগইন করুন
                </h4>
                <p className="text-xs text-slate-500 mt-1">
                  ম্যাচ কেনা এবং কাস্টম রুম আইডি পেতে অনুগ্রহ করে আপনার একাউন্টে লগইন করুন বা আইডি তৈরি করুন।
                </p>
              </div>
              <button
                onClick={() => {
                  onClose();
                  setShowLoginModal(true);
                }}
                className="w-full py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs uppercase tracking-wider cursor-pointer shadow-md"
              >
                লগইন / আইডি তৈরি করুন
              </button>
            </div>
          ) : isSuccess ? (
            /* 2. SUCCESS STATE */
            <div className="text-center py-2 space-y-3.5">
              <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-sm">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div>
                <h4 className="font-heading font-black text-xl text-slate-900">
                  {successStatus === 'PENDING' ? 'পেমেন্ট রিকোয়েস্ট জমা হয়েছে!' : 'রেজিস্ট্রেশন সফল হয়েছে!'}
                </h4>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  {successStatus === 'PENDING'
                    ? 'আপনার বিকাশ/নগদ পেমেন্ট তথ্য জমা নেওয়া হয়েছে। এডমিন কনফার্ম করলে স্লট নম্বর বরাদ্দ হবে।'
                    : `আপনি সফলভাবে ${tournament.title} তে স্লট #${assignedSlot} নিশ্চিত করেছেন।`}
                </p>
              </div>

              {/* Status Ticket */}
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-left space-y-2 text-xs">
                <div className="flex justify-between items-center border-b border-slate-200 pb-2">
                  <span className="text-slate-500">স্ট্যাটাস:</span>
                  <span className={`px-2 py-0.5 rounded font-black text-xs ${
                    successStatus === 'PENDING'
                      ? 'bg-amber-100 text-amber-800 border border-amber-300'
                      : 'bg-emerald-100 text-emerald-700 border border-emerald-300'
                  }`}>
                    {successStatus === 'PENDING' ? 'Pending Admin Approval (এডমিন যাচাই পেন্ডিং)' : `Slot #${assignedSlot} Confirmed`}
                  </span>
                </div>

                <div className="flex justify-between">
                  <span className="text-slate-500">টুর্নামেন্ট:</span>
                  <span className="font-bold text-slate-900 truncate max-w-[180px]">{tournament.title}</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-slate-500">টিম নেম:</span>
                  <span className="font-bold text-slate-900">{teamName}</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-slate-500">Player UID:</span>
                  <span className="font-mono font-bold text-slate-900">{ffUid}</span>
                </div>

                {isPaidMatch && (
                  <div className="flex justify-between border-t border-slate-200 pt-1.5">
                    <span className="text-slate-500">Transaction ID:</span>
                    <span className="font-mono font-black text-red-600">{transactionId}</span>
                  </div>
                )}
              </div>

              <div className="p-3 bg-red-50/70 border border-red-200 rounded-xl text-[11px] text-slate-700 text-left space-y-1">
                <p className="font-bold text-red-700">গুরুত্বপূর্ণ নির্দেশনা:</p>
                <p>
                  • ম্যাচটি আপনার <strong>My Matches</strong> পেজে সেভ করা হয়েছে।
                </p>
                <p>
                  • এডমিন ভেরিফাই করে কনফার্ম করলে আপনি টিম স্লট নম্বর পাবেন এবং ম্যাচ শুরুর ১৫ মিনিট আগে রুম আইডি ও পাসওয়ার্ড দেখতে পারবেন।
                </p>
              </div>

              <button
                onClick={() => {
                  onClose();
                  onNavigateToMatches();
                }}
                className="w-full py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs uppercase tracking-wide flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
              >
                <Gamepad2 className="w-4 h-4" />
                <span>মাই ম্যাচ অপশনে যান (MY MATCHES)</span>
              </button>
            </div>
          ) : !isProfileCompleteNow ? (
            /* 3. INCOMPLETE PROFILE GATE (CRITICAL REQUIREMENT) */
            <div className="space-y-4">
              <div className="p-3.5 rounded-xl bg-amber-50 border-2 border-amber-300 text-amber-900 space-y-1.5">
                <div className="flex items-center gap-2 font-black text-sm">
                  <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0" />
                  <span>আগে প্রোফাইল সম্পূর্ণ করুন!</span>
                </div>
                <p className="text-xs text-amber-800 leading-relaxed">
                  টুর্নামেন্ট কিনতে হলে আপনার <strong>গেম নাম</strong>, <strong>গেম UID</strong>, <strong>TEAM NAME</strong> এবং <strong>bKash/Nagad number</strong> অবশ্যই পূরণ করতে হবে।
                </p>
              </div>

              {quickSaveError && (
                <div className="p-2.5 rounded-lg bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{quickSaveError}</span>
                </div>
              )}

              {/* Quick Profile Completion Form */}
              <form onSubmit={handleQuickProfileSave} className="space-y-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                    ১. গেম নাম (In-Game Nickname / IGN) *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: 亗 DARK_KILLER 亗"
                    value={quickFfNickname}
                    onChange={(e) => setQuickFfNickname(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs text-slate-900 focus:outline-none focus:border-red-600"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                    ২. গেম UID (Free Fire UID) *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: 2948291048"
                    value={quickFfUid}
                    onChange={(e) => setQuickFfUid(e.target.value.replace(/[^0-9]/g, ''))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-xs text-slate-900 focus:outline-none focus:border-red-600"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                    ৩. TEAM NAME (টিমের নাম) *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: NINEX Esports / Dhaka Tigers"
                    value={quickTeamName}
                    onChange={(e) => setQuickTeamName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs text-slate-900 focus:outline-none focus:border-red-600"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                    ৪. bKash / Nagad Number (বিকাশ বা নগদ নম্বর) *
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="01XXXXXXXXX"
                    value={quickBkash}
                    onChange={(e) => setQuickBkash(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-xs text-slate-900 focus:outline-none focus:border-red-600"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs uppercase tracking-wide cursor-pointer shadow-md transition-all flex items-center justify-center gap-1.5"
                >
                  <span>প্রোফাইল সংরক্ষণ করে টুর্নামেন্ট কিনুন</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            </div>
          ) : (
            /* 4. TOURNAMENT PURCHASE FORM WITH BKASH/NAGAD & TRXID */
            <form onSubmit={handleSubmit} className="space-y-3.5">
              
              {/* Match pricing summary */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                <div>
                  <span className="font-heading font-black text-sm text-slate-900 block truncate">
                    {tournament.title}
                  </span>
                  <span className="text-[11px] text-slate-500 font-bold block">
                    {tournament.mode} • Map: {tournament.map} • সময়: {tournament.time}
                  </span>
                </div>
                <div className="text-right shrink-0">
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">এন্ট্রি ফি</span>
                  <span className="font-heading font-black text-base text-red-600 block">
                    {tournament.entryFee === 0 ? 'FREE' : `৳ ${tournament.entryFee}`}
                  </span>
                </div>
              </div>

              {errorMessage && (
                <div className="p-2.5 rounded-lg bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* PAYMENT INSTRUCTIONS & OFFICIAL SEND MONEY NUMBER (FOR PAID MATCHES) */}
              {isPaidMatch && (
                <div className="p-3.5 rounded-xl bg-red-50/60 border-2 border-red-200 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-red-700 uppercase flex items-center gap-1.5">
                      <Wallet className="w-4 h-4" />
                      NINEX অফিসিয়াল পেমেন্ট নম্বর
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-red-100 text-red-800">
                      Send Money (Personal)
                    </span>
                  </div>

                  <div className="p-2.5 bg-white rounded-lg border border-red-200 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-500 font-bold block uppercase">
                        bKash / Nagad Personal Number
                      </span>
                      <span className="font-mono text-base font-black text-slate-950 block">
                        {OFFICIAL_PAYMENT_NUMBER}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={handleCopyPaymentNumber}
                      className="px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white font-bold text-xs flex items-center gap-1 cursor-pointer transition-all"
                    >
                      {copiedNumber ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedNumber ? 'কপি হয়েছে' : 'নম্বর কপি'}</span>
                    </button>
                  </div>

                  <p className="text-[11px] text-slate-600 leading-relaxed">
                    ১. উপরের নম্বরে এন্ট্রি ফি <strong>৳ {tournament.entryFee}</strong> টাকা সেন্ড মানি করুন।<br />
                    ২. টাকা পাঠানো হয়ে গেলে নিচের ফর্মে আপনার <strong>প্রেরক নম্বর</strong> ও <strong>TrxID</strong> দিন।
                  </p>
                </div>
              )}

              {/* PAYMENT INPUTS (FOR PAID MATCHES) */}
              {isPaidMatch && (
                <div className="grid grid-cols-2 gap-2.5">
                  {/* Payment Method */}
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">
                      পেমেন্ট মাধ্যম *
                    </label>
                    <select
                      value={paymentMethod}
                      onChange={(e) => setPaymentMethod(e.target.value as 'bKash' | 'Nagad')}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-900 focus:outline-none focus:border-red-600 bg-white"
                    >
                      <option value="bKash">bKash (বিকাশ)</option>
                      <option value="Nagad">Nagad (নগদ)</option>
                    </select>
                  </div>

                  {/* Sender Number */}
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">
                      প্রেরক মোবাইল নম্বর *
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="01XXXXXXXXX"
                      value={senderNumber}
                      onChange={(e) => setSenderNumber(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-xs text-slate-900 focus:outline-none focus:border-red-600"
                    />
                  </div>

                  {/* Transaction ID */}
                  <div className="col-span-2">
                    <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1 flex items-center justify-between">
                      <span>ট্রানজেকশন আইডি (Transaction ID / TrxID) *</span>
                      <span className="text-[10px] text-red-600 font-mono">যেমন: BIK9482718</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="টাকা পাঠানোর ফিরতি এসএমএস এর TrxID দিন"
                      value={transactionId}
                      onChange={(e) => setTransactionId(e.target.value.toUpperCase())}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-300 font-mono text-xs text-slate-900 focus:outline-none focus:border-red-600 tracking-wider font-bold uppercase"
                    />
                  </div>
                </div>
              )}

              {/* GAME CREDENTIALS (TEAM NAME + GAME UID + GAME NAME) */}
              <div className="space-y-2.5 pt-1 border-t border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase block">
                  প্লেয়ার ও টিম তথ্য (প্রোফাইল থেকে সংগৃহীত)
                </span>

                <div className="grid grid-cols-2 gap-2.5">
                  {/* Team Name */}
                  <div className="col-span-2">
                    <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">
                      TEAM NAME (টিমের নাম) *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="আপনার দলের নাম"
                      value={teamName}
                      onChange={(e) => setTeamName(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs text-slate-900 focus:outline-none focus:border-red-600"
                    />
                  </div>

                  {/* Game Nickname */}
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">
                      গেম নাম (IGN) *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="গেম নিকনেম"
                      value={ffNickname}
                      onChange={(e) => setFfNickname(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs text-slate-900 focus:outline-none focus:border-red-600"
                    />
                  </div>

                  {/* Game UID */}
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">
                      গেম UID (Player UID) *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="ফ্রি ফায়ার UID"
                      value={ffUid}
                      onChange={(e) => setFfUid(e.target.value.replace(/[^0-9]/g, ''))}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-xs text-slate-900 focus:outline-none focus:border-red-600"
                    />
                  </div>
                </div>
              </div>

              {/* Rules agreement */}
              <label className="flex items-start gap-2 pt-1 text-[11px] text-slate-500 cursor-pointer">
                <input
                  type="checkbox"
                  checked={rulesAgreed}
                  onChange={(e) => setRulesAgreed(e.target.checked)}
                  className="mt-0.5 text-red-600 rounded"
                />
                <span>আমি মোবাইল প্লেয়ার এবং গান প্রোপার্টি অফ ও কাস্টম নিয়মে সম্মতি দিচ্ছি।</span>
              </label>

              {/* Submit CTA */}
              <button
                type="submit"
                disabled={isSubmitting || !rulesAgreed}
                className="w-full py-2.5 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs uppercase tracking-wider cursor-pointer shadow-md disabled:opacity-50 transition-all flex items-center justify-center gap-1.5"
              >
                {isSubmitting 
                  ? 'প্রসেসিং হচ্ছে...' 
                  : isPaidMatch 
                  ? 'পেমেন্ট রিকোয়েস্ট সাবমিট করুন (SUBMIT PAYMENT)' 
                  : 'কনফার্ম জয়েন (JOIN MATCH)'}
              </button>
            </form>
          )}

        </div>

      </div>
    </div>
  );
};
