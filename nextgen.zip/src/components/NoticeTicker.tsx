import React from 'react';
import { Megaphone, ShieldAlert, Zap } from 'lucide-react';

interface NoticeTickerProps {
  onOpenRules?: () => void;
}

export const NoticeTicker: React.FC<NoticeTickerProps> = ({ onOpenRules }) => {
  return (
    <div className="bg-gradient-to-r from-cyan-950/80 via-slate-900 to-blue-950/80 border-y border-cyan-500/30 overflow-hidden py-2 px-4 shadow-inner">
      <div className="max-w-7xl mx-auto flex items-center gap-3">
        {/* Badge */}
        <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-red-600/90 text-white text-[10px] font-black uppercase tracking-wider shrink-0 shadow-sm animate-pulse">
          <Megaphone className="w-3.5 h-3.5" />
          <span>জরুরি নোটিশ</span>
        </div>

        {/* Scrolling text marquee */}
        <div className="overflow-hidden relative w-full flex-1">
          <div className="animate-ticker text-xs font-medium text-slate-200 flex items-center gap-8">
            <span className="flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400 inline" />
              কাস্টম রুম আইডি ও পাসওয়ার্ড ম্যাচ শুরুর ঠিক ১৫ মিনিট আগে <strong className="text-cyan-400">My Matches</strong> পেজে দেওয়া হবে!
            </span>
            <span className="text-slate-500">•</span>
            <span className="flex items-center gap-1.5 text-red-350">
              <ShieldAlert className="w-3.5 h-3.5 text-red-400 inline" />
              পিসি/এমুলেটর বা হ্যাকিং ১০০% নিষিদ্ধ। ধরা পড়লে আজীবন ব্যান!
            </span>
            <span className="text-slate-500">•</span>
            <span className="text-emerald-300">
              💰 বিকাশ ও নগদে ম্যাচ শেষের ১০ মিনিটের মধ্যে প্রাইজমানি ইনস্ট্যান্ট ক্যাশআউট।
            </span>
            <span className="text-slate-500">•</span>
            <span className="text-cyan-300">
              🇧🇩 বাংলাদেশ ফ্রি ফায়ার অফিশিয়াল স্ক্রিমস সিজন ২০২৬ এ সবাইকে স্বাগতম!
            </span>
          </div>
        </div>

        {/* Quick action button */}
        <button
          onClick={onOpenRules}
          className="hidden sm:inline-flex text-[11px] font-bold text-cyan-400 hover:text-cyan-300 underline shrink-0 cursor-pointer"
        >
          নিয়মাবলী দেখুন
        </button>
      </div>
    </div>
  );
};
