import React, { useState } from 'react';
import { X, User, Phone, Lock, Shield, UserCheck, AlertCircle, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRegisteredSuccess?: () => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({ isOpen, onClose, onRegisteredSuccess }) => {
  const { loginWithPhoneAndPassword, signupWithCredentials, loginWithDemo, isLoading } = useAuth();

  const [tab, setTab] = useState<'login' | 'signup'>('signup');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [successNotice, setSuccessNotice] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessNotice('');

    if (tab === 'signup') {
      const res = await signupWithCredentials(name, phone, password, confirmPassword);
      if (!res.success) {
        setErrorMsg(res.message || 'আইডি তৈরি ব্যর্থ হয়েছে। তথ্য যাচাই করুন।');
      } else {
        setSuccessNotice('আইডি তৈরি সফল হয়েছে! টুর্নামেন্ট খেলতে আগে আপনার প্রোফাইল সম্পূর্ণ করুন।');
        setTimeout(() => {
          onClose();
          if (onRegisteredSuccess) onRegisteredSuccess();
        }, 1200);
      }
    } else {
      const res = await loginWithPhoneAndPassword(phone, password);
      if (!res.success) {
        setErrorMsg(res.message || 'লগইন ব্যর্থ হয়েছে। তথ্য যাচাই করে আবার চেষ্টা করুন।');
      } else {
        onClose();
      }
    }
  };

  const handleFillDemo = (type: 'admin' | 'player') => {
    if (type === 'admin') {
      setName('Ibrahim Hossain');
      setPhone('01712345678');
      setPassword('123');
      setConfirmPassword('123');
    } else {
      setName('Tanvir Ahmed');
      setPhone('01819283746');
      setPassword('123');
      setConfirmPassword('123');
    }
    setErrorMsg('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in font-bangla">
      <div className="relative w-full max-w-sm bg-white text-slate-900 rounded-2xl border-2 border-red-600 shadow-2xl p-6 space-y-4 max-h-[92vh] overflow-y-auto">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1 rounded-lg text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Logo & Header */}
        <div className="text-center pt-1">
          <div className="w-12 h-12 rounded-xl bg-red-600 text-white font-black text-xl flex items-center justify-center mx-auto shadow-md mb-2">
            9X
          </div>
          <h2 className="font-heading text-xl font-black text-slate-900">
            NINE<span className="text-red-600">X</span> Esports
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {tab === 'signup' 
              ? 'নাম, মোবাইল নম্বর ও পাসওয়ার্ড (২ বার) দিয়ে আইডি তৈরি করুন'
              : 'মোবাইল নম্বর ও পাসওয়ার্ড দিয়ে লগইন করুন'}
          </p>
        </div>

        {/* Mode Tabs: Sign Up vs Login */}
        <div className="flex rounded-xl bg-slate-100 p-1 border border-slate-200">
          <button
            type="button"
            onClick={() => {
              setTab('signup');
              setErrorMsg('');
            }}
            className={`flex-1 py-1.5 text-xs font-black rounded-lg transition-all cursor-pointer ${
              tab === 'signup'
                ? 'bg-red-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            আইডি তৈরি (Sign Up)
          </button>
          <button
            type="button"
            onClick={() => {
              setTab('login');
              setErrorMsg('');
            }}
            className={`flex-1 py-1.5 text-xs font-black rounded-lg transition-all cursor-pointer ${
              tab === 'login'
                ? 'bg-red-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            লগইন (Login)
          </button>
        </div>

        {/* Error Notice */}
        {errorMsg && (
          <div className="p-2.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Success Notice */}
        {successNotice && (
          <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{successNotice}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-3 text-left">
          
          {/* Name (Sign up only) */}
          {tab === 'signup' && (
            <div>
              <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-red-600" />
                আপনার নাম (NAME) *
              </label>
              <input
                type="text"
                required
                placeholder="যেমন: Ibrahim Hossain"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-red-600 focus:ring-1 focus:ring-red-600 transition-all"
              />
            </div>
          )}

          {/* Mobile Number */}
          <div>
            <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1 flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-red-600" />
              মোবাইল নম্বর (PHONE NUMBER) *
            </label>
            <input
              type="tel"
              required
              placeholder="01XXXXXXXXX"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl border border-slate-300 font-mono text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-red-600 focus:ring-1 focus:ring-red-600 transition-all"
            />
          </div>

          {/* Password */}
          <div>
            <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-red-600" />
              পাসওয়ার্ড (PASSWORD) *
            </label>
            <input
              type="password"
              required
              placeholder="গোপন পাসওয়ার্ড দিন"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-red-600 focus:ring-1 focus:ring-red-600 transition-all"
            />
          </div>

          {/* Confirm Password (Sign up only - ২ বার পাসওয়ার্ড) */}
          {tab === 'signup' && (
            <div>
              <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-red-600" />
                পাসওয়ার্ড নিশ্চিত করুন (CONFIRM PASSWORD) *
              </label>
              <input
                type="password"
                required
                placeholder="একই পাসওয়ার্ড পুনরায় দিন"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-red-600 focus:ring-1 focus:ring-red-600 transition-all"
              />
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full mt-2 py-2.5 px-4 rounded-xl bg-red-600 hover:bg-red-700 active:scale-98 text-white font-black text-xs sm:text-sm uppercase tracking-wider transition-all shadow-md cursor-pointer disabled:opacity-50"
          >
            {isLoading 
              ? 'যাচাই করা হচ্ছে...' 
              : tab === 'signup' 
              ? 'আইডি তৈরি করুন (CREATE ACCOUNT)' 
              : 'লগইন করুন (LOGIN)'}
          </button>
        </form>

        {/* Quick Demo Fill Buttons */}
        <div className="pt-2 border-t border-slate-100">
          <span className="text-[10px] uppercase font-bold text-slate-400 block mb-2 text-center">
            টেস্টিং ডেমো একাউন্ট (Quick Auto-Fill)
          </span>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => handleFillDemo('admin')}
              className="py-1.5 px-2 rounded-lg bg-red-50 hover:bg-red-100 border border-red-200 text-red-700 text-[11px] font-bold flex items-center justify-center gap-1 cursor-pointer transition-colors"
            >
              <Shield className="w-3 h-3" />
              <span>Admin Auto-Fill</span>
            </button>
            <button
              type="button"
              onClick={() => handleFillDemo('player')}
              className="py-1.5 px-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-bold flex items-center justify-center gap-1 cursor-pointer transition-colors"
            >
              <UserCheck className="w-3 h-3" />
              <span>Player Auto-Fill</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
