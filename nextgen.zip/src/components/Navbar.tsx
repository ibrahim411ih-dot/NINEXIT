import React from 'react';
import { useAuth } from '../context/AuthContext';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  setShowNotifications?: (show: boolean) => void;
  onOpenWallet?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  activeTab, 
  setActiveTab,
}) => {
  const { user, isAdmin, setShowLoginModal } = useAuth();

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-sm font-bangla">
      <div className="max-w-xl mx-auto px-4 h-16 flex items-center justify-between">
        
        {/* Brand / Logo (Left) */}
        <button 
          onClick={() => setActiveTab('home')}
          className="flex items-center gap-2 text-left focus:outline-none cursor-pointer"
        >
          {/* Esports emblem icon */}
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-600 to-black flex items-center justify-center shadow-md text-white font-black">
            <span className="font-heading text-lg tracking-wider">9X</span>
          </div>
          <div>
            <div className="font-heading text-xl font-black tracking-wider text-slate-900 leading-none">
              NINE<span className="text-red-600">X</span>
            </div>
            <span className="text-[10px] text-slate-500 font-semibold tracking-wide">
              E-SPORTS TOURNAMENT
            </span>
          </div>
        </button>

        {/* Right side auth & wallet buttons */}
        <div className="flex items-center gap-2">
          {user ? (
            <div className="flex items-center gap-2">
              {/* Admin Button */}
              {isAdmin && (
                <button
                  onClick={() => setActiveTab(activeTab === 'admin' ? 'home' : 'admin')}
                  className={`px-2.5 py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer ${
                    activeTab === 'admin'
                      ? 'bg-red-600 text-white'
                      : 'bg-amber-100 text-amber-900 border border-amber-300'
                  }`}
                >
                  Admin
                </button>
              )}

              {/* Profile Avatar / Initial letter */}
              <button
                onClick={() => setActiveTab('profile')}
                className="w-8 h-8 rounded-lg bg-red-600 text-white font-heading font-black text-xs flex items-center justify-center cursor-pointer shadow-sm uppercase ring-2 ring-red-600/40 hover:bg-red-700 transition-colors"
                title={user.displayName || 'Profile'}
              >
                {user.displayName?.trim().charAt(0).toUpperCase() || 'U'}
              </button>
            </div>
          ) : (
            /* EXACT REGISTER & LOGIN BUTTONS FROM SCREENSHOT 2 */
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowLoginModal(true)}
                className="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-900 font-bold text-xs sm:text-sm transition-colors cursor-pointer"
              >
                Register
              </button>
              <button
                onClick={() => setShowLoginModal(true)}
                className="px-5 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white font-black text-xs sm:text-sm transition-colors shadow-sm cursor-pointer"
              >
                Login
              </button>
            </div>
          )}
        </div>

      </div>
    </header>
  );
};
