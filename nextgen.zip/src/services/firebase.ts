import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut as fbSignOut } from 'firebase/auth';
import { getFirestore, Firestore } from 'firebase/firestore';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

let firebaseApp = null;
let firebaseAuth: ReturnType<typeof getAuth> | null = null;
let firestoreDb: Firestore | null = null;
let isFirebaseConfigured = false;

try {
  // Check if firebase-applet-config.json is present dynamically
  // If not present, we remain in local persistent mode without crashing
  const firebaseConfigEnv = (import.meta as any).env?.VITE_FIREBASE_CONFIG;
  if (firebaseConfigEnv) {
    const config = JSON.parse(firebaseConfigEnv);
    firebaseApp = getApps().length > 0 ? getApp() : initializeApp(config);
    firebaseAuth = getAuth(firebaseApp);
    firestoreDb = getFirestore(firebaseApp, (config as any).firestoreDatabaseId);
    isFirebaseConfigured = true;
  }
} catch {
  // Local fallback mode active
  isFirebaseConfigured = false;
}

export const auth = firebaseAuth;
export const db = firestoreDb;
export const isConfigured = isFirebaseConfigured;

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const currentUser = firebaseAuth?.currentUser;
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: currentUser?.uid,
      email: currentUser?.email,
      emailVerified: currentUser?.emailVerified,
      isAnonymous: currentUser?.isAnonymous,
      tenantId: currentUser?.tenantId,
      providerInfo: currentUser?.providerData?.map(p => ({
        providerId: p.providerId,
        email: p.email,
      })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export async function loginWithGoogleFirebase() {
  if (!firebaseAuth) {
    throw new Error('Firebase not configured. Please use demo sign in.');
  }
  const provider = new GoogleAuthProvider();
  return await signInWithPopup(firebaseAuth, provider);
}

export async function logoutFirebase() {
  if (firebaseAuth) {
    await fbSignOut(firebaseAuth);
  }
}
