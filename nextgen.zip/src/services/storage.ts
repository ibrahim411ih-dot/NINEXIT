import { Tournament, Registration, RoomData, MatchResult, NotificationItem, UserProfile } from '../types';
import { INITIAL_TOURNAMENTS, INITIAL_ROOMS, INITIAL_RESULTS, INITIAL_NOTIFICATIONS, DEFAULT_DEMO_USER } from './mockData';

const STORAGE_KEYS = {
  TOURNAMENTS: 'ff_arena_tournaments',
  REGISTRATIONS: 'ff_arena_registrations',
  ROOMS: 'ff_arena_rooms',
  RESULTS: 'ff_arena_results',
  NOTIFICATIONS: 'ff_arena_notifications',
  USER_PROFILE: 'ff_arena_user_profile',
  REGISTERED_USERS: 'ff_arena_all_users',
};

// Seed initial registrations for demo user so they can immediately test viewing room credentials
const INITIAL_DEMO_REGISTRATIONS: Registration[] = [
  {
    id: 'reg-demo-1',
    tournamentId: 'ff-tour-001',
    tournamentTitle: 'BR SCRIM',
    tournamentMode: 'Squad',
    tournamentMap: 'B. P. K',
    tournamentTime: '11:59:00 PM',
    userId: 'demo-user-1',
    userName: 'Ibrahim Hossain',
    userEmail: 'ibrahim380ih@gmail.com',
    ffUid: '2847291048',
    ffNickname: '亗 ɪʙʀᴀʜɪᴍ_ᴏᴘ 亗',
    teamName: 'Apex BD',
    phone: '01712345678',
    slotNumber: 7,
    status: 'CONFIRMED',
    registeredAt: '2026-10-07T09:00:00Z',
  },
  {
    id: 'reg-demo-2',
    tournamentId: 'ff-tour-005',
    tournamentTitle: 'CS 4 V 4 Clash squad',
    tournamentMode: 'Squad',
    tournamentMap: 'Bermuda',
    tournamentTime: '09:30:00 PM',
    userId: 'demo-user-1',
    userName: 'Ibrahim Hossain',
    userEmail: 'ibrahim380ih@gmail.com',
    ffUid: '2847291048',
    ffNickname: '亗 ɪʙʀᴀʜɪᴍ_ᴏᴘ 亗',
    teamName: 'Apex BD Squad',
    phone: '01712345678',
    slotNumber: 1,
    status: 'CONFIRMED',
    registeredAt: '2026-10-07T09:30:00Z',
  },
  {
    id: 'reg-demo-3',
    tournamentId: 'ff-tour-006',
    tournamentTitle: 'Lone Wolf',
    tournamentMode: 'Squad',
    tournamentMap: 'Lone Wolf Map',
    tournamentTime: '08:00:00 PM',
    userId: 'demo-user-1',
    userName: 'Ibrahim Hossain',
    userEmail: 'ibrahim380ih@gmail.com',
    ffUid: '2847291048',
    ffNickname: '亗 ɪʙʀᴀʜɪᴍ_ᴏᴘ 亗',
    teamName: 'Apex Wolf Squad',
    phone: '01712345678',
    slotNumber: 2,
    status: 'CONFIRMED',
    registeredAt: '2026-10-07T10:00:00Z',
  },
  // BR SCRIM 9:00 PM (ff-tour-013) Slot Buyers
  {
    id: 'reg-scrim9-1',
    tournamentId: 'ff-tour-013',
    tournamentTitle: 'BR SCRIM',
    tournamentMode: 'Squad',
    tournamentMap: 'B. P. K',
    tournamentTime: '09:00:00 PM',
    userId: 'demo-user-1',
    userName: 'Ibrahim Hossain',
    userEmail: 'ibrahim380ih@gmail.com',
    ffUid: '2081948291',
    ffNickname: '亗 ᴛᴀɴᴠɪʀ 亗',
    teamName: 'Apex BD',
    phone: '01811223344',
    slotNumber: 1,
    status: 'CONFIRMED',
    registeredAt: '2026-10-07T08:00:00Z',
  },
  {
    id: 'reg-scrim9-2',
    tournamentId: 'ff-tour-013',
    tournamentTitle: 'BR SCRIM',
    tournamentMode: 'Squad',
    tournamentMap: 'B. P. K',
    tournamentTime: '09:00:00 PM',
    userId: 'user-scrim-2',
    userName: 'Shadow Gamer',
    userEmail: 'shadow@ff.bd',
    ffUid: '1948291048',
    ffNickname: 'BD_SHADOW_07',
    teamName: 'Shadow Clan',
    phone: '01922334455',
    slotNumber: 2,
    status: 'CONFIRMED',
    registeredAt: '2026-10-07T08:10:00Z',
  },
  {
    id: 'reg-scrim9-3',
    tournamentId: 'ff-tour-013',
    tournamentTitle: 'BR SCRIM',
    tournamentMode: 'Squad',
    tournamentMap: 'B. P. K',
    tournamentTime: '09:00:00 PM',
    userId: 'user-scrim-3',
    userName: 'Rakib FF',
    userEmail: 'rakib@ff.bd',
    ffUid: '1839201948',
    ffNickname: '⚡RAKIB_FF⚡',
    teamName: 'Viper Force',
    phone: '01733445566',
    slotNumber: 3,
    status: 'CONFIRMED',
    registeredAt: '2026-10-07T08:15:00Z',
  },
  {
    id: 'reg-scrim9-4',
    tournamentId: 'ff-tour-013',
    tournamentTitle: 'BR SCRIM',
    tournamentMode: 'Squad',
    tournamentMap: 'B. P. K',
    tournamentTime: '09:00:00 PM',
    userId: 'user-scrim-4',
    userName: 'Naeem Pro',
    userEmail: 'naeem@ff.bd',
    ffUid: '1728394019',
    ffNickname: '★NAEEM_PRO★',
    teamName: 'Bengal Tigers',
    phone: '01644556677',
    slotNumber: 4,
    status: 'CONFIRMED',
    registeredAt: '2026-10-07T08:20:00Z',
  },
  {
    id: 'reg-scrim9-5',
    tournamentId: 'ff-tour-013',
    tournamentTitle: 'BR SCRIM',
    tournamentMode: 'Squad',
    tournamentMap: 'B. P. K',
    tournamentTime: '09:00:00 PM',
    userId: 'user-scrim-5',
    userName: 'Sakib Killer',
    userEmail: 'sakib@ff.bd',
    ffUid: '1639204817',
    ffNickname: 'KILLER_SAKIB',
    teamName: 'Delta BD',
    phone: '01555667788',
    slotNumber: 5,
    status: 'CONFIRMED',
    registeredAt: '2026-10-07T08:25:00Z',
  },
  // BR CHAMPION RUSH 9:00 PM (ff-tour-004) Slot Buyers
  {
    id: 'reg-champ9-1',
    tournamentId: 'ff-tour-004',
    tournamentTitle: 'BR CHAMPION RUSH',
    tournamentMode: 'Squad',
    tournamentMap: 'B. P. K. N. S',
    tournamentTime: '09:00:00 PM',
    userId: 'demo-user-1',
    userName: 'Ibrahim Hossain',
    userEmail: 'ibrahim380ih@gmail.com',
    ffUid: '1529384719',
    ffNickname: 'DEAD_SHOT_BD',
    teamName: 'Red Wolves',
    phone: '01899001122',
    slotNumber: 1,
    status: 'CONFIRMED',
    registeredAt: '2026-10-07T07:30:00Z',
  },
  {
    id: 'reg-champ9-2',
    tournamentId: 'ff-tour-004',
    tournamentTitle: 'BR CHAMPION RUSH',
    tournamentMode: 'Squad',
    tournamentMap: 'B. P. K. N. S',
    tournamentTime: '09:00:00 PM',
    userId: 'user-champ-2',
    userName: 'Cyber Ninja',
    userEmail: 'ninja@ff.bd',
    ffUid: '1428394018',
    ffNickname: 'CYBER_NINJA',
    teamName: 'Cyber Kings',
    phone: '01788990011',
    slotNumber: 2,
    status: 'CONFIRMED',
    registeredAt: '2026-10-07T07:45:00Z',
  },
  {
    id: 'reg-champ9-3',
    tournamentId: 'ff-tour-004',
    tournamentTitle: 'BR CHAMPION RUSH',
    tournamentMode: 'Squad',
    tournamentMap: 'B. P. K. N. S',
    tournamentTime: '09:00:00 PM',
    userId: 'user-champ-3',
    userName: 'Dark Demon',
    userEmail: 'demon@ff.bd',
    ffUid: '1329482019',
    ffNickname: 'RED_DEMON_77',
    teamName: 'Dark Knights',
    phone: '01677889900',
    slotNumber: 3,
    status: 'CONFIRMED',
    registeredAt: '2026-10-07T07:50:00Z',
  },
  {
    id: 'reg-champ9-4',
    tournamentId: 'ff-tour-004',
    tournamentTitle: 'BR CHAMPION RUSH',
    tournamentMode: 'Squad',
    tournamentMap: 'B. P. K. N. S',
    tournamentTime: '09:00:00 PM',
    userId: 'user-champ-4',
    userName: 'Phantom Soul',
    userEmail: 'soul@ff.bd',
    ffUid: '1293840192',
    ffNickname: 'DARK_SOUL_99',
    teamName: 'Phantom Crew',
    phone: '01566778899',
    slotNumber: 4,
    status: 'CONFIRMED',
    registeredAt: '2026-10-07T08:00:00Z',
  }
];

class StorageService {
  private get<T>(key: string, fallback: T): T {
    try {
      const data = localStorage.getItem(key);
      if (!data) return fallback;
      return JSON.parse(data) as T;
    } catch {
      return fallback;
    }
  }

  private set<T>(key: string, value: T): void {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.error('Storage write error:', e);
    }
  }

  // Tournaments
  getTournaments(): Tournament[] {
    const list = this.get<Tournament[]>(STORAGE_KEYS.TOURNAMENTS, INITIAL_TOURNAMENTS);
    const requiredCategories = ['BR SCRIM', 'BR BLAST', 'BR CHAMPION RUSH', 'CS 4V4', 'LONE WOLF', 'FREE MATCH'];
    const hasAll = requiredCategories.every(cat => list.some(t => t.matchCategory === cat));
    const hasOldSoloOr48 = list.some(t => t.title.includes('SOLO MATCH') || t.mode === 'Solo' || t.maxSlots === 48);
    const needsNewPricingOrMaps = list.some(t => 
      (t.matchCategory === 'BR SCRIM' && (t.entryFee !== 40 || t.map !== 'B. P. K' || t.title !== 'BR SCRIM')) ||
      (t.matchCategory === 'BR BLAST' && (t.entryFee !== 50 || t.prizePool !== 450 || t.map !== 'B. P. K. N' || t.title !== 'BR BLAST')) ||
      (t.matchCategory === 'BR CHAMPION RUSH' && (t.entryFee !== 80 || t.prizePool !== 700 || t.map !== 'B. P. K. N. S' || t.title !== 'BR CHAMPION RUSH')) ||
      (t.matchCategory === 'CS 4V4' && (t.maxSlots !== 4 || t.prizePool !== 100 || t.title !== 'CS 4 V 4 Clash squad')) ||
      (t.matchCategory === 'LONE WOLF' && (t.entryFee !== 50 || t.prizePool !== 80 || t.maxSlots !== 2 || t.title !== 'Lone Wolf'))
    );
    if (!hasAll || list.length < INITIAL_TOURNAMENTS.length || hasOldSoloOr48 || needsNewPricingOrMaps) {
      this.set(STORAGE_KEYS.TOURNAMENTS, INITIAL_TOURNAMENTS);
      return INITIAL_TOURNAMENTS;
    }
    return list;
  }

  getTournament(id: string): Tournament | undefined {
    return this.getTournaments().find(t => t.id === id);
  }

  saveTournament(tournament: Tournament): void {
    const list = this.getTournaments();
    const index = list.findIndex(t => t.id === tournament.id);
    if (index >= 0) {
      list[index] = tournament;
    } else {
      list.unshift(tournament);
    }
    this.set(STORAGE_KEYS.TOURNAMENTS, list);
  }

  deleteTournament(id: string): void {
    const list = this.getTournaments().filter(t => t.id !== id);
    this.set(STORAGE_KEYS.TOURNAMENTS, list);
  }

  // Registrations
  getRegistrations(): Registration[] {
    const list = this.get<Registration[]>(STORAGE_KEYS.REGISTRATIONS, INITIAL_DEMO_REGISTRATIONS);
    const hasCSorLW = list.some(r => r.tournamentId === 'ff-tour-005' || r.tournamentId === 'ff-tour-006');
    const hasDemoScrim9PM = list.some(r => r.tournamentId === 'ff-tour-013' && r.userId === 'demo-user-1');
    const hasDemoChamp9PM = list.some(r => r.tournamentId === 'ff-tour-004' && r.userId === 'demo-user-1');
    if ((!hasCSorLW || !hasDemoScrim9PM || !hasDemoChamp9PM) && list.some(r => r.userId === 'demo-user-1')) {
      const merged = [...list];
      INITIAL_DEMO_REGISTRATIONS.forEach(demoReg => {
        const existingIdx = merged.findIndex(r => r.id === demoReg.id);
        if (existingIdx >= 0) {
          merged[existingIdx] = demoReg;
        } else {
          merged.push(demoReg);
        }
      });
      this.set(STORAGE_KEYS.REGISTRATIONS, merged);
      return merged;
    }
    return list;
  }

  getUserRegistrations(userId: string): Registration[] {
    return this.getRegistrations().filter(r => r.userId === userId);
  }

  isUserRegistered(tournamentId: string, userId: string): boolean {
    return this.getRegistrations().some(
      r => r.tournamentId === tournamentId && 
           r.userId === userId && 
           r.status !== 'CANCELLED' && 
           r.status !== 'REJECTED'
    );
  }

  isUserConfirmed(tournamentId: string, userId: string): boolean {
    return this.getRegistrations().some(
      r => r.tournamentId === tournamentId && 
           r.userId === userId && 
           (r.status === 'CONFIRMED' || r.status === 'REGISTERED')
    );
  }

  getUserRegistrationForTournament(tournamentId: string, userId: string): Registration | undefined {
    return this.getRegistrations().find(
      r => r.tournamentId === tournamentId && 
           r.userId === userId && 
           r.status !== 'CANCELLED' &&
           r.status !== 'REJECTED'
    );
  }

  registerForTournament(reg: Omit<Registration, 'id' | 'registeredAt' | 'slotNumber' | 'status'>): Registration {
    const registrations = this.getRegistrations();
    const tournament = this.getTournament(reg.tournamentId);
    const isPaid = tournament ? tournament.entryFee > 0 : false;

    // For free matches, assign slot immediately.
    // For paid matches, status is PENDING_APPROVAL until Admin verifies bKash/Nagad TrxID!
    let assignedSlot: number | undefined = undefined;
    let initialStatus: Registration['status'] = 'PENDING_APPROVAL';

    if (!isPaid) {
      const currentConfirmed = registrations.filter(
        r => r.tournamentId === reg.tournamentId && (r.status === 'CONFIRMED' || r.status === 'REGISTERED')
      );
      assignedSlot = currentConfirmed.length + 1;
      initialStatus = 'CONFIRMED';
    }

    const newReg: Registration = {
      ...reg,
      id: `reg-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      slotNumber: assignedSlot,
      status: initialStatus,
      amountPaid: isPaid ? (reg.amountPaid || tournament?.entryFee || 0) : 0,
      registeredAt: new Date().toISOString(),
    };

    registrations.push(newReg);
    this.set(STORAGE_KEYS.REGISTRATIONS, registrations);

    if (!isPaid && tournament) {
      tournament.joinedSlots = Math.min(tournament.maxSlots, tournament.joinedSlots + 1);
      if (tournament.joinedSlots >= tournament.maxSlots) {
        tournament.status = 'FULL';
      }
      this.saveTournament(tournament);
    }

    // Auto-generate notification
    if (isPaid) {
      this.addNotification({
        userId: reg.userId,
        tournamentId: reg.tournamentId,
        title: '⏳ পেমেন্ট ভেরিফিকেশন পেন্ডিং',
        message: `"${reg.tournamentTitle}" এর জন্য পেমেন্ট জমা হয়েছে (TrxID: ${reg.transactionId || 'N/A'})। এডমিন কনফার্ম করলে স্লট বরাদ্দ করা হবে।`,
        type: 'REGISTRATION',
        read: false,
      });
    } else {
      this.addNotification({
        userId: reg.userId,
        tournamentId: reg.tournamentId,
        title: '🎉 রেজিস্ট্রেশন কনফার্মড!',
        message: `"${reg.tournamentTitle}" এ স্লট #${assignedSlot} বরাদ্দ হয়েছে।`,
        type: 'REGISTRATION',
        read: false,
      });
    }

    return newReg;
  }

  adminApproveRegistration(registrationId: string): { success: boolean; message: string; registration?: Registration } {
    const registrations = this.getRegistrations();
    const reg = registrations.find(r => r.id === registrationId);

    if (!reg) {
      return { success: false, message: 'রেজিস্ট্রেশন রেকর্ড পাওয়া যায়নি।' };
    }

    if (reg.status === 'CONFIRMED' || reg.status === 'REGISTERED') {
      return { success: false, message: 'এই রেজিস্ট্রেশন ইতিমধ্যে কনফার্ম করা হয়েছে।' };
    }

    const tournament = this.getTournament(reg.tournamentId);
    if (!tournament) {
      return { success: false, message: 'টুর্নামেন্ট পাওয়া যায়নি।' };
    }

    if (tournament.joinedSlots >= tournament.maxSlots) {
      return { success: false, message: 'টুর্নামেন্টের সব স্লট ইতিমধ্যে পূর্ণ (Full) হয়ে গেছে।' };
    }

    // Allocate next slot
    const confirmedRegs = registrations.filter(
      r => r.tournamentId === reg.tournamentId && (r.status === 'CONFIRMED' || r.status === 'REGISTERED')
    );
    const allocatedSlot = confirmedRegs.length + 1;

    reg.slotNumber = allocatedSlot;
    reg.status = 'CONFIRMED';

    // Increment tournament joinedSlots
    tournament.joinedSlots = Math.min(tournament.maxSlots, tournament.joinedSlots + 1);
    if (tournament.joinedSlots >= tournament.maxSlots) {
      tournament.status = 'FULL';
    } else if (tournament.joinedSlots >= tournament.maxSlots * 0.8) {
      tournament.status = 'ALMOST_FULL';
    }

    this.saveTournament(tournament);
    this.set(STORAGE_KEYS.REGISTRATIONS, registrations);

    // Notify user
    this.addNotification({
      userId: reg.userId,
      tournamentId: reg.tournamentId,
      title: '🎉 পেমেন্ট অনুমোদিত! স্লট কনফার্মড',
      message: `আপনার "${reg.tournamentTitle}" টুর্নামেন্টের পেমেন্ট সফলভাবে ভেরিফাই হয়েছে। আপনার টিম স্লট নম্বর: #${allocatedSlot}। My Matches এ বিস্তারিত দেখুন।`,
      type: 'REGISTRATION',
      read: false,
    });

    return { success: true, message: `সফলভাবে স্লট #${allocatedSlot} কনফার্ম করা হয়েছে!`, registration: reg };
  }

  adminRejectRegistration(registrationId: string, reason?: string): { success: boolean; message: string } {
    const registrations = this.getRegistrations();
    const reg = registrations.find(r => r.id === registrationId);

    if (!reg) {
      return { success: false, message: 'রেজিস্ট্রেশন পাওয়া যায়নি।' };
    }

    const previousStatus = reg.status;
    reg.status = 'REJECTED';
    reg.adminNote = reason || 'পেমেন্ট ভেরিফিকেশন ব্যর্থ হয়েছে বা ভুল ট্রানজেকশন আইডি দেওয়া হয়েছে।';

    // If it was previously confirmed, decrement slot
    if (previousStatus === 'CONFIRMED' || previousStatus === 'REGISTERED') {
      const tour = this.getTournament(reg.tournamentId);
      if (tour && tour.joinedSlots > 0) {
        tour.joinedSlots -= 1;
        if (tour.status === 'FULL') tour.status = 'OPEN';
        this.saveTournament(tour);
      }
    }

    this.set(STORAGE_KEYS.REGISTRATIONS, registrations);

    this.addNotification({
      userId: reg.userId,
      tournamentId: reg.tournamentId,
      title: '❌ পেমেন্ট রিকোয়েস্ট বাতিল করা হয়েছে',
      message: `"${reg.tournamentTitle}" এর পেমেন্ট রিকোয়েস্ট বাতিল হয়েছে। কারণ: ${reg.adminNote}`,
      type: 'ANNOUNCEMENT',
      read: false,
    });

    return { success: true, message: 'রেজিস্ট্রেশন বাতিল করা হয়েছে।' };
  }

  cancelRegistration(registrationId: string): void {
    const list = this.getRegistrations();
    const reg = list.find(r => r.id === registrationId);
    if (reg) {
      const prev = reg.status;
      reg.status = 'CANCELLED';
      this.set(STORAGE_KEYS.REGISTRATIONS, list);
      
      if (prev === 'CONFIRMED' || prev === 'REGISTERED') {
        const tour = this.getTournament(reg.tournamentId);
        if (tour && tour.joinedSlots > 0) {
          tour.joinedSlots -= 1;
          if (tour.status === 'FULL') tour.status = 'OPEN';
          this.saveTournament(tour);
        }
      }
    }
  }

  // Room Management (STRICT SECURITY GATE)
  private getAllRooms(): Record<string, RoomData> {
    return this.get<Record<string, RoomData>>(STORAGE_KEYS.ROOMS, INITIAL_ROOMS);
  }

  getRoomSecure(
    tournamentId: string, 
    userId?: string, 
    isAdmin = false
  ): { 
    status: 'NOT_FOUND' | 'UNREGISTERED' | 'LOCKED' | 'AVAILABLE'; 
    room?: RoomData; 
    message: string;
  } {
    const rooms = this.getAllRooms();
    const room = rooms[tournamentId];

    if (!room) {
      return {
        status: 'NOT_FOUND',
        message: 'Room details have not been created yet by the tournament host.',
      };
    }

    // Admins always have access
    if (isAdmin) {
      return {
        status: room.isReleased ? 'AVAILABLE' : 'LOCKED',
        room,
        message: room.isReleased ? 'Room is currently RELEASED to registered players.' : 'Room is currently LOCKED/HIDDEN from players.',
      };
    }

    // If user is not logged in or registration is not confirmed by admin
    if (!userId || !this.isUserConfirmed(tournamentId, userId)) {
      const reg = userId ? this.getUserRegistrationForTournament(tournamentId, userId) : undefined;
      if (reg && reg.status === 'PENDING_APPROVAL') {
        return {
          status: 'UNREGISTERED',
          message: 'আপনার পেমেন্ট ভেরিফিকেশন পেন্ডিং রয়েছে। এডমিন কনফার্ম করলে রুম আইডি দেখতে পাবেন।',
        };
      }
      return {
        status: 'UNREGISTERED',
        message: 'রুম আইডি ও পাসওয়ার্ড শুধুমাত্র এই টুর্নামেন্টের কনফার্মড প্লেয়ারদের জন্য সংরক্ষিত।',
      };
    }

    // If room is not released yet by admin
    if (!room.isReleased) {
      return {
        status: 'LOCKED',
        room: {
          ...room,
          roomId: '••••••••',
          password: '••••',
        },
        message: `LOCKED: Room ID & Password will be available soon${room.releaseTime ? ` (Scheduled for ${room.releaseTime})` : ' (10-15 mins before match)'}.`,
      };
    }

    // Authenticated + Registered + Released
    return {
      status: 'AVAILABLE',
      room,
      message: 'Room ID and Password are now available! Please enter the custom room immediately.',
    };
  }

  saveRoom(roomData: RoomData): void {
    const rooms = this.getAllRooms();
    const previous = rooms[roomData.tournamentId];
    rooms[roomData.tournamentId] = {
      ...roomData,
      updatedAt: new Date().toISOString(),
    };
    this.set(STORAGE_KEYS.ROOMS, rooms);

    // If room was just released, notify all registered users!
    if (roomData.isReleased && (!previous || !previous.isReleased)) {
      const registrations = this.getRegistrations().filter(
        r => r.tournamentId === roomData.tournamentId && r.status !== 'CANCELLED'
      );
      const tour = this.getTournament(roomData.tournamentId);
      const tourTitle = tour ? tour.title : 'Your Tournament';

      registrations.forEach(reg => {
        this.addNotification({
          userId: reg.userId,
          tournamentId: roomData.tournamentId,
          title: '🔥 ROOM ID RELEASED!',
          message: `Room ID and Password are now available for "${tourTitle}". Go to "My Matches" to copy credentials and join!`,
          type: 'ROOM_RELEASE',
          read: false,
        });
      });
    }
  }

  // Results & Leaderboard
  getResults(tournamentId?: string): MatchResult[] {
    let list = this.get<MatchResult[]>(STORAGE_KEYS.RESULTS, INITIAL_RESULTS);
    if (!list || list.length === 0) {
      list = INITIAL_RESULTS;
      this.set(STORAGE_KEYS.RESULTS, list);
    }
    if (tournamentId) {
      return list.filter(r => r.tournamentId === tournamentId);
    }
    return list;
  }

  saveResult(result: MatchResult): void {
    const list = this.getResults();
    const index = list.findIndex(r => r.id === result.id);
    if (index >= 0) {
      list[index] = result;
    } else {
      list.push(result);
    }
    this.set(STORAGE_KEYS.RESULTS, list);
  }

  saveBatchResults(tournamentId: string, results: MatchResult[]): void {
    const currentList = this.getResults().filter(r => r.tournamentId !== tournamentId);
    const updated = [...currentList, ...results];
    this.set(STORAGE_KEYS.RESULTS, updated);

    // Notify registered players
    const tour = this.getTournament(tournamentId);
    if (tour) {
      tour.status = 'COMPLETED';
      this.saveTournament(tour);
    }

    this.addNotification({
      userId: 'all',
      tournamentId,
      title: '🏆 Results Published!',
      message: `Match standings and points for "${tour?.title || 'Tournament'}" have been published. Check out the Leaderboard!`,
      type: 'RESULT',
      read: false,
    });
  }

  // Notifications
  getNotifications(userId: string): NotificationItem[] {
    const list = this.get<NotificationItem[]>(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS);
    return list.filter(n => n.userId === 'all' || n.userId === userId);
  }

  addNotification(notif: Omit<NotificationItem, 'id' | 'createdAt'>): void {
    const list = this.get<NotificationItem[]>(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS);
    const newItem: NotificationItem = {
      ...notif,
      id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      createdAt: new Date().toISOString(),
    };
    list.unshift(newItem);
    this.set(STORAGE_KEYS.NOTIFICATIONS, list);
  }

  markNotificationRead(id: string): void {
    const list = this.get<NotificationItem[]>(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS);
    const target = list.find(n => n.id === id);
    if (target) {
      target.read = true;
      this.set(STORAGE_KEYS.NOTIFICATIONS, list);
    }
  }

  markAllNotificationsRead(userId: string): void {
    const list = this.get<NotificationItem[]>(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS);
    list.forEach(n => {
      if (n.userId === 'all' || n.userId === userId) {
        n.read = true;
      }
    });
    this.set(STORAGE_KEYS.NOTIFICATIONS, list);
  }

  // User Profile
  getUserProfile(): UserProfile {
    return this.get<UserProfile>(STORAGE_KEYS.USER_PROFILE, DEFAULT_DEMO_USER);
  }

  saveUserProfile(profile: UserProfile): void {
    this.set(STORAGE_KEYS.USER_PROFILE, profile);
  }

  // Registered Accounts (Name, Phone, Password)
  getUserAccounts(): Record<string, { name: string; phone: string; password: string; profile: UserProfile }> {
    return this.get<Record<string, { name: string; phone: string; password: string; profile: UserProfile }>>(
      STORAGE_KEYS.REGISTERED_USERS,
      {
        '01712345678': {
          name: 'Ibrahim Hossain',
          phone: '01712345678',
          password: '123',
          profile: DEFAULT_DEMO_USER,
        }
      }
    );
  }

  saveUserAccount(account: { name: string; phone: string; password: string; profile: UserProfile }): void {
    const accounts = this.getUserAccounts();
    accounts[account.phone] = account;
    this.set(STORAGE_KEYS.REGISTERED_USERS, accounts);
  }

  // Admin Payment Number (bKash/Nagad)
  getAdminPaymentNumber(): string {
    return this.get<string>('ff_arena_admin_payment_num', '01712345678');
  }

  saveAdminPaymentNumber(num: string): void {
    this.set('ff_arena_admin_payment_num', num);
  }

  // Reset to initial demo data
  resetDemoData(): void {
    localStorage.removeItem(STORAGE_KEYS.TOURNAMENTS);
    localStorage.removeItem(STORAGE_KEYS.REGISTRATIONS);
    localStorage.removeItem(STORAGE_KEYS.ROOMS);
    localStorage.removeItem(STORAGE_KEYS.RESULTS);
    localStorage.removeItem(STORAGE_KEYS.NOTIFICATIONS);
    localStorage.removeItem(STORAGE_KEYS.USER_PROFILE);
    localStorage.removeItem('ff_arena_admin_payment_num');
  }
}

export const storage = new StorageService();
