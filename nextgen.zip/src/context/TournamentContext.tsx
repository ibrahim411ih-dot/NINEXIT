import React, { createContext, useContext, useState, useEffect } from 'react';
import { Tournament, Registration, RoomData, MatchResult, NotificationItem } from '../types';
import { storage } from '../services/storage';
import { useAuth } from './AuthContext';

interface TournamentContextType {
  tournaments: Tournament[];
  userRegistrations: Registration[];
  allRegistrations: Registration[];
  notifications: NotificationItem[];
  unreadNotificationCount: number;
  results: MatchResult[];
  
  // Actions
  joinTournament: (data: {
    tournamentId: string;
    ffUid: string;
    ffNickname: string;
    teamName?: string;
    phone: string;
    paymentMethod?: 'bKash' | 'Nagad';
    senderNumber?: string;
    transactionId?: string;
    amountPaid?: number;
  }) => Promise<{ success: boolean; registration?: Registration; message: string }>;
  
  cancelRegistration: (registrationId: string) => void;
  
  // Room access
  getRoomCredentials: (tournamentId: string) => {
    status: 'NOT_FOUND' | 'UNREGISTERED' | 'LOCKED' | 'AVAILABLE';
    room?: RoomData;
    message: string;
  };
  
  // Admin actions
  adminSaveTournament: (tournament: Tournament) => void;
  adminDeleteTournament: (id: string) => void;
  adminSaveRoom: (roomData: RoomData) => void;
  adminSaveResults: (tournamentId: string, results: MatchResult[]) => void;
  adminSendNotification: (notif: { title: string; message: string; type: NotificationItem['type']; targetUserId?: string; tournamentId?: string }) => void;
  adminApproveRegistration: (registrationId: string) => { success: boolean; message: string; registration?: Registration };
  adminRejectRegistration: (registrationId: string, reason?: string) => { success: boolean; message: string };
  
  // Notifications
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  
  // Helpers
  isRegisteredFor: (tournamentId: string) => boolean;
  refreshData: () => void;
  resetAllDemoData: () => void;
}

const TournamentContext = createContext<TournamentContextType | undefined>(undefined);

export const TournamentProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isAdmin } = useAuth();
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [allRegistrations, setAllRegistrations] = useState<Registration[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [results, setResults] = useState<MatchResult[]>([]);

  const refreshData = () => {
    setTournaments(storage.getTournaments());
    setAllRegistrations(storage.getRegistrations());
    setNotifications(storage.getNotifications(user?.uid || 'guest'));
    setResults(storage.getResults());
  };

  useEffect(() => {
    refreshData();
  }, [user]);

  const userRegistrations = user 
    ? allRegistrations.filter(r => r.userId === user.uid && r.status !== 'CANCELLED')
    : [];

  const unreadNotificationCount = notifications.filter(n => !n.read).length;

  const isRegisteredFor = (tournamentId: string): boolean => {
    if (!user) return false;
    return userRegistrations.some(
      r => r.tournamentId === tournamentId && 
           r.status !== 'CANCELLED' && 
           r.status !== 'REJECTED'
    );
  };

  const joinTournament = async (data: {
    tournamentId: string;
    ffUid: string;
    ffNickname: string;
    teamName?: string;
    phone: string;
    paymentMethod?: 'bKash' | 'Nagad';
    senderNumber?: string;
    transactionId?: string;
    amountPaid?: number;
  }) => {
    if (!user) {
      return { success: false, message: 'টুর্নামেন্টে জয়েন করতে দয়া করে লগইন করুন।' };
    }

    const tour = tournaments.find(t => t.id === data.tournamentId);
    if (!tour) {
      return { success: false, message: 'টুর্নামেন্ট পাওয়া যায়নি।' };
    }

    if (tour.status === 'FULL' || tour.joinedSlots >= tour.maxSlots) {
      return { success: false, message: 'এই টুর্নামেন্টের সব টিম পূর্ণ হয়ে গেছে (SOLD OUT)।' };
    }

    if (tour.status === 'COMPLETED' || tour.status === 'CANCELLED' || tour.status === 'REGISTRATION_CLOSED') {
      return { success: false, message: 'এই টুর্নামেন্টের রেজিস্ট্রেশন বন্ধ রয়েছে।' };
    }

    if (isRegisteredFor(data.tournamentId)) {
      return { success: false, message: 'আপনি ইতিমধ্যে এই টুর্নামেন্টে জয়েন করার রিকোয়েস্ট পাঠিয়েছেন।' };
    }

    const newReg = storage.registerForTournament({
      tournamentId: data.tournamentId,
      tournamentTitle: tour.title,
      tournamentMode: tour.mode,
      tournamentMap: tour.map,
      tournamentTime: tour.time,
      userId: user.uid,
      userName: user.displayName,
      userEmail: user.email,
      ffUid: data.ffUid,
      ffNickname: data.ffNickname,
      teamName: data.teamName,
      phone: data.phone,
      paymentMethod: data.paymentMethod,
      senderNumber: data.senderNumber,
      transactionId: data.transactionId,
      amountPaid: data.amountPaid || tour.entryFee,
    });

    refreshData();
    const isPaid = tour.entryFee > 0;
    const msg = isPaid
      ? 'পেমেন্ট রিকোয়েস্ট জমা হয়েছে! এডমিন যাচাই করে কনফার্ম করলে স্লট নম্বর বরাদ্দ হবে।'
      : 'রেজিস্ট্রেশন সফলভাবে সম্পন্ন হয়েছে!';
    return { success: true, registration: newReg, message: msg };
  };

  const cancelRegistration = (registrationId: string) => {
    storage.cancelRegistration(registrationId);
    refreshData();
  };

  const getRoomCredentials = (tournamentId: string) => {
    return storage.getRoomSecure(tournamentId, user?.uid, isAdmin);
  };

  const adminApproveRegistration = (registrationId: string) => {
    const result = storage.adminApproveRegistration(registrationId);
    refreshData();
    return result;
  };

  const adminRejectRegistration = (registrationId: string, reason?: string) => {
    const result = storage.adminRejectRegistration(registrationId, reason);
    refreshData();
    return result;
  };

  // Admin Actions
  const adminSaveTournament = (tournament: Tournament) => {
    storage.saveTournament(tournament);
    refreshData();
  };

  const adminDeleteTournament = (id: string) => {
    storage.deleteTournament(id);
    refreshData();
  };

  const adminSaveRoom = (roomData: RoomData) => {
    storage.saveRoom(roomData);
    refreshData();
  };

  const adminSaveResults = (tournamentId: string, matchResults: MatchResult[]) => {
    storage.saveBatchResults(tournamentId, matchResults);
    refreshData();
  };

  const adminSendNotification = (notif: { 
    title: string; 
    message: string; 
    type: NotificationItem['type']; 
    targetUserId?: string; 
    tournamentId?: string; 
  }) => {
    storage.addNotification({
      userId: notif.targetUserId || 'all',
      tournamentId: notif.tournamentId,
      title: notif.title,
      message: notif.message,
      type: notif.type,
      read: false,
    });
    refreshData();
  };

  const markNotificationRead = (id: string) => {
    storage.markNotificationRead(id);
    refreshData();
  };

  const markAllNotificationsRead = () => {
    if (user) {
      storage.markAllNotificationsRead(user.uid);
      refreshData();
    }
  };

  const resetAllDemoData = () => {
    storage.resetDemoData();
    refreshData();
  };

  return (
    <TournamentContext.Provider
      value={{
        tournaments,
        userRegistrations,
        allRegistrations,
        notifications,
        unreadNotificationCount,
        results,
        joinTournament,
        cancelRegistration,
        getRoomCredentials,
        adminSaveTournament,
        adminDeleteTournament,
        adminSaveRoom,
        adminSaveResults,
        adminSendNotification,
        adminApproveRegistration,
        adminRejectRegistration,
        markNotificationRead,
        markAllNotificationsRead,
        isRegisteredFor,
        refreshData,
        resetAllDemoData,
      }}
    >
      {children}
    </TournamentContext.Provider>
  );
};

export const useTournaments = () => {
  const context = useContext(TournamentContext);
  if (!context) {
    throw new Error('useTournaments must be used within a TournamentProvider');
  }
  return context;
};
