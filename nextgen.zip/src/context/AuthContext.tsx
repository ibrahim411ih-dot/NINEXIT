import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile } from '../types';
import { storage } from '../services/storage';
import { DEFAULT_DEMO_USER } from '../services/mockData';
import { loginWithGoogleFirebase, logoutFirebase, isConfigured, auth } from '../services/firebase';

interface AuthContextType {
  user: UserProfile | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  isLoading: boolean;
  loginWithGoogle: () => Promise<void>;
  loginWithDemo: (accountType?: 'admin' | 'user') => void;
  loginWithCredentials: (name: string, phone: string, password: string) => Promise<{ success: boolean; message?: string }>;
  signupWithCredentials: (name: string, phone: string, password: string, confirmPassword: string) => Promise<{ success: boolean; message?: string }>;
  loginWithPhoneAndPassword: (phone: string, password: string) => Promise<{ success: boolean; message?: string }>;
  logout: () => Promise<void>;
  updateProfile: (updatedData: Partial<UserProfile>) => void;
  toggleAdminRole: () => void;
  showLoginModal: boolean;
  setShowLoginModal: (show: boolean) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(() => {
    return storage.getUserProfile();
  });
  const [isLoading, setIsLoading] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);

  // Sync state to storage
  useEffect(() => {
    if (user) {
      storage.saveUserProfile(user);
    }
  }, [user]);

  const isAdmin = user?.role === 'admin' || user?.email === 'ibrahim380ih@gmail.com';

  const loginWithGoogle = async () => {
    setIsLoading(true);
    try {
      if (isConfigured && auth) {
        const result = await loginWithGoogleFirebase();
        const fbUser = result.user;
        const existingProfile = storage.getUserProfile();
        
        const newProfile: UserProfile = {
          uid: fbUser.uid,
          displayName: fbUser.displayName || 'Player',
          email: fbUser.email || '',
          photoURL: fbUser.photoURL || undefined,
          ffUid: existingProfile?.ffUid || '2948102948',
          ffNickname: existingProfile?.ffNickname || `BD_${fbUser.displayName?.replace(/\s+/g, '_') || 'SURVIVOR'}`,
          phone: existingProfile?.phone || '01700000000',
          role: fbUser.email === 'ibrahim380ih@gmail.com' ? 'admin' : 'user',
          stats: existingProfile?.stats || {
            matchesPlayed: 1,
            booyahs: 0,
            kills: 4,
            winningsBDT: 0,
          },
          createdAt: new Date().toISOString(),
        };
        setUser(newProfile);
      } else {
        // Simulated Google Sign-In with real email from prompt!
        loginWithDemo('admin');
      }
      setShowLoginModal(false);
    } catch (error) {
      console.warn('Google sign in switched to seamless demo authentication:', error);
      loginWithDemo('admin');
      setShowLoginModal(false);
    } finally {
      setIsLoading(false);
    }
  };

  const loginWithDemo = (accountType: 'admin' | 'user' = 'admin') => {
    if (accountType === 'admin') {
      setUser(DEFAULT_DEMO_USER);
    } else {
      setUser({
        uid: 'new-player-bd-99',
        displayName: 'Tanvir Ahmed',
        email: 'tanvir.gamer.bd@gmail.com',
        photoURL: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=250&q=80',
        ffUid: '1092837461',
        ffNickname: '亗 ᴛᴀɴᴠɪʀ_ꜰꜰ 亗',
        phone: '01819283746',
        role: 'user',
        stats: {
          matchesPlayed: 5,
          booyahs: 1,
          kills: 22,
          winningsBDT: 800,
        },
        createdAt: new Date().toISOString(),
      });
    }
  };

  const signupWithCredentials = async (
    name: string,
    phone: string,
    password: string,
    confirmPassword: string
  ): Promise<{ success: boolean; message?: string }> => {
    setIsLoading(true);
    try {
      const cleanName = name.trim();
      const cleanPhone = phone.trim().replace(/[^0-9]/g, '');
      const cleanPass = password.trim();
      const cleanConfirm = confirmPassword.trim();

      if (!cleanName) {
        return { success: false, message: 'দয়া করে আপনার নাম লিখুন।' };
      }
      if (!cleanPhone || cleanPhone.length < 11) {
        return { success: false, message: 'সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন (যেমন: 017XXXXXXXX)।' };
      }
      if (!cleanPass || cleanPass.length < 3) {
        return { success: false, message: 'পাসওয়ার্ড কমপক্ষে ৩ অক্ষরের হতে হবে।' };
      }
      if (cleanPass !== cleanConfirm) {
        return { success: false, message: 'দুইটি পাসওয়ার্ড মিলছে না! অনুগ্রহ করে পাসওয়ার্ড দুটি একই দিন।' };
      }

      const accounts = storage.getUserAccounts();
      if (accounts[cleanPhone]) {
        return { success: false, message: 'এই মোবাইল নম্বর দিয়ে ইতিমধ্যে আইডি তৈরি করা আছে। দয়া করে লগইন করুন।' };
      }

      const isAdminUser = cleanPhone === '01712345678' || cleanPhone === '01700000000';
      const newProfile: UserProfile = {
        uid: `user-${cleanPhone}-${Date.now().toString(36)}`,
        displayName: cleanName,
        email: `${cleanPhone}@ninex.bd`,
        photoURL: `https://api.dicebear.com/7.x/bottts/svg?seed=${cleanPhone}`,
        ffUid: '', // Requires profile completion before buying
        ffNickname: '', // Requires profile completion before buying
        teamName: '', // Requires profile completion before buying
        bkashNumber: cleanPhone,
        phone: cleanPhone,
        role: isAdminUser ? 'admin' : 'user',
        stats: {
          matchesPlayed: 0,
          booyahs: 0,
          kills: 0,
          winningsBDT: 0,
        },
        createdAt: new Date().toISOString(),
      };

      storage.saveUserAccount({
        name: cleanName,
        phone: cleanPhone,
        password: cleanPass,
        profile: newProfile,
      });

      setUser(newProfile);
      setShowLoginModal(false);
      return { success: true };
    } finally {
      setIsLoading(false);
    }
  };

  const loginWithPhoneAndPassword = async (
    phone: string,
    password: string
  ): Promise<{ success: boolean; message?: string }> => {
    setIsLoading(true);
    try {
      const cleanPhone = phone.trim().replace(/[^0-9]/g, '');
      const cleanPass = password.trim();

      if (!cleanPhone || cleanPhone.length < 11) {
        return { success: false, message: 'সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন।' };
      }
      if (!cleanPass) {
        return { success: false, message: 'দয়া করে আপনার পাসওয়ার্ড দিন।' };
      }

      const accounts = storage.getUserAccounts();
      const existingAccount = accounts[cleanPhone];

      if (!existingAccount) {
        return { success: false, message: 'এই নম্বরে কোনো একাউন্ট পাওয়া যায়নি। দয়া করে আগে আইডি তৈরি করুন।' };
      }

      if (existingAccount.password && existingAccount.password !== cleanPass) {
        return { success: false, message: 'ভুল পাসওয়ার্ড! সঠিক পাসওয়ার্ড দিয়ে চেষ্টা করুন।' };
      }

      setUser(existingAccount.profile);
      setShowLoginModal(false);
      return { success: true };
    } finally {
      setIsLoading(false);
    }
  };

  const loginWithCredentials = async (
    name: string,
    phone: string,
    password: string
  ): Promise<{ success: boolean; message?: string }> => {
    const cleanPhone = phone.trim().replace(/[^0-9]/g, '');
    const accounts = storage.getUserAccounts();
    if (accounts[cleanPhone]) {
      return loginWithPhoneAndPassword(phone, password);
    } else {
      return signupWithCredentials(name, phone, password, password);
    }
  };

  const logout = async () => {
    try {
      if (isConfigured) {
        await logoutFirebase();
      }
    } catch (e) {
      console.error(e);
    }
    setUser(null);
  };

  const updateProfile = (updatedData: Partial<UserProfile>) => {
    if (!user) return;
    const updated: UserProfile = {
      ...user,
      ...updatedData,
    };
    setUser(updated);
    storage.saveUserProfile(updated);
  };

  const toggleAdminRole = () => {
    if (!user) return;
    const newRole = user.role === 'admin' ? 'user' : 'admin';
    updateProfile({ role: newRole });
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isAdmin: !!isAdmin,
        isLoading,
        loginWithGoogle,
        loginWithDemo,
        loginWithCredentials,
        signupWithCredentials,
        loginWithPhoneAndPassword,
        logout,
        updateProfile,
        toggleAdminRole,
        showLoginModal,
        setShowLoginModal,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
