export type TournamentMode = 'Solo' | 'Duo' | 'Squad';
export type TournamentMap = 'Bermuda' | 'Purgatory' | 'Kalahari' | 'Alpine' | 'Nexterra' | 'Solara' | 'Lone Wolf Map' | string;
export type TournamentStatus = 
  | 'OPEN'
  | 'ALMOST_FULL'
  | 'FULL'
  | 'REGISTRATION_CLOSED'
  | 'LIVE'
  | 'COMPLETED'
  | 'CANCELLED';

export interface Tournament {
  id: string;
  title: string;
  game: string;
  mode: TournamentMode;
  map: TournamentMap;
  date: string; // e.g. "Today, Oct 7"
  time: string; // e.g. "08:30 PM BST"
  regDeadline: string; // e.g. "08:00 PM BST"
  maxSlots: number;
  joinedSlots: number;
  entryFee: number; // In BDT ৳ (0 = Free)
  prizePool: number; // Total prize in BDT ৳
  prizeDetails: {
    first: number;
    second?: number;
    third?: number;
    perKill?: number;
  };
  status: TournamentStatus;
  bannerUrl: string;
  rules: string[];
  matchCategory?: 'BR SCRIM' | 'BR BLAST' | 'BR CHAMPION RUSH' | 'CS 4V4' | 'LONE WOLF' | 'FREE MATCH' | string;
  customType?: string;
  matchTimestamp?: number;
  createdAt: string;
}

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  photoURL?: string;
  ffUid: string; // Free Fire in-game UID (e.g. 1928374829)
  ffNickname: string; // Free Fire IGN (e.g. 亗 DARK亗KILLER)
  teamName?: string; // Player's squad / clan team name
  bkashNumber?: string; // bKash / Nagad number for payment & prize
  phone: string; // Bangladeshi Phone number (01XXXXXXXXX)
  role: 'user' | 'admin';
  stats: {
    matchesPlayed: number;
    booyahs: number;
    kills: number;
    winningsBDT: number;
  };
  createdAt: string;
}

export const isUserProfileComplete = (user: UserProfile | null): boolean => {
  if (!user) return false;
  const hasGameName = Boolean(user.ffNickname && user.ffNickname.trim().length > 0);
  const hasGameUid = Boolean(user.ffUid && user.ffUid.trim().length >= 5);
  const hasTeamName = Boolean(user.teamName && user.teamName.trim().length > 0);
  const hasPaymentNumber = Boolean(
    (user.bkashNumber && user.bkashNumber.trim().length >= 11) ||
    (user.phone && user.phone.trim().length >= 11)
  );
  return hasGameName && hasGameUid && hasTeamName && hasPaymentNumber;
};

export interface Registration {
  id: string;
  tournamentId: string;
  tournamentTitle: string;
  tournamentMode: TournamentMode;
  tournamentMap: TournamentMap;
  tournamentTime: string;
  userId: string;
  userName: string;
  userEmail: string;
  ffUid: string;
  ffNickname: string;
  teamName?: string;
  teamMembers?: string[]; // For Duo/Squad
  phone: string;
  slotNumber?: number; // Allocated once confirmed by Admin
  paymentMethod?: 'bKash' | 'Nagad';
  senderNumber?: string;
  transactionId?: string;
  amountPaid?: number;
  status: 'PENDING_APPROVAL' | 'REGISTERED' | 'CONFIRMED' | 'CANCELLED' | 'REJECTED';
  adminNote?: string;
  registeredAt: string;
}

export interface RoomData {
  tournamentId: string;
  roomId: string;
  password: string;
  isReleased: boolean;
  releaseTime?: string; // e.g. "08:15 PM BST"
  notes?: string;
  updatedAt: string;
}

export interface MatchResult {
  id: string;
  tournamentId: string;
  tournamentTitle: string;
  matchCategory?: string;
  rank: number;
  playerName: string;
  ffUid: string;
  teamName?: string;
  kills: number;
  placementPoints: number;
  totalPoints: number;
  prizeWon?: number;
  matchesPlayed?: number; // ম্যাচ সংখ্যা (default 1)
  booyahs?: number; // Booyah সংখ্যা (default 1 if rank 1 else 0)
  isDesignatedChampion?: boolean; // For Champion Rush custom champion selection
}

// Free Fire Official Esports Point System:
// #1 = 12, #2 = 9, #3 = 8, #4 = 7, #5 = 6, #6 = 5, #7 = 4, #8 = 3, #9 = 2, #10 = 1, #11 = 0, #12 = 0
// Per Kill = 1 pt
export const FF_OFFICIAL_PLACEMENT_POINTS: Record<number, number> = {
  1: 12,
  2: 9,
  3: 8,
  4: 7,
  5: 6,
  6: 5,
  7: 4,
  8: 3,
  9: 2,
  10: 1,
  11: 0,
  12: 0,
};

export const getFFPlacementPoints = (rank: number): number => {
  if (rank in FF_OFFICIAL_PLACEMENT_POINTS) {
    return FF_OFFICIAL_PLACEMENT_POINTS[rank];
  }
  return 0;
};

export interface NotificationItem {
  id: string;
  userId: string; // 'all' or specific user UID
  tournamentId?: string;
  title: string;
  message: string;
  type: 'REGISTRATION' | 'ROOM_RELEASE' | 'MATCH_START' | 'RESULT' | 'ANNOUNCEMENT';
  read: boolean;
  createdAt: string;
  actionUrl?: string;
}
