/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { TournamentProvider, useTournaments } from './context/TournamentContext';
import { Navbar } from './components/Navbar';
import { BottomNav } from './components/BottomNav';
import { RegistrationModal } from './components/RegistrationModal';
import { RoomModal } from './components/RoomModal';
import { LoginModal } from './components/LoginModal';
import { NotificationModal } from './components/NotificationModal';
import { WalletModal } from './components/WalletModal';
import { PrizeListModal } from './components/PrizeListModal';

import { Home } from './pages/Home';
import { MyMatches } from './pages/MyMatches';
import { Leaderboard } from './pages/Leaderboard';
import { Profile } from './pages/Profile';
import { AdminDashboard } from './pages/AdminDashboard';
import { Tournament } from './types';

function AppContent() {
  const { showLoginModal, setShowLoginModal, isAdmin } = useAuth();
  const [activeTab, setActiveTab] = useState<string>('home');
  const [selectedTournament, setSelectedTournament] = useState<Tournament | null>(null);

  // Modals state
  const [showRegistrationModal, setShowRegistrationModal] = useState(false);
  const [targetRegistrationTour, setTargetRegistrationTour] = useState<Tournament | null>(null);

  const [showRoomModal, setShowRoomModal] = useState(false);
  const [targetRoomTour, setTargetRoomTour] = useState<Tournament | null>(null);

  const [showPrizeModal, setShowPrizeModal] = useState(false);
  const [targetPrizeTour, setTargetPrizeTour] = useState<Tournament | null>(null);

  const [showNotificationsModal, setShowNotificationsModal] = useState(false);
  const [showWalletModal, setShowWalletModal] = useState(false);

  // Navigation handlers
  const handleSelectTournament = (tour: Tournament) => {
    setSelectedTournament(tour);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleJoinTournament = (tour: Tournament) => {
    setTargetRegistrationTour(tour);
    setShowRegistrationModal(true);
  };

  const handleOpenRoomId = (tour: Tournament) => {
    setTargetRoomTour(tour);
    setShowRoomModal(true);
  };

  const handleOpenPrizeList = (tour: Tournament) => {
    setTargetPrizeTour(tour);
    setShowPrizeModal(true);
  };

  const renderActivePage = () => {
    switch (activeTab) {
      case 'home':
        return (
          <Home
            onSelectTournament={handleSelectTournament}
            onJoinTournament={handleJoinTournament}
            onOpenRoomId={handleOpenRoomId}
            onOpenPrizeList={handleOpenPrizeList}
            setActiveTab={setActiveTab}
            onOpenWallet={() => setShowWalletModal(true)}
          />
        );
      case 'my-matches':
        return (
          <MyMatches
            onSelectTournament={handleSelectTournament}
            setActiveTab={setActiveTab}
          />
        );
      case 'leaderboard':
        return <Leaderboard setActiveTab={setActiveTab} />;
      case 'profile':
        return <Profile setActiveTab={setActiveTab} onOpenWallet={() => setShowWalletModal(true)} />;
      case 'admin':
        return <AdminDashboard />;
      default:
        return (
          <Home
            onSelectTournament={handleSelectTournament}
            onJoinTournament={handleJoinTournament}
            onOpenRoomId={handleOpenRoomId}
            onOpenPrizeList={handleOpenPrizeList}
            setActiveTab={setActiveTab}
            onOpenWallet={() => setShowWalletModal(true)}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#f4f6f8] text-slate-800 flex flex-col font-sans">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        setShowNotifications={setShowNotificationsModal}
        onOpenWallet={() => setShowWalletModal(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-xl w-full mx-auto px-3 sm:px-4 pt-3 pb-20">
        {renderActivePage()}
      </main>

      {/* Mobile-First Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      {/* Modals */}
      <WalletModal
        isOpen={showWalletModal}
        onClose={() => setShowWalletModal(false)}
      />

      <RegistrationModal
        tournament={targetRegistrationTour}
        isOpen={showRegistrationModal}
        onClose={() => setShowRegistrationModal(false)}
        onNavigateToMatches={() => setActiveTab('my-matches')}
      />

      <RoomModal
        tournament={targetRoomTour}
        isOpen={showRoomModal}
        onClose={() => setShowRoomModal(false)}
        onJoinPrompt={() => {
          if (targetRoomTour) handleJoinTournament(targetRoomTour);
        }}
      />

      <PrizeListModal
        tournament={targetPrizeTour}
        isOpen={showPrizeModal}
        onClose={() => setShowPrizeModal(false)}
      />

      <LoginModal
        isOpen={showLoginModal}
        onClose={() => setShowLoginModal(false)}
      />

      <NotificationModal
        isOpen={showNotificationsModal}
        onClose={() => setShowNotificationsModal(false)}
        onNavigateToMatches={() => setActiveTab('my-matches')}
        onNavigateToLeaderboard={() => setActiveTab('leaderboard')}
      />
    </div>
  );
}

class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { hasError: boolean; error: Error | null }> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('App ErrorBoundary caught an error:', error, errorInfo);
  }

  handleReset = () => {
    localStorage.clear();
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-900 text-white flex flex-col items-center justify-center p-6 text-center font-bangla">
          <div className="max-w-md w-full bg-slate-800 border border-slate-700 rounded-2xl p-6 shadow-xl space-y-4">
            <div className="w-16 h-16 rounded-full bg-red-600/20 text-red-500 flex items-center justify-center mx-auto text-2xl font-black">
              ⚠️
            </div>
            <h2 className="text-xl font-black font-heading text-white">কিছু একটি সমস্যা হয়েছে</h2>
            <p className="text-xs text-slate-300 leading-relaxed">
              অ্যাপ্লিকেশনটি লোড হতে সমস্যা হয়েছে। নিচের বাটনে ক্লিক করে পুনরায় লোড করুন।
            </p>
            <div className="pt-2 flex flex-col gap-2">
              <button
                onClick={() => window.location.reload()}
                className="w-full py-2.5 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold cursor-pointer transition-colors shadow-md"
              >
                রিলোড করুন (Reload)
              </button>
              <button
                onClick={this.handleReset}
                className="w-full py-2 px-4 rounded-xl bg-slate-700 hover:bg-slate-600 text-slate-300 text-xs font-bold cursor-pointer transition-colors"
              >
                ক্লিয়ার ডেটা ও রিস্টার্ট
              </button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <TournamentProvider>
          <AppContent />
        </TournamentProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}
